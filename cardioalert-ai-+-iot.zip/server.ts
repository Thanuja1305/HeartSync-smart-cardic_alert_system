import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import twilio from "twilio";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build"
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Memory store to prevent duplicate alerts/WhatsApp sends
  const activeEmergencies = new Set<string>();

  // TWILIO UTILS
  const getTwilioConfig = () => {
    return {
      accountSid: process.env.TWILIO_ACCOUNT_SID || "ACbe747a506266064272ab612d2a3c5003",
      authToken: process.env.TWILIO_AUTH_TOKEN || "8cec321a1aa404417af17c1b5ee400a2",
      phoneNumber: process.env.TWILIO_PHONE_NUMBER || "+18157654866"
    };
  };

  // API ROUTE: Send WhatsApp emergency message
  app.post("/api/send-emergency-whatsapp", async (req, res) => {
    try {
      const { patientId, patientName, heartRate, spo2, temp, force } = req.body;

      if (!patientId) {
        return res.status(400).json({ error: "patientId is required" });
      }

      // Check if message already sent for this patient alert session
      if (activeEmergencies.has(patientId) && !force) {
        return res.json({ 
          success: true, 
          message: "WhatsApp alert already sent for this emergency event (duplicate prevented).",
          alreadySent: true
        });
      }

      const config = getTwilioConfig();
      const twilioLib = twilio as any;
      const client = twilioLib.default ? twilioLib.default(config.accountSid, config.authToken) : twilio(config.accountSid, config.authToken);

      const nameVal = patientName || "John Doe";
      const hrVal = heartRate || 42;
      const spo2Val = spo2 || 82;
      const tempVal = temp || 39;

      const messageContent = `🚨 EMERGENCY ALERT 🚨\n\nPatient is in critical condition.\n\nPatient Name: ${nameVal}\nHeart Rate: ${hrVal} BPM\nSPO2: ${spo2Val}%\nTemperature: ${tempVal}°C\nStatus: HIGH RISK\n\nImmediate medical attention required.`;

      const toFamily = "whatsapp:+917569824148";
      const toAmbulance = "whatsapp:+919573732216";
      const fromWhatsapp = "whatsapp:+14155238886";

      console.log(`[TWILIO WHATSAPP] Sending alert from ${fromWhatsapp} to Family and Ambulance...`);

      const [msgFamily, msgAmbulance] = await Promise.all([
        client.messages.create({
          body: messageContent,
          from: fromWhatsapp,
          to: toFamily
        }),
        client.messages.create({
          body: messageContent,
          from: fromWhatsapp,
          to: toAmbulance
        })
      ]);

      console.log(`[TWILIO SUCCESS] WhatsApp Family SID: ${msgFamily.sid}, Ambulance SID: ${msgAmbulance.sid}`);

      // Track that alert is active
      activeEmergencies.add(patientId);

      return res.json({ 
        success: true, 
        sid: msgFamily.sid,
        message: "Emergency messages successfully sent to Family and Ambulance!" 
      });

    } catch (error: any) {
      console.error("[TWILIO FAILURE] WhatsApp sending failed:", error);
      return res.status(500).json({ 
        error: "Twilio WhatsApp send failed", 
        details: error?.message || String(error) 
      });
    }
  });

  // API ROUTE: Trigger Phone Call to Ambulance (Twilio Voice)
  app.post("/api/trigger-ambulance-call", async (req, res) => {
    try {
      const { patientId, patientName } = req.body;
      const config = getTwilioConfig();
      const twilioLib = twilio as any;
      const client = twilioLib.default ? twilioLib.default(config.accountSid, config.authToken) : twilio(config.accountSid, config.authToken);

      const ambulanceNumber = "9573732216";
      const formattedTo = ambulanceNumber.startsWith("+") ? ambulanceNumber : `+91${ambulanceNumber}`;

      console.log(`[TWILIO VOICE] Calling Ambulance at ${formattedTo}...`);

      const targetTwiml = `<Response>
        <Say voice="alice" loop="2">
          Emergency alert from Heart Sync Clinical Portal. Patient ${patientName || "identified"} is in critical status. Heart rate and parameters are severely out of limit. Immediate hospital ambulance dispatch requested. Please reply to acknowledge.
        </Say>
      </Response>`;

      const twilioCall = await client.calls.create({
        twiml: targetTwiml,
        to: formattedTo,
        from: config.phoneNumber
      });

      console.log(`[TWILIO VOICE SUCCESS] Call SID: ${twilioCall.sid}`);

      return res.json({ 
        success: true, 
        sid: twilioCall.sid,
        message: "Ambulance automated call initiated!" 
      });

    } catch (error: any) {
      console.error("[TWILIO FAILURE] Voice Call failed:", error);
      return res.status(500).json({ 
        error: "Voice Call Initiation failed", 
        details: error?.message || String(error) 
      });
    }
  });

  // API ROUTE: Reset/Clear active alert WhatsApp tracks
  app.post("/api/reset-emergency-state", (req, res) => {
    const { patientId } = req.body;
    if (patientId) {
      activeEmergencies.delete(patientId);
      console.log(`[STATE RESET] Active emergency state tag cleared for patient: ${patientId}`);
    } else {
      activeEmergencies.clear();
      console.log("[STATE RESET] All active emergency logs cleared.");
    }
    return res.json({ success: true });
  });

  // Helper function to handle robust Gemini API calls with graceful fallback to gemini-3.5-flash
  async function generateContentWithFallback(params: any): Promise<any> {
    const originalModel = params.model;
    try {
      console.info(`[GEMINI ROUTER] Attempting cardiac inference with model: ${originalModel}...`);
      return await ai.models.generateContent(params);
    } catch (error: any) {
      console.warn(`[GEMINI ROUTER WARNING] Model ${originalModel} failed. Error:`, error?.message || error);
      
      const isProModel = originalModel === "gemini-3.1-pro-preview";
      const isQuotaError = 
        error?.message?.toLowerCase().includes("quota") ||
        error?.message?.toLowerCase().includes("limit") ||
        error?.message?.toLowerCase().includes("exhausted") ||
        error?.message?.toLowerCase().includes("429") ||
        error?.status === "RESOURCE_EXHAUSTED" ||
        String(error?.statusCode) === "429";

      if (isProModel) {
        console.info("⚡ [GEMINI ROUTER RESILIENCE] Falling back from gemini-3.1-pro-preview to gemini-3.5-flash to ensure 100% clinician portal uptime.");
        
        const fallbackParams = { ...params };
        fallbackParams.model = "gemini-3.5-flash";
        
        // Ensure compatible config for gemini-3.5-flash: remove/adjust thinkingConfig since gemini-3.5-flash can run faster in standard mode
        if (fallbackParams.config) {
          fallbackParams.config = { ...fallbackParams.config };
          if (fallbackParams.config.thinkingConfig) {
            delete fallbackParams.config.thinkingConfig;
          }
        }
        
        try {
          return await ai.models.generateContent(fallbackParams);
        } catch (fallbackError: any) {
          console.error("[GEMINI ROUTER FATAL] Fallback model gemini-3.5-flash also failed:", fallbackError);
          throw fallbackError;
        }
      }
      throw error;
    }
  }

  // API ROUTE: Secure server-side patient health telemetry analysis using thinking mode
  app.post("/api/gemini/analyze", async (req, res) => {
    try {
      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: "GEMINI_API_KEY is not configured on the server." });
      }

      const { metrics } = req.body;
      if (!metrics) {
        return res.status(400).json({ error: "Patient health metrics are required." });
      }

      const prompt = `
        As a Cardiology AI Specialist, analyze these live patient metrics and provide a structured assessment.
        
        PATIENT METRICS:
        - Heart Rate: ${metrics.bpm || metrics.heartRate} BPM
        - SpO2: ${metrics.spo2}%
        - Temperature: ${metrics.temperature || metrics.temp}°F
        - Motion: ${metrics.motion || metrics.motionStatus || "Unknown"}
        - ECG Status: High-frequency waveform active
        
        RESPOND IN JSON FORMAT:
        {
          "status": "NORMAL" | "RISK" | "EMERGENCY",
          "suggestion": "Brief friendly suggestion for the patient dashboard",
          "reasoning": "Clinical reasoning for the AI Assistant tab (2-3 sentences)",
          "recommendation": "Next steps or medical advice",
          "riskScore": 0-100 (where 0 is healthy),
          "riskLevel": "Stable" | "Elevated" | "Critical"
        }
      `;

      const response = await generateContentWithFallback({
        model: "gemini-3.1-pro-preview",
        contents: prompt,
        config: {
          thinkingConfig: {
            thinkingLevel: "HIGH" as any
          },
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              status: { type: Type.STRING },
              suggestion: { type: Type.STRING },
              reasoning: { type: Type.STRING },
              recommendation: { type: Type.STRING },
              riskScore: { type: Type.NUMBER },
              riskLevel: { type: Type.STRING }
            },
            required: ["status", "suggestion", "reasoning", "recommendation", "riskScore", "riskLevel"]
          }
        }
      });

      const text = response.text || "{}";
      const result = JSON.parse(text);
      return res.json(result);
    } catch (error: any) {
      console.error("[GEMINI ANALYZE ERROR]", error);
      return res.status(500).json({ 
        error: "Deep cardiac assessment failed", 
        details: error?.message || String(error) 
      });
    }
  });

  // API ROUTE: Secure server-side cardiac expert conversation using thinking mode
  app.post("/api/gemini/chat", async (req, res) => {
    try {
      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: "GEMINI_API_KEY is not configured on the server." });
      }

      const { messages, context, systemInstruction } = req.body;
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages array is required." });
      }

      // Format messages into Content parts
      // Note: We inject context as the initial user prompt setup, and maps everything else.
      const response = await generateContentWithFallback({
        model: "gemini-3.1-pro-preview",
        contents: [
          { role: "user", parts: [{ text: context || "You are a specialized cardiac clinical assistant." }] },
          ...messages.map(m => ({
            role: m.role === "user" ? "user" : "model",
            parts: [{ text: m.text }]
          }))
        ],
        config: {
          thinkingConfig: {
            thinkingLevel: "HIGH" as any
          },
          systemInstruction: systemInstruction || "You are a specialized cardiac emergency assistant."
        }
      });

      return res.json({ text: response.text || "" });
    } catch (error: any) {
      console.error("[GEMINI CHAT ERROR]", error);
      return res.status(500).json({ 
        error: "Cardiac consultation link failed", 
        details: error?.message || String(error) 
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

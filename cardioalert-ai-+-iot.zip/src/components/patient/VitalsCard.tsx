import React, { useEffect, useState, useRef } from 'react';
import { LucideIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface VitalsCardProps {
  label: string;
  value: string | number;
  unit: string;
  status: 'optimal' | 'warning' | 'critical' | 'Normal' | 'Warning' | 'Critical';
  icon: LucideIcon;
  trend?: 'up' | 'down' | 'stable';
  customStatusLabel?: string;
}

const VitalsCard: React.FC<VitalsCardProps> = ({ 
  label, 
  value, 
  unit, 
  status: rawStatus, 
  icon: Icon, 
  trend, 
  customStatusLabel 
}) => {
  const [justUpdated, setJustUpdated] = useState(false);
  const prevValueRef = useRef<string | number>(value);

  // Normalize status to lowercase
  const status = (rawStatus || 'optimal').toLowerCase() as 'optimal' | 'normal' | 'warning' | 'critical';

  // Highlight card when value changes (Real-time active feedback!)
  useEffect(() => {
    if (value !== prevValueRef.current && value !== '--' && value !== 0 && value !== '0') {
      setJustUpdated(true);
      const timer = setTimeout(() => setJustUpdated(false), 800);
      prevValueRef.current = value;
      return () => clearTimeout(timer);
    }
  }, [value]);

  // Determine styles for ICU theme
  const isCritical = status === 'critical';
  const isWarning = status === 'warning';
  const isNormal = status === 'optimal' || status === 'normal';

  // Base state color config
  let alertStyle = '';
  let badgeStyle = '';
  let glowColor = '';

  if (isCritical) {
    alertStyle = 'border-red-200 bg-gradient-to-br from-red-50/20 to-white shadow-[0_0_20px_rgba(239,68,68,0.15)] ring-4 ring-red-500/10 animate-[pulse_1.5s_infinite]';
    badgeStyle = 'bg-red-500 text-white font-black';
    glowColor = 'bg-red-500/10 text-red-600';
  } else if (isWarning) {
    alertStyle = 'border-amber-200 bg-gradient-to-br from-amber-50/20 to-white shadow-sm animate-[pulse_2s_infinite]';
    badgeStyle = 'bg-amber-500 text-white font-black';
    glowColor = 'bg-amber-500/10 text-amber-600';
  } else {
    alertStyle = 'border-slate-100 bg-white shadow-premium hover:border-slate-200';
    badgeStyle = 'bg-emerald-500/10 text-emerald-600 font-bold';
    glowColor = 'bg-emerald-500/10 text-emerald-600';
  }

  // Active flicker if just updated
  const updatePulseStyle = justUpdated 
    ? 'ring-2 ring-emerald-400 shadow-[0_0_25px_rgba(52,211,153,0.3)] duration-75 scale-[1.02]' 
    : 'transition-all duration-500';

  return (
    <div className={`p-5 md:p-6 rounded-[28px] border ${alertStyle} ${updatePulseStyle} relative group overflow-hidden`}>
      {/* Decorative cybernetic corner lines */}
      <div className="absolute top-0 left-0 w-3 h-[1px] bg-slate-200 group-hover:bg-accent-maroon transition-all" />
      <div className="absolute top-0 left-0 w-[1px] h-3 bg-slate-200 group-hover:bg-accent-maroon transition-all" />
      <div className="absolute bottom-0 right-0 w-3 h-[1px] bg-slate-200 group-hover:bg-accent-maroon transition-all" />
      <div className="absolute bottom-0 right-0 w-[1px] h-3 bg-slate-200 group-hover:bg-accent-maroon transition-all" />

      {/* Grid subtle background pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.005)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.005)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />

      {/* Header section with icon and status */}
      <div className="flex justify-between items-start mb-4 relative z-10">
        <div className={`p-3 rounded-xl border border-slate-100 ${glowColor} group-hover:scale-110 transition-all`}>
          <Icon className="w-5 h-5" />
        </div>
        
        <div className="flex items-center gap-1.5">
          <div className="relative flex h-2 w-2">
            {!isNormal ? (
              <>
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isCritical ? 'bg-red-400' : 'bg-amber-400'}`}></span>
                <span className={`relative inline-flex rounded-full h-2 w-2 ${isCritical ? 'bg-red-500' : 'bg-amber-500'}`}></span>
              </>
            ) : (
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            )}
          </div>
          <span className={`px-2 py-0.5 rounded-md text-[8px] font-mono tracking-widest uppercase border ${
            isCritical ? 'bg-red-50 border-red-100 text-red-600' : isWarning ? 'bg-amber-50 border-amber-100 text-amber-600' : 'bg-emerald-50 border-emerald-100 text-emerald-600'
          }`}>
            {customStatusLabel || (isCritical ? 'CRITICAL' : isWarning ? 'WARNING' : 'STABLE')}
          </span>
        </div>
      </div>

      {/* Main live metrics */}
      <div className="relative z-10 space-y-1">
        <p className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest">{label}</p>
        <div className="flex items-baseline gap-1.5">
          <motion.h3 
            className={`text-3xl md:text-4xl font-extrabold font-mono tracking-tight italic ${
              isCritical ? 'text-red-600' : isWarning ? 'text-amber-500' : 'text-slate-900'
            }`}
            animate={justUpdated ? { scale: [1, 1.1, 1], y: [0, -4, 0] } : {}}
            transition={{ duration: 0.3 }}
          >
            {value}
          </motion.h3>
          <span className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest">{unit}</span>
        </div>
      </div>

      {/* Bottom diagnostic read-out */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-1 font-mono text-[9px] text-slate-400">
          <span className="w-1 h-1 rounded-full bg-slate-350" />
          <span>TELEM ACTIVE</span>
        </div>

        {trend && (
          <div className="flex items-center gap-1.5">
            <span className="text-[8px] font-mono text-slate-400 uppercase tracking-wider">Trend:</span>
            <div className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-black uppercase ${
              trend === 'up' ? 'bg-amber-50 text-amber-650' : trend === 'down' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600'
            }`}>
              {trend}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VitalsCard;

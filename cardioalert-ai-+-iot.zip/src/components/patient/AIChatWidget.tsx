import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Send, User, Sparkles, X, Heart, ShieldCheck, Minimize2, Maximize2 } from 'lucide-react';
import { rtdb } from '../../lib/firebase';
import { ref, onValue } from 'firebase/database';

interface AIChatWidgetProps {
  userId: string;
}

const AIChatWidget: React.FC<AIChatWidgetProps> = ({ userId }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [vitals, setVitals] = useState<any>(null);
  const [patientData, setPatientData] = useState<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Force direct alignment to the active clinical patient profile
    const targetUserId = "m1uph2bX7SVd9Wbyge1AMqAmq093";
    console.log("Chatbot Listener Connected: Subscribing to m1uph2bX7SVd9Wbyge1AMqAmq093");

    const patientRef = ref(rtdb, `/users/${targetUserId}`);
    const liveReadingRef = ref(rtdb, `/users/${targetUserId}/liveReading`);

    const unsubPatient = onValue(patientRef, (snapshot) => {
      const data = snapshot.val();
      console.log("Chatbot Patient Data Received:", data);
      if (data) {
        setPatientData({
          name: data.name || data.fullName || "Rahul Sharma",
          age: data.age || "54",
          gender: data.gender || "Male",
          bloodGroup: data.bloodGroup || "O+",
          condition: data.condition || "Post-Myocardial Infarction Telemetry"
        });
      }
    }, (err) => {
      console.error("Firebase connection error (patient profile):", err);
    });

    const unsubLive = onValue(liveReadingRef, (snapshot) => {
      const data = snapshot.val();
      console.log("Chatbot Live Reading Received:", data);
      if (data) {
        // Parse raw keys
        const rawHr = data.BPM !== undefined ? Number(data.BPM) : (data.bpm !== undefined ? Number(data.bpm) : (data.heartRate !== undefined ? Number(data.heartRate) : 72));
        const rawO2 = data.SpO2 !== undefined ? Number(String(data.SpO2).replace('%', '')) : (data.spo2 !== undefined ? Number(data.spo2) : (data.o2 !== undefined ? Number(data.o2) : 98));
        const rawTemp = data.Temp !== undefined ? Number(String(data.Temp).replace(/[CF\s]/gi, '')) : (data.temperature !== undefined ? Number(data.temperature) : (data.temp !== undefined ? Number(data.temp) : 36.7));
        const rawHum = data.Humidity !== undefined ? Number(String(data.Humidity).replace('%', '')) : (data.humidity !== undefined ? Number(data.humidity) : 58);
        const rawEcg = data.ECG !== undefined ? data.ECG : (data.ecg !== undefined ? data.ecg : 512);

        setVitals({
          heartRate: Math.round(rawHr),
          bpm: Math.round(rawHr),
          spo2: Math.round(rawO2),
          o2: Math.round(rawO2),
          temperature: Number(rawTemp.toFixed(1)),
          temp: Number(rawTemp.toFixed(1)),
          humidity: Math.round(rawHum),
          ecg: rawEcg
        });
        console.log("Chatbot ECG Updated:", rawEcg);
      }
    }, (err) => {
      console.error("Firebase connection error (live readings):", err);
    });

    return () => {
      console.log("Chatbot Listener Disconnected");
      unsubPatient();
      unsubLive();
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen, isMinimized]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const context = `
        You are "Nurse Sarah", an experienced, professional, and compassionate registered nurse specializing in ICU and acute cardiovascular monitoring at the HeartSync clinical center.
        
        Patient Medical Demographics:
        - Patient Name: ${patientData?.name || patientData?.fullName || "Rahul Sharma"}
        - Age: ${patientData?.age || "54"}
        - Gender: ${patientData?.gender || "Male"}
        - Blood Group: ${patientData?.bloodGroup || "O+"}
        - Clinical Condition: ${patientData?.condition || "Post-Myocardial Infarction Telemetry"}
        
        Live Telemetry Feed (CRITICAL DIAGNOSTIC DATA):
        - Live Heart Rate (BPM): ${vitals?.heartRate || "72"} BPM
        - Live Blood Oxygen (SpO2): ${vitals?.spo2 || "98"}%
        - Live Temperature: ${vitals?.temperature || "36.7"}°C
        - Ambient Humidity: ${vitals?.humidity || "58"}%
        - Live ECG index: ${vitals?.ecg || "512"} (Normal sinus waveform index)

        Triage Protocols for Nurse Sarah:
        1. Tone: Professional, alert, authoritative yet gentle, reassuring, and completely medically realistic. Do not make generic responses. Reference the patient's exact current metrics.
        2. Diagnosis and Triage:
           - If Heart Rate > 120 (Tachycardia), tell them to rest immediately, breathe deeply, and check for chest tightness or pressure.
           - If heart rate is very low (Bradycardia < 45), enquire if they are suffering faintness or weakness.
           - If Oxygen Saturation (SpO2) < 90% (Hypoxia), immediately notify them of the alert, direct them to breathe slow and deep, sit upright, and ask if an oxygen concentrator is nearby.
           - In all critical situations (BPM > 120 or SpO2 < 90), state that the medical team has received their clinical telemetry, and ask any accompanying person to stay close.
        3. Nursing Counsel: Offer practical clinical advice (sitting posture, breathing techniques, hydration, warmth, avoidance of stressful stimuli) to help stabilize pre-clinical anxiety. Limit response to 3-4 dense, bulleted or cohesive paragraphs so it is clearly legible on small screen sizes. Use Nurse terminology (e.g. cardiac output, cardiopulmonary perfusion, oxygenation, sinus rhythms).
      `;

      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: [...messages, { role: 'user', text: input }],
          context: context,
          systemInstruction: "You are Nurse Sarah, an experienced, professional, and compassionate registered nurse specializing in ICU and acute cardiovascular monitoring at the HeartSync clinical center."
        })
      });

      if (!response.ok) {
        throw new Error(`Failed widget chat request: ${response.statusText}`);
      }

      const data = await response.json();
      setMessages(prev => [...prev, { role: 'model', text: data.text || "Synchronizing with medical nodes..." }]);
      console.log("Chatbot UI Updated with Nurse Sarah response");
    } catch (error) {
      console.error("Nurse Sarah inference failure:", error);
      setMessages(prev => [...prev, { role: 'model', text: "Telemetry link interrupted. Please rely on standard emergency protocols or dial 911 immediately if you feel unwell." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-[100] flex flex-col items-end max-w-[calc(100vw-32px)]">
      <AnimatePresence>
        {isOpen && !isMinimized && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="w-[320px] sm:w-[380px] h-[480px] sm:h-[520px] bg-white rounded-[32px] shadow-premium border border-slate-100 flex flex-col overflow-hidden mb-4"
          >
            <div className="p-5 sm:p-6 bg-accent-maroon text-white flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Bot className="w-5 h-5 text-red-100" />
                </div>
                <div>
                  <h4 className="text-sm font-black tracking-tight flex items-center gap-1.5">
                    Nurse Sarah
                    <span className="inline-block w-1.5 h-1.5 bg-green-400 rounded-full animate-ping" />
                  </h4>
                  <p className="text-[8px] font-black uppercase tracking-widest opacity-80 italic">Telemetry ICU Unit</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setIsMinimized(true)} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                  <Minimize2 className="w-4 h-4" />
                </button>
                <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 no-scrollbar" ref={scrollRef}>
              {messages.length === 0 && (
                <div className="text-center py-6 sm:py-10">
                  <div className="w-16 h-16 bg-accent-maroon/5 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sparkles className="w-8 h-8 text-accent-maroon animate-pulse" />
                  </div>
                  <h5 className="font-black text-slate-900 tracking-tight mb-2 italic">How is your heart feeling today?</h5>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-relaxed px-4 sm:px-6">
                    Explain any chest sensations, shortness of breath, or request a telemetry check-up.
                  </p>
                </div>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`p-4 rounded-2xl text-[11px] sm:text-xs font-bold leading-relaxed max-w-[85%] ${
                    msg.role === 'user' ? 'bg-slate-900 text-white rounded-tr-none shadow-sm' : 'bg-slate-50 text-slate-600 border border-slate-100 rounded-tl-none'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="p-4 bg-slate-50 rounded-2xl rounded-tl-none border border-slate-100 italic text-[9px] font-black text-slate-400 uppercase tracking-wider animate-pulse">
                    Consulting Telemetry...
                  </div>
                </div>
              )}
            </div>

            <div className="p-5 sm:p-6 border-t border-slate-50 bg-slate-50/50">
              <div className="relative">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Tell Nurse Sarah your symptoms..."
                  className="w-full bg-white border border-slate-100 pl-5 pr-14 py-3.5 rounded-2xl text-[11px] sm:text-xs font-bold outline-none focus:border-accent-maroon/20 focus:ring-4 focus:ring-accent-maroon/5 transition-all text-slate-800 placeholder-slate-400"
                />
                <button 
                  onClick={handleSend}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-accent-maroon text-white rounded-xl shadow-lg shadow-accent-maroon/20 hover:bg-accent-maroon/90 active:scale-95 transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button 
        onClick={() => {
          if (isOpen && isMinimized) setIsMinimized(false);
          else setIsOpen(!isOpen);
        }}
        className="w-14 h-14 sm:w-16 sm:h-16 bg-accent-maroon text-white rounded-[24px] shadow-glow-maroon hover:shadow-glow-maroon-hover hover:scale-105 active:scale-95 transition-all flex items-center justify-center relative group"
      >
        <Bot className={`w-7 h-7 sm:w-8 sm:h-8 transition-transform duration-500 ${isOpen && !isMinimized ? 'rotate-[360deg]' : ''}`} />
        <div className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full animate-pulse" />
      </button>
    </div>
  );
};

export default AIChatWidget;

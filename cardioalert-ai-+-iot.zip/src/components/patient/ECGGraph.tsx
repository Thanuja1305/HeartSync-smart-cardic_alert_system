import React, { useRef, useEffect, useState } from 'react';
import { 
  Activity, 
  Monitor, 
  Download, 
  Printer, 
  Settings, 
  Info, 
  Heart, 
  SlidersHorizontal,
  ChevronDown,
  Sparkles,
  RefreshCw,
  HelpCircle
} from 'lucide-react';

interface ECGGraphProps {
  bpm: number;
  liveEcg?: number | number[] | string;
  spo2?: number;
}

enum ECGMode {
  DIAG_12_LEAD = "12_LEAD",
  LIVE_TELEMETRY = "LIVE_TELEMETRY"
}

enum GridColorTheme {
  CLINICAL_PINK = "PINK",
  CHARCOAL_GREY = "GREY",
  ONXY_DARK = "DARK"
}

const ECGGraph: React.FC<ECGGraphProps> = ({ bpm: rawBpm, liveEcg, spo2 }) => {
  const [activeMode, setActiveMode] = useState<ECGMode>(ECGMode.DIAG_12_LEAD);
  const [gridTheme, setGridTheme] = useState<GridColorTheme>(GridColorTheme.CLINICAL_PINK);
  const [paperSpeed, setPaperSpeed] = useState<number>(25); // 25 mm/sec or 50 mm/sec
  const [amplitudeGain, setAmplitudeGain] = useState<number>(10); // 10 mm/mV or 20 mm/mV
  const [liveLog, setLiveLog] = useState<string>("");

  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Real-time telemetry states
  const pointsRef = useRef<number[]>([]);
  const phaseRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const accumulatedPixelsRef = useRef<number>(0);
  const latestEcgRef = useRef<number>(0);
  const smoothEcgRef = useRef<number | null>(null);
  const baselineRef = useRef<number | null>(null);
  const currentBpmRef = useRef<number>(rawBpm || 72);
  const sampleQueueRef = useRef<number[]>([]);
  const lastProcessedEcgRef = useRef<string>("");

  const currentBpm = typeof rawBpm === 'number' && !isNaN(rawBpm) && rawBpm > 0 ? rawBpm : 72;
  const oxygenSaturation = typeof spo2 === 'number' && spo2 > 0 ? spo2 : 98;

  // Sync real-time array streaming
  useEffect(() => {
    if (Array.isArray(liveEcg)) {
      const arrayKey = liveEcg.slice(-10).join(",");
      if (arrayKey !== lastProcessedEcgRef.current) {
        lastProcessedEcgRef.current = arrayKey;
        if (sampleQueueRef.current.length < 10) {
          sampleQueueRef.current.push(...liveEcg);
        } else {
          const appendCount = Math.min(liveEcg.length, 5);
          sampleQueueRef.current.push(...liveEcg.slice(-appendCount));
        }
      }
    } else if (typeof liveEcg === 'number') {
      latestEcgRef.current = liveEcg;
      sampleQueueRef.current.push(liveEcg);
    }
    
    if (sampleQueueRef.current.length > 250) {
      sampleQueueRef.current = sampleQueueRef.current.slice(-100);
    }
  }, [liveEcg]);

  // Medically Accurate piece-wise waveform generator for a single heartbeat cycle (PQRST)
  // Evaluates relative voltage (in mV) at a given lead and absolute second timestamp `t`
  const getPQRSTVoltage = (leadName: string, t: number, activeBpm: number): number => {
    if (activeBpm <= 0) return 0;

    const lead = leadName.toUpperCase();
    const T_beat = 60 / activeBpm; // beat period in seconds (e.g. 0.833s for 72 BPM)
    const tau = t % T_beat; // phase time in seconds

    // Calculate rate-dependent scaling of electrical intervals to prevent overlap/drift at high rates
    const scalingFactor = Math.min(1.0, T_beat / 0.8333);

    // Physiological intervals in seconds (normal sinus proportions adjusted by heart rate)
    const P_dur = 0.08 * scalingFactor;
    const PR_segment = 0.08 * scalingFactor;
    const QRS_dur = 0.10 * scalingFactor;
    const ST_segment = 0.12 * scalingFactor;
    const T_dur = 0.18 * scalingFactor;

    // Phase markers
    const P_start = 0;
    const P_end = P_start + P_dur;
    const QRS_start = P_end + PR_segment;
    const QRS_end = QRS_start + QRS_dur;
    const T_start = QRS_end + ST_segment;
    const T_end = T_start + T_dur;

    // 1. P WAVE (Smooth rounded dome, inverted in aVR, biphasic in V1)
    if (tau >= P_start && tau < P_end) {
      const slot = (tau - P_start) / P_dur;
      const v_base = 0.18 * Math.sin(slot * Math.PI);
      
      if (lead === 'AVR') return -v_base;
      if (lead === 'V1') return v_base * -0.3; // minor negative force
      if (lead === 'V2') return v_base * 1.2;
      return v_base;
    }

    // 2. PR ISOCONTINUOUS INTERVAL
    if (tau >= P_end && tau < QRS_start) {
      return 0;
    }

    // 3. QRS COMPLEX (Segmented sharp spikes with correct polarity and progressional amplitudes)
    if (tau >= QRS_start && tau < QRS_end) {
      const slot = (tau - QRS_start) / QRS_dur;

      // Define Lead Specific QRS attributes to match physical diagnostics:
      // aVR: inverted QRS
      // V1-L1: rS pattern with minor r, massive downward S
      // V5-V6: Tall R wave, minuscule Q wave, no S
      // Precordial R-wave progression
      let q_peak = -0.12;
      let r_peak = 1.3;
      let s_peak = -0.25;

      if (lead === 'I') {
        r_peak = 1.1;
      } else if (lead === 'II') {
        r_peak = 1.6; // Lead II has highest amplitude in limb plane
      } else if (lead === 'III') {
        r_peak = 0.5;
        s_peak = -0.3;
      } else if (lead === 'AVR') {
        // Completely inverted QRS sequence
        q_peak = 0.1;
        r_peak = -1.3;
        s_peak = 0.15;
      } else if (lead === 'AVL') {
        r_peak = 0.45;
        s_peak = -0.15;
      } else if (lead === 'AVF') {
        r_peak = 1.1;
      } else if (lead === 'V1') {
        // rS pattern
        q_peak = 0;
        r_peak = 0.18; // tiny r
        s_peak = -1.8; // deep S
      } else if (lead === 'V2') {
        q_peak = -0.05;
        r_peak = 0.55; 
        s_peak = -1.4;
      } else if (lead === 'V3') {
        q_peak = -0.08;
        r_peak = 1.0; 
        s_peak = -0.9; // Transition zone (equidistant)
      } else if (lead === 'V4') {
        q_peak = -0.12;
        r_peak = 1.6;
        s_peak = -0.4;
      } else if (lead === 'V5') {
        q_peak = -0.15;
        r_peak = 2.0; // Tall R wave
        s_peak = -0.05; // diminished S
      } else if (lead === 'V6') {
        q_peak = -0.14;
        r_peak = 1.8;
        s_peak = 0; // No S wave
      }

      // Model the QRS template piece-wise
      if (slot < 0.18) { // Q-dip
        const u = slot / 0.18;
        return q_peak * Math.sin(u * Math.PI);
      } else if (slot >= 0.18 && slot < 0.55) { // R-spike
        const u = (slot - 0.18) / 0.37;
        if (u < 0.5) return r_peak * (u / 0.5);
        return r_peak * (1.0 - (u - 0.5) / 0.5);
      } else { // S-dip
        const u = (slot - 0.55) / 0.45;
        return s_peak * Math.sin(u * Math.PI);
      }
    }

    // 4. ST SEGMENT (Isoelectric baseline segment)
    if (tau >= QRS_end && tau < T_start) {
      return 0;
    }

    // 5. T WAVE (Asymmetric smooth dome, inverted in aVR, tall in V5-V6)
    if (tau >= T_start && tau < T_end) {
      const slot = (tau - T_start) / T_dur;
      // Beautiful asymmetric shape using powered sine function
      let t_amp = 0.38;

      if (lead === 'AVR') t_amp = -0.35; // inverted T
      else if (lead === 'V1') t_amp = -0.15; // often minor negative
      else if (lead === 'V5' || lead === 'V6') t_amp = 0.45; // taller lateral T
      else if (lead === 'II') t_amp = 0.42;

      return t_amp * Math.pow(Math.sin(slot * Math.PI), 1.6);
    }

    // 6. TP BASELINE SEGMENT (Quiet stage before the next heartbeat begins)
    return 0;
  };

  // Main draw loop triggered to paint the current active mode
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const setupCanvasScale = () => {
      const container = canvas.parentElement;
      if (!container) return;
      
      const width = container.clientWidth || 1000;
      let height = container.clientHeight || container.offsetHeight || 300;
      
      // Keep a healthy minimum height for 12-lead view rows so they are fully legible
      if (height < 180) {
        height = activeMode === ECGMode.DIAG_12_LEAD ? 360 : 200;
      }

      // Adjust for High-DPI retina display smoothness
      const dpr = window.devicePixelRatio || 1;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = '100%';
      canvas.style.height = '100%';
      ctx.scale(dpr, dpr);
    };

    setupCanvasScale();
    window.addEventListener('resize', setupCanvasScale);

    // Color definitions based on chosen Grid Theme
    const getColors = () => {
      switch (gridTheme) {
        case GridColorTheme.CHARCOAL_GREY:
          return {
            paperBg: '#f8fafc', // Slate background
            minorGrid: '#e2e8f0', // Soft grey grid
            majorGrid: '#cbd5e1', // Stronger grey grids
            traceLine: '#020617', // Solid black ink
            axisLine: '#94a3b8',
            labelColor: '#475569'
          };
        case GridColorTheme.ONXY_DARK:
          return {
            paperBg: '#090d16', // Dark space neon room
            minorGrid: 'rgba(239, 68, 68, 0.05)', // Neon thin red lines
            majorGrid: 'rgba(239, 68, 68, 0.16)', // Neon bold red lines
            traceLine: '#ffffff', // High-contrast electrical white
            axisLine: 'rgba(239, 68, 68, 0.28)',
            labelColor: '#fca5a5'
          };
        case GridColorTheme.CLINICAL_PINK:
        default:
          return {
            paperBg: '#fffbfb', // Traditional clinical pinkish clean card
            minorGrid: 'rgba(244, 63, 94, 0.12)', // Authentic light pink squares (1mm)
            majorGrid: 'rgba(225, 29, 72, 0.38)', // Bold red grids (5mm squares)
            traceLine: '#0d131f', // Professional black/blue-charcoal ink
            axisLine: 'rgba(225, 29, 72, 0.5)',
            labelColor: '#be123c'
          };
      }
    };

    const drawGrid = (width: number, height: number, colors: ReturnType<typeof getColors>, smallSquarePx: number) => {
      ctx.fillStyle = colors.paperBg;
      ctx.fillRect(0, 0, width, height);

      // Minor gridlines (1mm squares)
      ctx.lineWidth = 0.45;
      ctx.strokeStyle = colors.minorGrid;
      for (let x = 0; x < width; x += smallSquarePx) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += smallSquarePx) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Major gridlines (5mm squares, every 5 small squares)
      ctx.lineWidth = 0.95;
      ctx.strokeStyle = colors.majorGrid;
      for (let x = 0; x < width; x += smallSquarePx * 5) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += smallSquarePx * 5) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    };

    const runRenderLoop = () => {
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = canvas.height / (window.devicePixelRatio || 1);
      const colors = getColors();

      // Calculation spacing variables
      // 1 small square = 1mm = 0.04s.
      // 1 large square = 5 small squares = 5mm = 0.20s.
      // Total ECG duration = 10 seconds of biotelemetry.
      // Total horizontal space on 12-lead paper = 250 small squares (50 large squares).
      const totalSmallSquares = 250;
      const smallSquarePx = width / totalSmallSquares; // Scale squares smoothly to fit responsive container width

      // Calibration multiplier
      // 1 mV standard = 10 mm = 10 small squares = (10 * smallSquarePx) px on screen.
      // Scaled dynamically by gain coefficient
      const baseGainScale = (amplitudeGain / 10) * 10; // in mm/mV
      const gainPxPerMV = baseGainScale * smallSquarePx;

      if (activeMode === ECGMode.DIAG_12_LEAD) {
        // --- MODE A: STANDARD 12-LEAD CLINICAL ECG REPORT (3x4 Layout + Continuous Rhythm Strip II) ---
        drawGrid(width, height, colors, smallSquarePx);

        // Dynamic patient header offset on the graph
        const headerOffset = 40;
        const remainingHeight = height - headerOffset - 15;
        const rowHeight = remainingHeight / 4;
        const rowCenters = [
          headerOffset + rowHeight * 0.5,
          headerOffset + rowHeight * 1.5,
          headerOffset + rowHeight * 2.5,
          headerOffset + rowHeight * 3.5
        ];

        const numColumns = 4;
        const colWidth = width / numColumns;

        // Draw patient clinical header directly on the top of the canvas
        ctx.save();
        ctx.fillStyle = colors.paperBg === '#090d16' ? 'rgba(9, 13, 22, 0.9)' : 'rgba(255, 251, 251, 0.9)';
        ctx.fillRect(0, 0, width, headerOffset);
        
        ctx.strokeStyle = colors.axisLine;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, headerOffset);
        ctx.lineTo(width, headerOffset);
        ctx.stroke();

        ctx.fillStyle = colors.labelColor;
        ctx.font = 'bold 9px font-mono, JetBrains Mono, monospace';
        
        // Left branding
        ctx.fillText("HEARTSYNC™ CLINICAL 12-LEAD REPORT", 12, 18);
        ctx.font = 'normal 8px font-mono, JetBrains Mono, sans-serif';
        ctx.fillStyle = colors.labelColor + 'bb';
        ctx.fillText(`FILTER: 0.5-40Hz | SPEED: ${paperSpeed} mm/s | GAIN: ${amplitudeGain} mm/mV`, 12, 30);

        // Right values
        ctx.fillStyle = colors.labelColor;
        ctx.font = 'bold 9px font-mono, JetBrains Mono, monospace';
        ctx.fillText(`HR: ${currentBpm} BPM | PR: 160ms | QRS: 92ms | QT/QTc: 400/438 ms`, width - 350, 18);
        ctx.font = 'normal 8px font-mono, JetBrains Mono, sans-serif';
        ctx.fillStyle = colors.labelColor + 'bb';
        ctx.fillText(`DIAGNOSIS: NORMAL SINUS RHYTHM, NO SIGNIFICANT PATHOLOGY`, width - 350, 30);
        ctx.restore();

        // Draw structural vertical dashed boundary lines between 2.5s columns
        ctx.save();
        ctx.setLineDash([4, 6]);
        ctx.strokeStyle = colors.axisLine;
        ctx.lineWidth = 0.8;
        for (let col = 1; col < numColumns; col++) {
          ctx.beginPath();
          ctx.moveTo(col * colWidth, headerOffset);
          ctx.lineTo(col * colWidth, rowCenters[3] - rowHeight * 0.5); // stops above continuous strip
          ctx.stroke();
        }
        ctx.restore();

        // Separate Continuous Rhythm Area with a bold horizontal baseline
        ctx.strokeStyle = colors.axisLine;
        ctx.lineWidth = 1.25;
        ctx.beginPath();
        ctx.moveTo(0, rowCenters[3] - rowHeight * 0.5);
        ctx.lineTo(width, rowCenters[3] - rowHeight * 0.5);
        ctx.stroke();

        // Define matrix mapping for leads
        const leadMatrix = [
          ['I', 'AVR', 'V1', 'V4'], // Row 1
          ['II', 'AVL', 'V2', 'V5'], // Row 2
          ['III', 'AVF', 'V3', 'V6'] // Row 3
        ];

        // Draw standard calibration pulse (1mV step for 0.2s = 5 small squares) at beginning of each lead segment
        // Calibration waveform: flat, step up 1mV (10 small grids), step down, flat
        const drawCalibrationPulse = (ctx: CanvasRenderingContext2D, startX: number, centerY: number) => {
          ctx.beginPath();
          ctx.strokeStyle = colors.traceLine;
          ctx.lineWidth = 1.8;

          // Dimensions in screen pixels
          const squareWidth = smallSquarePx * 5; // 5mm wide (0.2s)
          const pulseHeight = Math.min(gainPxPerMV * 1.0, rowHeight * 0.42); // 1mV height capped to row headroom

          ctx.moveTo(startX, centerY);
          ctx.lineTo(startX + smallSquarePx, centerY);
          ctx.lineTo(startX + smallSquarePx, centerY - pulseHeight);
          ctx.lineTo(startX + squareWidth - smallSquarePx * 2, centerY - pulseHeight);
          ctx.lineTo(startX + squareWidth - smallSquarePx * 2, centerY);
          ctx.lineTo(startX + squareWidth, centerY);
          ctx.stroke();
        };

        // Static Master Time tracker to sync waves seamlessly
        const absoluteTimeOffset = 1.0; 

        // 1. Draw the 3 columns x 4 rows matrix leads
        for (let r = 0; r < 3; r++) {
          for (let c = 0; c < 4; c++) {
            const leadName = leadMatrix[r][c];
            const startX = c * colWidth;
            const endX = startX + colWidth;
            const centerY = rowCenters[r];

            // Print Lead designation label text
            ctx.fillStyle = colors.labelColor;
            ctx.font = '900 11px font-mono, JetBrains Mono, monospace';
            ctx.fillText(leadName, startX + 25, centerY - rowHeight / 2.6);

            // Draw calibration key pulse at the left-most onset of each column segment
            drawCalibrationPulse(ctx, startX + 5, centerY);

            // Draw the physiological waveform across this 2.5-second time segment
            ctx.beginPath();
            ctx.strokeStyle = colors.traceLine;
            ctx.lineWidth = 1.7;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';

            // Each segment shows 2.5s of data. 2.5s = 62.5 small squares.
            // We start plotting wave after the calibration pulse segment (which takes ~5 small squares = colWidth * 0.08)
            const waveformOnsetX = startX + 35; // offset past calibration pulse
            
            let firstPoint = true;
            for (let px = waveformOnsetX; px < endX - 5; px += 0.75) {
              const relFraction = (px - startX) / colWidth; // fraction across this column [0, 1]
              const relTime = relFraction * 2.5; // relative time [0.0, 2.5] seconds
              const absoluteTime = c * 2.5 + relTime + absoluteTimeOffset; // continuous global sync clock

              // standard biological voltage values
              const volt = getPQRSTVoltage(leadName, absoluteTime, currentBpm);
              const drawY = centerY - (volt * gainPxPerMV);

              if (firstPoint) {
                ctx.moveTo(px, drawY);
                firstPoint = false;
              } else {
                ctx.lineTo(px, drawY);
              }
            }
            ctx.stroke();
          }
        }

        // 2. Draw Bottom Rhythm Strip (Continuous Lead II spanning across 10 full seconds)
        const rhythmCenterY = rowCenters[3];
        ctx.fillStyle = colors.labelColor;
        ctx.font = '900 11px font-mono, JetBrains Mono, monospace';
        ctx.fillText('RHYTHM STRIP II (II) // CONTINUOUS TELEMETRY 1x12', 25, rhythmCenterY - rowHeight / 2.8);

        // Calibration marker
        drawCalibrationPulse(ctx, 5, rhythmCenterY);

        ctx.beginPath();
        ctx.strokeStyle = colors.traceLine;
        ctx.lineWidth = 1.9;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        let firstPt = true;
        for (let px = 35; px < width - 10; px += 0.75) {
          const absoluteTimeFraction = px / width;
          const absoluteTime = absoluteTimeFraction * 10.0 + absoluteTimeOffset;

          const volt = getPQRSTVoltage('II', absoluteTime, currentBpm);
          const drawY = rhythmCenterY - (volt * gainPxPerMV);

          if (firstPt) {
            ctx.moveTo(px, drawY);
            firstPt = false;
          } else {
            ctx.lineTo(px, drawY);
          }
        }
        ctx.stroke();

      } else {
        // --- MODE B: REAL-TIME CONTINUOUS SCROLLING PATIENT TELEMETRY ---
        // Scroll speed and timing coordinates for rolling wave
        const timestamp = performance.now();
        if (lastTimeRef.current === 0) {
          lastTimeRef.current = timestamp;
          animationId = requestAnimationFrame(runRenderLoop);
          return;
        }

        const dt = (timestamp - lastTimeRef.current) / 1000;
        lastTimeRef.current = timestamp;

        // Custom sweeping grid speed scaling (150 pixels per active second)
        const scrollSpeed = 160;
        const pixelsToAdvance = dt * scrollSpeed;
        accumulatedPixelsRef.current += pixelsToAdvance;
        const timePerPixel = 1 / scrollSpeed;

        drawGrid(width, height, colors, 12); // smaller grid spacing for compact live wave
        const centerY = height / 2;

        // Resize state buffers dynamically
        if (pointsRef.current.length !== Math.floor(width)) {
          const targetLen = Math.floor(width);
          const currentPoints = [...pointsRef.current];
          if (currentPoints.length < targetLen) {
            while (currentPoints.length < targetLen) {
              currentPoints.push(centerY);
            }
          } else {
            currentPoints.length = targetLen;
          }
          pointsRef.current = currentPoints;
        }

        // Scroll buffer array
        while (accumulatedPixelsRef.current >= 1) {
          pointsRef.current.shift();

          let targetY = centerY;
          const hasRealLiveStream = Array.isArray(liveEcg) && liveEcg.length > 0;

          if (hasRealLiveStream) {
            // Real continuous stream passed from device
            let targetValue = latestEcgRef.current;
            if (sampleQueueRef.current.length > 0) {
              targetValue = sampleQueueRef.current.shift()!;
              latestEcgRef.current = targetValue;
            }

            if (smoothEcgRef.current === null) {
              smoothEcgRef.current = targetValue;
            } else {
              smoothEcgRef.current = smoothEcgRef.current * 0.72 + targetValue * 0.28;
            }

            if (baselineRef.current === null) {
              baselineRef.current = smoothEcgRef.current;
            } else {
              baselineRef.current = baselineRef.current * 0.993 + smoothEcgRef.current * 0.007;
            }

            const deviation = smoothEcgRef.current - baselineRef.current;
            let scaledDeviation = deviation * 0.5;

            // Cap severe signal artifacts gently
            if (scaledDeviation > 75) scaledDeviation = 75;
            if (scaledDeviation < -75) scaledDeviation = -75;

            targetY = centerY - scaledDeviation;
          } else {
            // Synchronized live-repeating synthesized wave matching Patient Status
            const activeVoltVal = getPQRSTVoltage('II', phaseRef.current * (60 / currentBpm), currentBpm);
            targetY = centerY - (activeVoltVal * gainPxPerMV * 0.8);

            const adjustedBeatIntervalSec = currentBpm > 0 ? 60 / currentBpm : 1.0;
            const adjustedPhaseIncrement = timePerPixel / adjustedBeatIntervalSec;

            phaseRef.current = (phaseRef.current + adjustedPhaseIncrement) % 1.0;
          }

          pointsRef.current.push(targetY);
          accumulatedPixelsRef.current -= 1;
        }

        // Draw real-time trace curve
        ctx.beginPath();
        ctx.strokeStyle = colors.traceLine;
        ctx.lineWidth = 2.4;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        for (let i = 0; i < pointsRef.current.length; i++) {
          if (i === 0) {
            ctx.moveTo(i, pointsRef.current[i]);
          } else {
            ctx.lineTo(i, pointsRef.current[i]);
          }
        }
        ctx.stroke();

        ctx.save();
        ctx.fillStyle = colors.labelColor;
        ctx.font = 'bold 9px font-mono, JetBrains Mono, monospace';
        ctx.fillText(`SWEEP SPEED: 25mm/s // TELEMETRY CHANNEL: LEAD II // FILTER: 0.5-40Hz`, 15, height - 12);
        
        ctx.font = 'bold 9px font-mono, JetBrains Mono, monospace';
        ctx.fillText(`LIVE BIOTELEMETRY STREAM | HR: ${currentBpm} BPM | SpO2: ${oxygenSaturation}%`, 15, 22);
        ctx.restore();

        animationId = requestAnimationFrame(runRenderLoop);
      }
    };

    if (activeMode === ECGMode.LIVE_TELEMETRY) {
      animationId = requestAnimationFrame(runRenderLoop);
    } else {
      runRenderLoop();
    }

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', setupCanvasScale);
    };
  }, [activeMode, gridTheme, paperSpeed, amplitudeGain, currentBpm, oxygenSaturation, liveEcg]);

  // Download crisp PNG snapshot of EKG Layout
  const handleExportPNG = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    try {
      const dataUrl = canvas.toDataURL("image/png");
      const tempLink = document.createElement("a");
      tempLink.href = dataUrl;
      tempLink.download = `heartsync_12ld_ecg_record_${currentBpm}bpm.png`;
      tempLink.click();
      setLiveLog("ECG Trace exported successfully!");
      setTimeout(() => setLiveLog(""), 3000);
    } catch (e) {
      console.error("Export canvas error:", e);
    }
  };

  const handlePrintECG = () => {
    window.print();
  };

  return (
    <div className="w-full h-full min-h-[220px] relative overflow-hidden bg-white rounded-2xl flex flex-col font-mono select-none">
      
      {/* Streamlined overlay header for Mode indicator and stats, floating elegantly */}
      <div className="absolute top-2 left-2 right-2 flex flex-wrap items-center justify-between gap-1 pointer-events-none z-10 select-none">
        
        {/* Patient and telemetry meta parameters (transparent backdrop blur tag) */}
        <div className="bg-slate-950/85 backdrop-blur-md text-white rounded-lg px-2 py-1 text-[9px] font-bold flex items-center gap-2 border border-white/10 pointer-events-auto shadow-md">
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-pulse" />
            <span className="text-rose-400 font-extrabold uppercase">
              {activeMode === ECGMode.DIAG_12_LEAD ? "12-Lead" : "Live II"}
            </span>
          </div>
          <span className="h-2 w-px bg-slate-800" />
          <span>HR: <strong className="text-emerald-400 font-extrabold">{currentBpm}</strong></span>
          <span className="h-2 w-px bg-slate-800" />
          <span>SpO2: <strong className="text-cyan-400 font-extrabold">{oxygenSaturation}%</strong></span>
        </div>

        {/* Floating Controls with background blur */}
        <div className="flex items-center gap-1.5 pointer-events-auto bg-slate-950/85 backdrop-blur-md rounded-lg p-0.5 border border-white/10 shadow-md">
          {/* Toggle Mode */}
          <button
            onClick={() => setActiveMode(activeMode === ECGMode.DIAG_12_LEAD ? ECGMode.LIVE_TELEMETRY : ECGMode.DIAG_12_LEAD)}
            className="px-1.5 py-0.5 text-[8px] uppercase font-black tracking-wide rounded hover:bg-slate-800 transition-colors text-rose-300 flex items-center gap-0.5 cursor-pointer"
            title="Toggle diagnostic 12-lead vs live channel II"
          >
            <Activity className="w-2.5 h-2.5 text-rose-400" />
            <span>{activeMode === ECGMode.DIAG_12_LEAD ? "Telemetry" : "12-Lead"}</span>
          </button>

          <span className="h-2 w-px bg-slate-800" />

          {/* Grid Selector */}
          <select
            value={gridTheme}
            onChange={(e) => setGridTheme(e.target.value as GridColorTheme)}
            className="bg-transparent text-slate-300 outline-none border-none py-0.5 px-0.5 font-black text-[8px] cursor-pointer"
          >
            <option value={GridColorTheme.CLINICAL_PINK} className="bg-slate-950 text-rose-400 text-[9px]">Pink Graph</option>
            <option value={GridColorTheme.CHARCOAL_GREY} className="bg-slate-950 text-slate-400 text-[9px]">Ivory Grid</option>
            <option value={GridColorTheme.ONXY_DARK} className="bg-slate-950 text-red-500 text-[9px]">Onyx Dark</option>
          </select>

          <span className="h-2 w-px bg-slate-800" />

          {/* Export Button */}
          <button
            onClick={handleExportPNG}
            className="p-1 hover:bg-slate-800 rounded transition-colors text-slate-300 cursor-pointer flex items-center justify-center"
            title="Export PNG Waveform"
          >
            <Download className="w-2.5 h-2.5" />
          </button>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="flex-1 w-full h-full overflow-hidden relative bg-white flex items-center justify-center">
        <canvas ref={canvasRef} className="block w-full h-full transition-opacity duration-300" />
        
        {/* Dynamic calibration overlays embedded on the graph */}
        <div className="absolute bottom-1 right-2 text-[7px] font-mono pointer-events-none opacity-45 select-none flex items-center gap-2" style={{ color: gridTheme === GridColorTheme.ONXY_DARK ? '#fca5a5' : '#be123c' }}>
          <span>SPEEC: 25 mm/s</span>
          <span>GAIN: {amplitudeGain} mm/mV</span>
          <span>NOTCH: 50Hz</span>
        </div>

        {/* Toast Log message */}
        {liveLog && (
          <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 bg-slate-950 text-white border border-white/10 rounded-lg px-2.5 py-1 shadow-md font-mono text-[8px] flex items-center gap-1 animate-bounce z-25">
            <Sparkles className="w-2.5 h-2.5 text-emerald-400" />
            <span>{liveLog}</span>
          </div>
        )}
      </div>

    </div>
  );
};

export default ECGGraph;

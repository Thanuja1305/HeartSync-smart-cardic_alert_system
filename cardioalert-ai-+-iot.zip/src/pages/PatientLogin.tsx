import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Heart, 
  Mail, 
  Lock, 
  ArrowRight, 
  Activity, 
  ShieldCheck, 
  Clock,
  Eye,
  EyeOff,
  Chrome,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { signInWithPopup, signInWithEmailAndPassword } from 'firebase/auth';
import { auth, googleProvider, db, handleFirestoreError, OperationType, parseFirestoreError } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

const PatientLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [errorIsEmailInUse, setErrorIsEmailInUse] = useState(false);
  const { showToast, user, profile, loading: authLoading, login, loginWithGoogle, resetPassword } = useAuth();
  const navigate = useNavigate();

  const [resetMode, setResetMode] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const handleSandboxBypass = async () => {
    setLoading(true);
    setError('');
    setErrorIsEmailInUse(false);
    try {
      const cleanPrefix = email.split('@')[0].replace(/[^a-zA-Z0-9]/g, '') || "patient_john";
      const sandboxEmail = `${cleanPrefix}_mock_pat_${Date.now().toString().slice(-4)}@heartsync.health`;
      const sandboxPassword = password || "123456";
      
      const { createUserWithEmailAndPassword, updateProfile } = await import('firebase/auth');
      const { auth } = await import('../lib/firebase');
      
      const userCredential = await createUserWithEmailAndPassword(auth, sandboxEmail, sandboxPassword);
      const loggedUser = userCredential.user;
      
      const patientName = email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1) || "Patient Name";
      await updateProfile(loggedUser, { displayName: patientName });
      
      setEmail(sandboxEmail);
      setPassword(sandboxPassword);
      
      showToast("Patient sandbox bypass activated successfully.", "success");
      
      const userRef = doc(db, 'users', loggedUser.uid);
      const newUser = {
        uid: loggedUser.uid,
        fullName: patientName,
        email: sandboxEmail,
        role: 'patient',
        status: 'approved',
        createdAt: serverTimestamp(),
        profileCompleted: false,
        onboardingCompleted: false,
        photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${loggedUser.uid}`
      };
      
      await setDoc(userRef, newUser, { merge: true });
      await setDoc(doc(db, 'patients', loggedUser.uid), {
        uid: loggedUser.uid,
        email: sandboxEmail,
        fullName: newUser.fullName,
        status: 'ACTIVE',
        createdAt: serverTimestamp()
      }, { merge: true });

      navigate('/patient/onboarding');
    } catch (err: any) {
      setError(err.message || "Sandbox Bypass session failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleDemoPreFill = () => {
    setEmail("patient.test@heartsync.health");
    setPassword("123456");
    setErrorIsEmailInUse(false);
    setError('');
    showToast("Standard patient credentials pre-loaded.", "success");
  };

  // Auto redirect if already logged in and profile is resolved with a role
  React.useEffect(() => {
    if (!authLoading && user && profile?.role) {
      if (profile.role === 'patient') {
        navigate('/patient/dashboard');
      } else if (profile.role === 'doctor') {
        navigate('/doctor/dashboard');
      } else if (profile.role === 'admin') {
        navigate('/admin');
      }
    }
  }, [user, profile, authLoading, navigate]);

  const handlePostAuth = async (authUser: any) => {
    if (!authUser) return;

    let retries = 3;
    let delay = 1000;

    const fetchProfile = async () => {
      try {
        const userRef = doc(db, 'users', authUser.uid);
        const userDoc = await getDoc(userRef);
        return { userDoc, userRef };
      } catch (err: any) {
        if (err.message?.includes('offline') && retries > 0) {
          retries--;
          await new Promise(r => setTimeout(r, delay));
          delay *= 2;
          return fetchProfile();
        }
        throw err;
      }
    };

    try {
      const { userDoc, userRef } = await fetchProfile();
      const userData = userDoc.exists() ? userDoc.data() : null;

      if (!userData || !userData.role) {
        // Create new user record
        const newUser = {
          uid: authUser.uid,
          fullName: authUser.displayName || 'Patient Name',
          email: authUser.email,
          role: 'patient',
          status: 'approved',
          createdAt: serverTimestamp(),
          profileCompleted: false,
          onboardingCompleted: false,
          photoURL: authUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${authUser.uid}`
        };
        
        await setDoc(userRef, newUser, { merge: true });
        await setDoc(doc(db, 'patients', authUser.uid), {
          uid: authUser.uid,
          email: authUser.email,
          fullName: newUser.fullName,
          status: 'ACTIVE',
          createdAt: serverTimestamp()
        }, { merge: true });

        navigate('/patient/onboarding');
        return;
      }

      if (userData.role === 'patient') {
        navigate('/patient/dashboard');
      } else if (userData.role === 'doctor') {
        showToast('This account is registered as a Cardiologist. Please use the Doctor Portal.', 'error');
        await auth.signOut();
      } else {
        navigate('/select-role');
      }
    } catch (err: any) {
      console.error('Error fetching role:', err);
      showToast('Authentication check failed', 'error');
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (resetMode) {
      handleResetPassword(e);
      return;
    }
    setLoading(true);
    setError('');
    setErrorIsEmailInUse(false);
    try {
      let loggedUser;
      try {
        loggedUser = await login(email, password);
      } catch (loginErr: any) {
        const isCredentialsError = 
          loginErr.message.toLowerCase().includes("credentials") || 
          loginErr.message.toLowerCase().includes("access denied") || 
          loginErr.message.toLowerCase().includes("not found");

        if (isCredentialsError) {
          console.info("Patient credentials not found. Executing automatic patient enrollment...");
          try {
            const { createUserWithEmailAndPassword, updateProfile } = await import('firebase/auth');
            const { auth } = await import('../lib/firebase');
            
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            loggedUser = userCredential.user;
            
            const patientName = email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1);
            await updateProfile(loggedUser, { displayName: patientName });
            
            showToast("Secure patient portal synchronized successfully.", "success");
          } catch (signupErr: any) {
            if (signupErr.code === 'auth/email-already-in-use') {
              setErrorIsEmailInUse(true);
              throw new Error("This email is already registered inside our Patient registry. Please double check your key, or click the Sandbox Bypass option below to sign in instantly.");
            } else if (signupErr.code === 'auth/weak-password') {
              throw new Error("Secret Key must be at least 6 characters long for security compliance.");
            } else {
              throw signupErr;
            }
          }
        } else {
          throw loginErr;
        }
      }

      if (loggedUser) {
        await handlePostAuth(loggedUser);
      }
    } catch (err: any) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError("Medical ID required for recovery.");
      return;
    }
    setLoading(true);
    setError('');
    try {
      await resetPassword(email);
      setResetSent(true);
      setTimeout(() => {
        setResetMode(false);
        setResetSent(false);
      }, 6000);
    } catch (err: any) {
      setError(err.message || "Recovery protocol failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    try {
      const loggedUser = await loginWithGoogle();
      if (loggedUser) {
        await handlePostAuth(loggedUser);
      }
    } catch (err: any) {
      setError(err.message || 'Google synchronization failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex overflow-hidden">
      <title>Patient Access | HeartSync</title>
      
      {/* LEFT SIDE: Medical Illustration & Animation */}
      <div className="hidden lg:flex lg:w-1/2 bg-slate-900 relative flex-col items-center justify-center p-12 overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent-maroon/20 rounded-full blur-[120px] animate-pulse" />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
          className="relative z-10 w-full max-w-lg"
        >
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-12 rounded-[64px] shadow-2xl relative overflow-hidden group">
            <div className="flex items-center gap-4 mb-12">
               <div className="p-3 bg-accent-maroon rounded-2xl">
                  <Heart className="w-8 h-8 text-white animate-pulse" />
               </div>
               <h1 className="text-3xl font-black text-white tracking-tighter">Sync</h1>
            </div>

            <h2 className="text-5xl font-black text-white leading-tight mb-8 tracking-tighter">
              Your health monitored <br />
              <span className="text-accent-maroon">in real-time.</span>
            </h2>

            <div className="h-24 bg-white/5 rounded-3xl border border-white/10 flex items-center justify-center p-8 mb-12 overflow-hidden">
               <svg width="100%" height="100%" viewBox="0 0 100 20" preserveAspectRatio="none">
                  <motion.path
                    d="M0 10 L10 10 L12 2 L14 18 L16 10 L25 10 L27 5 L29 15 L31 10 L40 10 L42 2 L44 18 L46 10 L55 10 L57 5 L59 15 L61 10 L70 10 L72 2 L74 18 L76 10 L85 10 L87 5 L89 15 L91 10 L100 10"
                    fill="none"
                    stroke="#FF0000"
                    strokeWidth="0.5"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1, x: [0, -50, 0] }}
                    transition={{ 
                      pathLength: { duration: 2, repeat: Infinity },
                      x: { duration: 10, repeat: Infinity, ease: "linear" }
                    }}
                  />
               </svg>
            </div>

            <div className="space-y-4 text-white/60">
               {[
                 { icon: ShieldCheck, text: "HIPAA Compliant Encrypted Data" },
                 { icon: Activity, text: "Live Biotelemetry Stream" },
                 { icon: Clock, text: "24/7 AI Cardiac Watchdog" }
               ].map((item, i) => (
                 <div key={i} className="flex items-center gap-3">
                    <item.icon className="w-5 h-5 text-accent-maroon" />
                    <span className="text-sm font-bold">{item.text}</span>
                 </div>
               ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* RIGHT SIDE: Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 md:p-20 bg-white">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="w-full max-w-md"
        >
          <div className="mb-12">
            <Link to="/" className="inline-flex items-center gap-2 mb-8 group">
               <div className="p-2 bg-accent-maroon/10 rounded-lg group-hover:bg-accent-maroon transition-colors">
                  <Heart className="w-5 h-5 text-accent-maroon group-hover:text-white" />
               </div>
               <span className="text-xl font-black text-slate-900 tracking-tighter">Sync</span>
            </Link>
            <h2 className="text-4xl font-black text-slate-900 tracking-tighter mb-4 italic">
              {resetMode ? "Identity Recovery" : "Patient Portal"}
            </h2>
            <p className="text-slate-500 font-bold">
              {resetMode 
                ? "Re-establish secure clinical access."
                : "Secure biometric access for monitoring."}
            </p>
          </div>

          {error && (
            <div className="mb-6 p-5 bg-red-50 border border-red-100 rounded-3xl flex flex-col gap-4 text-left">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                <p className="text-sm text-red-700 font-bold leading-relaxed">{error}</p>
              </div>
              {errorIsEmailInUse && (
                <div className="pt-4 border-t border-red-200/50 flex flex-col gap-3">
                  <p className="text-xs text-red-600 font-medium leading-relaxed uppercase tracking-tight">
                    💡 Node Bypass Activated:
                  </p>
                  <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                    The passcode provided is incorrect, but you can override and register a fresh sandbox patient medical record.
                  </p>
                  <button
                    type="button"
                    onClick={handleSandboxBypass}
                    className="w-full py-4.5 bg-accent-maroon hover:bg-opacity-90 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all shadow-xl shadow-accent-maroon/10"
                  >
                    ⚡ Secure Sandbox Bypass Login
                  </button>
                </div>
              )}
            </div>
          )}

          {resetSent && (
            <div className="mb-8 p-4 bg-green-50 border border-green-500/10 rounded-2xl flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
              <p className="text-xs font-bold text-green-600 leading-relaxed uppercase tracking-tight">
                Recovery protocol initiated. Check your primary medical mailbox.
              </p>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Medical ID (Email)</label>
              <div className="relative group">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-[24px] focus:ring-4 focus:ring-accent-maroon/5 focus:border-accent-maroon outline-none transition-all font-bold text-slate-900 placeholder:text-slate-300"
                  placeholder="patient@heartsync.health"
                  required
                />
                <Mail className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-accent-maroon transition-colors" />
              </div>
            </div>

            {!resetMode && (
              <div className="space-y-2">
                <div className="flex justify-between items-center px-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Secret Key</label>
                </div>
                <div className="relative group">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-[24px] focus:ring-4 focus:ring-accent-maroon/5 focus:border-accent-maroon outline-none transition-all font-bold text-slate-900 placeholder:text-slate-300"
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-900"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between px-1">
               <label className="flex items-center gap-3 cursor-pointer group">
                  <div className="relative w-5 h-5">
                    <input 
                      type="checkbox" 
                      className="peer hidden"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                    />
                    <div className="w-5 h-5 border-2 border-slate-200 rounded-lg peer-checked:bg-accent-maroon peer-checked:border-accent-maroon transition-all" />
                    <ShieldCheck className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 text-white opacity-0 peer-checked:opacity-100 transition-opacity" />
                  </div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Stay Secured</span>
               </label>
               <button 
                 type="button" 
                 onClick={() => setResetMode(!resetMode)}
                 className="text-[10px] font-black text-accent-maroon uppercase hover:underline"
               >
                 {resetMode ? "Return to Login" : "Revoke Key"}
               </button>
            </div>

            <button
              disabled={loading}
              className="w-full py-6 bg-accent-maroon text-white font-black rounded-[28px] shadow-2xl shadow-accent-maroon/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  {resetMode ? "Initialize Recovery" : "Access Dashboard"}
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 flex items-center gap-4 text-slate-200">
             <div className="h-px bg-slate-100 flex-1" />
             <span className="text-[10px] font-black tracking-[0.2em] uppercase">Connect With</span>
             <div className="h-px bg-slate-100 flex-1" />
          </div>

          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full mt-8 py-5 bg-white border border-slate-100 shadow-xl rounded-[28px] flex items-center justify-center gap-4 hover:bg-slate-50 transition-all font-black text-xs uppercase tracking-widest text-slate-900"
          >
            <Chrome className="w-5 h-5" /> Medical ID (Google)
          </button>

          {/* Clinical Sandbox Shortcut Panel */}
          <div className="mt-8 p-6 bg-slate-50 border border-slate-100 rounded-[28px] text-center flex flex-col gap-3">
             <span className="text-[10px] font-black text-slate-400 tracking-[0.2em] uppercase block">Developer Sandbox Controls</span>
             <p className="text-[11px] text-slate-500 font-semibold leading-normal">
               Testing the patient portal? Tap below to pre-fill verified patient credentials.
             </p>
             <button
               type="button"
               onClick={handleDemoPreFill}
               className="w-full py-4 bg-accent-maroon/10 hover:bg-accent-maroon/20 text-accent-maroon rounded-2xl font-black uppercase text-[10px] tracking-wider transition-all"
             >
               🚀 Pre-fill Patient Key
             </button>
          </div>

          <div className="mt-12 text-center">
            <p className="text-sm font-bold text-slate-400">
              New to HeartSync? <br />
              <Link to="/signup" className="text-accent-maroon hover:underline font-black uppercase tracking-widest text-xs mt-2 inline-block">Initialize Profile</Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default PatientLogin;

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Heart, 
  Mail, 
  Lock, 
  ArrowRight, 
  Activity, 
  ShieldCheck, 
  Stethoscope,
  Eye,
  EyeOff,
  Chrome,
  AlertCircle,
  Building2,
  Medal
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { auth, googleProvider, db } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

const DoctorLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [licenseId, setLicenseId] = useState('');
  const [hospital, setHospital] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [errorIsEmailInUse, setErrorIsEmailInUse] = useState(false);
  const { showToast, user, profile, loading: authLoading, login, loginWithGoogle, resetPassword } = useAuth();
  const navigate = useNavigate();

  const [resetMode, setResetMode] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const displayNameFromEmail = (rawEmail: string) => {
    const first = rawEmail.split('@')[0];
    return "Dr. " + first.charAt(0).toUpperCase() + first.slice(1);
  };

  const handleSandboxBypass = async () => {
    setLoading(true);
    setError('');
    setErrorIsEmailInUse(false);
    try {
      const cleanPrefix = email.split('@')[0].replace(/[^a-zA-Z0-9]/g, '') || "dr_john";
      const sandboxEmail = `${cleanPrefix}_mock_dr_${Date.now().toString().slice(-4)}@heartsync.health`;
      const sandboxPassword = password || "123456";
      
      const verifiedLicense = licenseId || "MD-9221";
      const verifiedHospital = hospital || "Apollo Hospitals";
      
      const userCredential = await createUserWithEmailAndPassword(auth, sandboxEmail, sandboxPassword);
      const loggedUser = userCredential.user;
      
      const drName = displayNameFromEmail(email) || "Dr. Srijareddy";
      await updateProfile(loggedUser, { displayName: drName });
      
      // Update variables so state matches the profile write
      setEmail(sandboxEmail);
      setPassword(sandboxPassword);
      setLicenseId(verifiedLicense);
      setHospital(verifiedHospital);
      
      showToast("Clinical sandbox bypass activated successfully.", "success");
      
      const userRef = doc(db, 'users', loggedUser.uid);
      const newUser = {
        uid: loggedUser.uid,
        fullName: drName,
        email: sandboxEmail,
        role: 'doctor',
        createdAt: serverTimestamp(),
        profileCompleted: false,
        photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${loggedUser.uid}`,
        medicalLicenseId: verifiedLicense,
        hospitalName: verifiedHospital
      };
      
      await setDoc(userRef, newUser, { merge: true });
      await setDoc(doc(db, 'doctors', loggedUser.uid), {
        uid: loggedUser.uid,
        email: sandboxEmail,
        fullName: newUser.fullName,
        verified: false,
        status: 'PENDING_VERIFICATION',
        createdAt: serverTimestamp()
      }, { merge: true });

      navigate('/doctor/registration');
    } catch (err: any) {
      setError(err.message || "Sandbox Bypass session failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleDemoPreFill = () => {
    setEmail("srijareddy456@gmail.com");
    setPassword("123456");
    setLicenseId("MD-9221");
    setHospital("Apollo Hospitals");
    setErrorIsEmailInUse(false);
    setError('');
    showToast("Professional clinical pre-fill keys loaded.", "success");
  };

  // Auto redirect if already logged in and profile is resolved with a role
  React.useEffect(() => {
    if (!authLoading && user && profile?.role) {
      if (profile.role === 'doctor') {
        navigate('/doctor/dashboard');
      } else if (profile.role === 'patient') {
        navigate('/patient/dashboard');
      } else if (profile.role === 'admin') {
        navigate('/admin');
      }
    }
  }, [user, profile, authLoading, navigate]);

  const handlePostAuth = async (authUser: any) => {
    if (!authUser) return;
    try {
      const userRef = doc(db, 'users', authUser.uid);
      const userDoc = await getDoc(userRef);
      const userData = userDoc.exists() ? userDoc.data() : null;

      if (!userData || !userData.role) {
        const newUser = {
          uid: authUser.uid,
          fullName: authUser.displayName || 'Doctor Name',
          email: authUser.email,
          role: 'doctor',
          createdAt: serverTimestamp(),
          profileCompleted: false,
          photoURL: authUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${authUser.uid}`,
          medicalLicenseId: licenseId,
          hospitalName: hospital
        };
        
        await setDoc(userRef, newUser, { merge: true });
        await setDoc(doc(db, 'doctors', authUser.uid), {
          uid: authUser.uid,
          email: authUser.email,
          fullName: newUser.fullName,
          verified: false,
          status: 'PENDING_VERIFICATION',
          createdAt: serverTimestamp()
        }, { merge: true });

        navigate('/doctor/registration');
        return;
      }

      if (userData.role === 'doctor') {
        navigate('/doctor/dashboard');
      } else {
        showToast('This account is registered as a Patient. Please use the Patient Portal.', 'error');
        await auth.signOut();
      }
    } catch (err: any) {
      showToast('Clinical access verification failed', 'error');
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (resetMode) {
      handleResetPassword(e);
      return;
    }
    setLoading(true);
    setError('');
    setErrorIsEmailInUse(false);
    try {
      let loggedUser;
      try {
        loggedUser = await login(email, password);
      } catch (loginErr: any) {
        const isCredentialsError = 
          loginErr.message.toLowerCase().includes("credentials") || 
          loginErr.message.toLowerCase().includes("access denied") || 
          loginErr.message.toLowerCase().includes("not found");

        if (isCredentialsError) {
          console.info("Doctor credentials not found. Executing automatic clinical enrollment...");
          try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            loggedUser = userCredential.user;
            
            const drName = `Dr. ${email.split('@')[0]}`;
            await updateProfile(loggedUser, { displayName: drName });
            
            showToast("Institutional registration verified successfully.", "success");
          } catch (signupErr: any) {
            if (signupErr.code === 'auth/email-already-in-use') {
              setErrorIsEmailInUse(true);
              throw new Error("This institutional email is already registered inside our biotelemetry node. Please double check your key, or click the Sandbox Bypass option below to sign in instantly.");
            } else if (signupErr.code === 'auth/weak-password') {
              throw new Error("Cloud Key must be at least 6 characters long for security compliance.");
            } else {
              throw signupErr;
            }
          }
        } else {
          throw loginErr;
        }
      }

      if (loggedUser) {
        await handlePostAuth(loggedUser);
      }
    } catch (err: any) {
      setError(err.message || 'Access denied');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError("Institutional Email required for recovery.");
      return;
    }
    setLoading(true);
    setError('');
    try {
      await resetPassword(email);
      setResetSent(true);
      setTimeout(() => {
        setResetMode(false);
        setResetSent(false);
      }, 6000);
    } catch (err: any) {
      setError(err.message || "Recovery link generation failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    try {
      const loggedUser = await loginWithGoogle();
      if (loggedUser) {
        await handlePostAuth(loggedUser);
      }
    } catch (err: any) {
      setError(err.message || 'Clinical SSO failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex overflow-hidden">
      <title>Doctor Access | HeartSync</title>
      
      {/* LEFT SIDE: Clinical Command Center Illustration */}
      <div className="hidden lg:flex lg:w-1/2 bg-[#071226] relative flex-col items-center justify-center p-12 overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'linear-gradient(#0a1f44 2px, transparent 2px), linear-gradient(90deg, #0a1f44 2px, transparent 2px)', backgroundSize: '50px 50px' }} />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
          className="relative z-10 w-full max-w-lg"
        >
          <div className="bg-white/5 backdrop-blur-2xl border border-white/10 p-12 rounded-[64px] shadow-2xl relative overflow-hidden group">
            <div className="flex items-center gap-4 mb-12">
               <div className="p-3 bg-accent-maroon rounded-2xl">
                  <Heart className="w-8 h-8 text-white" />
               </div>
               <h1 className="text-3xl font-black text-white tracking-tighter">Sync MD</h1>
            </div>

            <h2 className="text-5xl font-black text-white leading-tight mb-8 tracking-tighter">
              Advanced Cardiac <br />
              <span className="text-accent-maroon text-4xl">Command Center.</span>
            </h2>

            {/* Emergency UI Animation */}
            <div className="bg-black/40 rounded-3xl border border-white/5 p-6 mb-12">
               <div className="flex items-center justify-between mb-4">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    <div className="w-2 h-2 rounded-full bg-slate-700" />
                  </div>
                  <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">Incoming Emergency</span>
               </div>
               <div className="space-y-3">
                  <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                    <motion.div 
                      animate={{ x: ['-100%', '100%'] }}
                      transition={{ duration: 3, repeat: Infinity }}
                      className="w-1/2 h-full bg-accent-maroon/20" 
                    />
                  </div>
                  <div className="flex justify-between items-center bg-white/5 p-3 rounded-xl border border-white/5">
                     <span className="text-[9px] font-bold text-white/40">ECG VERIFICATION</span>
                     <Activity className="w-3 h-3 text-accent-maroon animate-pulse" />
                  </div>
               </div>
            </div>

            <div className="space-y-4 text-white/40">
               {[
                 { icon: Building2, text: "Institutional Grade Infrastructure" },
                 { icon: Medal, text: "Board Certified Verification Node" },
                 { icon: ShieldCheck, text: "Ultra-Secure Clinical Tunneling" }
               ].map((item, i) => (
                 <div key={i} className="flex items-center gap-3">
                    <item.icon className="w-5 h-5 text-accent-maroon" />
                    <span className="text-sm font-bold">{item.text}</span>
                 </div>
               ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* RIGHT SIDE: Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 md:p-20 bg-white">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="w-full max-w-md"
        >
          <div className="mb-12">
            <Link to="/" className="inline-flex items-center gap-2 mb-8 group">
               <div className="p-2 bg-accent-maroon/10 rounded-lg group-hover:bg-accent-maroon transition-colors">
                  <Heart className="w-5 h-5 text-accent-maroon group-hover:text-white" />
               </div>
               <span className="text-xl font-black text-slate-900 tracking-tighter">Sync</span>
            </Link>
            <h2 className="text-4xl font-black text-slate-900 tracking-tighter mb-4 italic uppercase">
              {resetMode ? "Session Recovery" : "Doctor Portal"}
            </h2>
            <p className="text-slate-500 font-bold uppercase text-[10px] tracking-widest">
              {resetMode 
                ? "Re-authorize clinical node access."
                : "Medical Professional Verified Sign-In"}
            </p>
          </div>

          {error && (
            <div className="mb-6 p-5 bg-red-50 border border-red-100 rounded-3xl flex flex-col gap-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                <p className="text-sm text-red-700 font-bold leading-relaxed">{error}</p>
              </div>
              {errorIsEmailInUse && (
                <div className="pt-4 border-t border-red-200/50 flex flex-col gap-3">
                  <p className="text-xs text-red-600 font-medium leading-relaxed uppercase tracking-tight">
                    💡 Node Bypass Activated:
                  </p>
                  <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                    The Cloud Key provided is incorrect, but you can override and register a fresh sandbox clinical channel.
                  </p>
                  <button
                    type="button"
                    onClick={handleSandboxBypass}
                    className="w-full py-4 bg-[#071226] hover:bg-slate-900 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all shadow-xl shadow-slate-900/10"
                  >
                    ⚡ Secure Sandbox Bypass Login
                  </button>
                </div>
              )}
            </div>
          )}

          {resetSent && (
            <div className="mb-8 p-4 bg-green-50 border border-green-500/10 rounded-2xl flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
              <p className="text-xs font-bold text-green-600 leading-relaxed uppercase tracking-tight text-left">
                Recovery link dispatched. Check institutional archives.
              </p>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-6">
            {!resetMode && (
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">License ID</label>
                  <div className="relative group">
                    <input
                      type="text"
                      value={licenseId}
                      onChange={(e) => setLicenseId(e.target.value)}
                      className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-[24px] focus:ring-4 focus:ring-accent-maroon/5 focus:border-accent-maroon outline-none transition-all font-bold text-slate-900 placeholder:text-slate-300"
                      placeholder="MD-9921"
                      required
                    />
                    <Medal className="absolute right-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 group-focus-within:text-accent-maroon transition-colors" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Hospital</label>
                  <div className="relative group">
                    <input
                      list="hospitals"
                      value={hospital}
                      onChange={(e) => setHospital(e.target.value)}
                      className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-[24px] focus:ring-4 focus:ring-accent-maroon/5 focus:border-accent-maroon outline-none transition-all font-bold text-slate-900 placeholder:text-slate-300"
                      placeholder="e.g. Apollo"
                      required
                    />
                    <datalist id="hospitals">
                      <option value="Apollo Hospitals" />
                      <option value="Fortis Healthcare" />
                      <option value="Max Medical" />
                      <option value="AIIMS" />
                      <option value="Lilavati Hospital" />
                      <option value="Medanta" />
                      <option value="Kokilaben Dhirubhai Ambani Hospital" />
                      <option value="Private Clinic" />
                    </datalist>
                    <Building2 className="absolute right-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 group-focus-within:text-accent-maroon transition-colors" />
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{resetMode ? "Medical ID" : "Work Email (Institutional)"}</label>
              <div className="relative group">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-[24px] focus:ring-4 focus:ring-accent-maroon/5 focus:border-accent-maroon outline-none transition-all font-bold text-slate-900 placeholder:text-slate-300"
                  placeholder="dr.name@hospital.com"
                  required
                />
                <Mail className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-accent-maroon transition-colors" />
              </div>
            </div>

            {!resetMode && (
              <div className="space-y-2">
                <div className="flex justify-between items-center px-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cloud Key</label>
                  <button 
                    type="button" 
                    onClick={() => setResetMode(true)}
                    className="text-[10px] font-black text-accent-maroon uppercase hover:underline"
                  >
                    Forgot Access
                  </button>
                </div>
                <div className="relative group">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-[24px] focus:ring-4 focus:ring-accent-maroon/5 focus:border-accent-maroon outline-none transition-all font-bold text-slate-900 placeholder:text-slate-300"
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-900"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            )}

            {resetMode && (
              <div className="flex justify-end px-1">
                <button 
                  type="button" 
                  onClick={() => setResetMode(false)}
                  className="text-[10px] font-black text-slate-400 hover:text-slate-900 uppercase tracking-widest transition-colors"
                >
                  Return to Portal Login
                </button>
              </div>
            )}

            <button
              disabled={loading}
              className="w-full py-6 bg-[#071226] text-white font-black rounded-[28px] shadow-2xl shadow-indigo-900/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  {resetMode ? "Dispatch Recovery Protocol" : "Authorize Session"}
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 flex items-center gap-4 text-slate-200">
             <div className="h-px bg-slate-100 flex-1" />
             <span className="text-[10px] font-black tracking-[0.2em] uppercase">Security Standard</span>
             <div className="h-px bg-slate-100 flex-1" />
          </div>

          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full mt-8 py-5 bg-white border border-slate-100 shadow-xl rounded-[28px] flex items-center justify-center gap-4 hover:bg-slate-50 transition-all font-black text-xs uppercase tracking-widest text-slate-900"
          >
            <Chrome className="w-5 h-5" /> Institutional SSO (MD ID)
          </button>

          {/* Clinical Sandbox Shortcut Panel */}
          <div className="mt-8 p-6 bg-slate-50 border border-slate-100 rounded-[28px] text-center flex flex-col gap-3">
             <span className="text-[10px] font-black text-slate-400 tracking-[0.2em] uppercase block">Developer Sandbox Controls</span>
             <p className="text-[11px] text-slate-500 font-semibold leading-normal">
               Testing the application? Tap below to pre-fill verified credentials.
             </p>
             <button
               type="button"
               onClick={handleDemoPreFill}
               className="w-full py-4 bg-accent-maroon/10 hover:bg-accent-maroon/20 text-accent-maroon rounded-2xl font-black uppercase text-[10px] tracking-wider transition-all"
             >
               🚀 Pre-fill Verified Credentials
             </button>
          </div>

          <div className="mt-12 text-center border-t border-slate-50 pt-8">
            <p className="text-sm font-bold text-slate-400">
              New medical practitioner? <br />
              <Link to="/signup" className="text-accent-maroon hover:underline font-black uppercase tracking-widest text-xs mt-2 inline-block">Register Board Account</Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default DoctorLogin;

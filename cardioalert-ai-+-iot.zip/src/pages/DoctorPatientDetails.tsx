import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Heart, 
  Activity, 
  MapPin, 
  Phone, 
  ShieldAlert, 
  History,
  Thermometer,
  Droplets,
  HeartPulse,
  Navigation,
  ExternalLink,
  Plus,
  Menu,
  Sparkles,
  AlertCircle,
  Search,
  ArrowRight,
  ChevronRight,
  X,
  FileDown
} from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { db, rtdb } from '../lib/firebase';
import { doc, onSnapshot, collection, query, where } from 'firebase/firestore';
import { ref, onValue } from 'firebase/database';
import DoctorSidebar from '../components/DoctorSidebar';
import ECGGraph from '../components/patient/ECGGraph';
import { useAlertEscalation } from '../hooks/useAlertEscalation';
import { generateVitalsPDF } from '../utils/pdfGenerator';

const DoctorPatientDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [patient, setPatient] = useState<any>(null);
  const [vitals, setVitals] = useState<any>(null);
  const [patientProfile, setPatientProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [patients, setPatients] = useState<any[]>([]);
  const [vitalsMap, setVitalsMap] = useState<Record<string, any>>({});

  const [isLocalEmergencyPopupVisible, setIsLocalEmergencyPopupVisible] = useState(false);
  const [whatsAppStatus, setWhatsAppStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [isAmbulanceCalling, setIsAmbulanceCalling] = useState(false);
  const [showDetailedReport, setShowDetailedReport] = useState(false);

  const reportSectionRef = React.useRef<HTMLDivElement | null>(null);

  // Web Audio Context Siren references
  const localSirenIntervalRef = React.useRef<any>(null);
  const localAudioCtxRef = React.useRef<AudioContext | null>(null);

  const startLocalSiren = () => {
    if (localSirenIntervalRef.current) return;
    try {
      if (!localAudioCtxRef.current) {
        localAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = localAudioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      let waveState = false;
      localSirenIntervalRef.current = setInterval(() => {
        if (!ctx || ctx.state === 'suspended') return;
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();

        osc.type = 'sawtooth';
        const targetFreq = waveState ? 990 : 660;
        osc.frequency.setValueAtTime(targetFreq, ctx.currentTime);
        
        gainNode.gain.setValueAtTime(0, ctx.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.1, ctx.currentTime + 0.05);
        gainNode.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.4);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.48);

        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
        waveState = !waveState;
      }, 500);
    } catch (e) {
      console.warn("Local siren playback initial friction:", e);
    }
  };

  const stopLocalSiren = () => {
    if (localSirenIntervalRef.current) {
      clearInterval(localSirenIntervalRef.current);
      localSirenIntervalRef.current = null;
    }
  };

  // Turn off local siren on unmount
  useEffect(() => {
    return () => {
      stopLocalSiren();
    };
  }, []);

  // Connect Real-Time Clinical Alert Triage & Escalation Engine
  const {
    vitals: escalationVitals,
    alertSeverity,
    clinicalReport,
    isAcknowledged,
    muteAudio,
    setMuteAudio,
    onMarkAsFalseAlert,
    onTriggerEmergencyAlert
  } = useAlertEscalation(id, patient?.displayName || "Patient Node");

  const handleLocalTriggerEmergency = async () => {
    // 1. Play emergency siren
    startLocalSiren();

    // 2. Open emergency popup
    setIsLocalEmergencyPopupVisible(true);

    // 3. Automatically trigger Twilio WhatsApp to Family & Ambulance
    setWhatsAppStatus('sending');
    try {
      const response = await fetch('/api/send-emergency-whatsapp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: id,
          patientName: patient?.displayName || "John Doe",
          heartRate: vitals?.heartRate || escalationVitals?.bpm || 42,
          spo2: vitals?.o2 || escalationVitals?.spo2 || 82,
          temp: vitals?.temp || escalationVitals?.temperature || 39,
          status: 'HIGH RISK'
        })
      });
      const data = await response.json();
      if (data.success) {
        setWhatsAppStatus('sent');
      } else {
        setWhatsAppStatus('error');
      }
    } catch (error) {
      console.error("Failed to send WhatsApp alert:", error);
      setWhatsAppStatus('error');
    }
  };

  const handleLocalCallAmbulance = async () => {
    setIsAmbulanceCalling(true);
    try {
      const response = await fetch('/api/trigger-ambulance-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: id,
          patientName: patient?.displayName || "John Doe"
        })
      });
      const data = await response.json();
      if (data.success) {
        alert("Twilio Voice Call dispatch to Ambulance Initiated Successfully! (Dialing 9573732216)");
      } else {
        alert("Failed to initiate Twilio ambulance call: " + (data.error || "Unknown Error"));
      }
    } catch (error) {
      console.error("Ambulance calling dispatch failed:", error);
    } finally {
      setIsAmbulanceCalling(false);
    }
  };

  const handleLocalFalseAlarm = async () => {
    // Stop Siren
    stopLocalSiren();
    // Close Popup
    setIsLocalEmergencyPopupVisible(false);
    // Mark Resolved in Database
    await onMarkAsFalseAlert();
    // Tell backend to allow subsequent sends for this patient if a new emergency occurs
    try {
      await fetch('/api/reset-emergency-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ patientId: id })
      });
    } catch (e) {
      console.warn("Reset state sync failed:", e);
    }
    // Set WhatsApp back to idle for subsequent alerts
    setWhatsAppStatus('idle');
  };

  const handleLocalViewReport = () => {
    // Stop Siren
    stopLocalSiren();
    // Open detailed report below
    setShowDetailedReport(true);
    // Close modal popup
    setIsLocalEmergencyPopupVisible(false);

    // Smooth scroll down to AI findings
    setTimeout(() => {
      reportSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleDownloadSnapshot = () => {
    const patientDataInfo = {
      name: patient?.displayName || patientProfile?.fullName || 'John Doe',
      age: String(patientProfile?.age || patient?.age || '54'),
      gender: patientProfile?.gender || patient?.gender || 'Male',
      bloodGroup: patientProfile?.bloodGroup || 'O+',
      phoneNumber: patientProfile?.phoneNumber || '+91 95737 32216',
      condition: patientProfile?.condition || patient?.condition || "Post-Myocardial Infarction Telemetry"
    };

    const heartRateVal = vitals?.heartRate !== undefined ? vitals.heartRate : (escalationVitals?.bpm !== undefined ? escalationVitals.bpm : 72);
    const o2Val = vitals?.o2 !== undefined ? vitals.o2 : (escalationVitals?.spo2 !== undefined ? escalationVitals.spo2 : 98);
    const tempVal = vitals?.temp !== undefined ? vitals.temp : (escalationVitals?.temperature !== undefined ? escalationVitals.temperature : 36.5);
    const humidityVal = vitals?.humidity !== undefined ? vitals.humidity : 55;

    const snapshotVitals = {
      heartRate: heartRateVal,
      o2: o2Val,
      temp: tempVal,
      humidity: humidityVal,
      status: alertSeverity.level >= 3 ? 'CRITICAL' : alertSeverity.level === 2 ? 'WARNING' : 'OPTIMAL',
      ecgCondition: clinicalReport?.ecgCondition || 'Sinus Rhythm within acceptable segments',
      anomalyDetected: clinicalReport?.possibleIssue || 'No diagnostic ST spikes recorded during current sweep.',
      recommendations: clinicalReport?.recommendation || 'Continuous biotelemetry tracking advised. Verify user lead contacts.'
    };

    generateVitalsPDF(patientDataInfo, snapshotVitals);
  };

  useEffect(() => {
    if (!id) return;

    // Fetch base user data
    const unsubUser = onSnapshot(doc(db, 'users', id), (snap) => {
      if (snap.exists()) {
        setPatient((prev: any) => ({
          ...prev,
          ...snap.data()
        }));
      }
    });

    // Fetch detailed patient profile
    const unsubProfile = onSnapshot(doc(db, 'patients', id), (snap) => {
      if (snap.exists()) {
        setPatientProfile((prev: any) => ({
          ...prev,
          ...snap.data()
        }));
      }
    });

    // Fetch other patients for the Clinical Registry panel
    const qPatients = query(
      collection(db, 'users'),
      where('role', '==', 'patient'),
      where('status', '==', 'approved')
    );
    const unsubPatients = onSnapshot(qPatients, (snap) => {
      setPatients(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Real-time listener for all patient live metrics
    const unsubAllVitals = onSnapshot(collection(db, 'liveHealthMetrics'), (snap) => {
      const metrics: Record<string, any> = {};
      snap.forEach(docSnap => {
        metrics[docSnap.id] = docSnap.data();
      });
      setVitalsMap(metrics);
    });

    // RTDB Patient profile listener
    const patientRef = ref(rtdb, `/users/${id}`);
    const unsubPatientRTDB = onValue(patientRef, (snapshot) => {
      const data = snapshot.val();
      if (snapshot.exists() && data) {
        setPatient((prev: any) => ({
          ...prev,
          displayName: data.name || data.fullName || (prev ? prev.displayName : 'Patient'),
          email: data.email || (prev ? prev.email : ''),
          age: data.age !== undefined ? String(data.age) : (prev ? prev.age : ''),
          gender: data.gender || (prev ? prev.gender : '')
        }));

        setPatientProfile((prev: any) => ({
          ...prev,
          age: data.age !== undefined ? String(data.age) : (prev ? prev.age : ''),
          gender: data.gender || (prev ? prev.gender : ''),
          bloodGroup: data.bloodGroup || (prev ? prev.bloodGroup : ''),
          condition: data.condition || (prev ? prev.condition : ''),
          email: data.email || (prev ? prev.email : '')
        }));
      }
    }, (err) => {
      console.error("RTDB patient profile error:", err);
    });

    // RTDB Live Reading listener (supporting both liveReading and livereading paths)
    const liveReadingRef = ref(rtdb, `/users/${id}/liveReading`);
    const livereadingRef = ref(rtdb, `/users/${id}/livereading`);
    
    let latestLiveReading: any = null;
    let latestLivereading: any = null;

    const processLiveVitals = (data: any) => {
      if (!data) return;
      const rawHr = data.BPM !== undefined ? Number(data.BPM) : (data.bpm !== undefined ? Number(data.bpm) : (data.heartRate !== undefined ? Number(data.heartRate) : (data.HeartRate !== undefined ? Number(data.HeartRate) : 0)));
      const rawO2 = data.SpO2 !== undefined ? Number(String(data.SpO2).replace('%', '')) : (data.spo2 !== undefined ? Number(data.spo2) : (data.SPO2 !== undefined ? Number(data.SPO2) : (data.o2 !== undefined ? Number(data.o2) : 0)));
      const rawTemp = data.Temp !== undefined ? Number(String(data.Temp).replace(/[CF\s]/gi, '')) : (data.temperature !== undefined ? Number(data.temperature) : (data.temp !== undefined ? Number(data.temp) : (data.Temperature !== undefined ? Number(data.Temperature) : 0)));
      const rawHum = data.Humidity !== undefined ? Number(String(data.Humidity).replace('%', '')) : (data.humidity !== undefined ? Number(data.humidity) : 0);
      
      const hrValue = Math.round(rawHr);
      const o2Value = Math.round(rawO2);
      const tempValue = Number(rawTemp.toFixed(1));
      const humValue = Math.round(rawHum);

      let ecgValue: number | number[] | string = 0;
      const rawEcg = data.ECG !== undefined ? data.ECG : (data.ecg !== undefined ? data.ecg : undefined);
      if (rawEcg !== undefined) {
        if (Array.isArray(rawEcg)) {
          ecgValue = rawEcg.map(Number).filter(v => !isNaN(v));
        } else if (typeof rawEcg === 'string') {
          ecgValue = rawEcg;
        } else {
          ecgValue = isNaN(Number(rawEcg)) ? 0 : Number(rawEcg);
        }
      }

      setVitals((prev: any) => ({
        ...prev,
        heartRate: hrValue,
        o2: o2Value,
        temp: tempValue,
        humidity: humValue,
        ecg: ecgValue,
        isEmergency: data.alertLevel === 3 || data.isEmergency === true || hrValue > 110,
        status: data.alertLevel === 3 ? 'critical' : data.alertLevel === 2 ? 'warning' : 'optimal'
      }));
      setLoading(false);
    };

    const unsubLiveReadingRTDB = onValue(liveReadingRef, (snapshot) => {
      latestLiveReading = snapshot.val();
      if (latestLiveReading) {
        processLiveVitals(latestLiveReading);
      } else if (latestLivereading) {
        processLiveVitals(latestLivereading);
      }
    }, (err) => {
      console.error("RTDB liveReading error:", err);
    });

    const unsubLivereadingRTDB = onValue(livereadingRef, (snapshot) => {
      latestLivereading = snapshot.val();
      if (latestLivereading) {
        processLiveVitals(latestLivereading);
      } else if (latestLiveReading) {
        processLiveVitals(latestLiveReading);
      }
    }, (err) => {
      console.error("RTDB livereading error:", err);
    });

    return () => {
      unsubUser();
      unsubProfile();
      unsubPatients();
      unsubAllVitals();
      unsubPatientRTDB();
      unsubLiveReadingRTDB();
    };
  }, [id]);

  if (loading && !patient) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-slate-100 border-t-accent-maroon rounded-full animate-spin" />
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">Bridging Clinical Port...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex overflow-hidden">
      <title>Patient Assessment Map | HeartSync Physician</title>
      <DoctorSidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />
      
      {/* MOBILE OVERLAY */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[80] lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* THREE PANEL STRUCTURE container */}
      <div className="flex-1 flex overflow-hidden min-h-screen lg:h-screen bg-slate-100 font-sans">
        
        {/* PANEL 1: CLINICAL REGISTRY (MIDDLE INDEX PANEL) */}
        <aside className="hidden lg:flex flex-col w-[360px] bg-white border-r border-slate-200 shrink-0 h-full overflow-y-auto no-scrollbar">
           <div className="p-6 border-b border-slate-100 space-y-4">
              <div>
                 <h2 className="text-xl font-black text-slate-900 tracking-tight italic">Clinical Registry</h2>
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mt-1">Real-time Telemetry Processing</p>
              </div>
              
              {/* Search box */}
              <div className="relative">
                 <input 
                   type="text" 
                   placeholder="Search patients..." 
                   value={searchQuery}
                   onChange={(e) => setSearchQuery(e.target.value)}
                   className="w-full bg-slate-50 border border-slate-100 rounded-xl py-2.5 pl-10 pr-4 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-accent-maroon/20 focus:bg-white transition-all text-slate-900"
                 />
                 <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3.5 top-3" />
              </div>
           </div>

           <div className="p-6 space-y-6">
              {/* EMERGENCIES INDICATOR MAPPING (RED CARD) */}
              {(() => {
                 const isThisPatientEmergency = vitals?.isEmergency || alertSeverity.level >= 3;
                 if (isThisPatientEmergency) {
                    return (
                       <div className="bg-red-50 border border-red-100 rounded-[24px] p-5 space-y-4 shadow-sm animate-pulse">
                          <div className="flex items-center gap-3 text-red-700">
                             <AlertCircle className="w-5 h-5 animate-bounce shrink-0" />
                             <div>
                                <p className="text-[10px] font-black uppercase tracking-wider">EMERGENCY</p>
                                <p className="text-xs font-black">Critical patient detected</p>
                             </div>
                          </div>

                          <div className="bg-white p-4 rounded-xl flex items-center justify-between shadow-sm border border-red-100/30">
                             <div className="flex items-center gap-3 min-w-0">
                                <div className="w-10 h-10 bg-slate-900 rounded-lg flex items-center justify-center text-white shrink-0 font-black overflow-hidden select-none">
                                   {patient?.photoURL ? <img src={patient.photoURL} alt="" className="w-full h-full object-cover" /> : patient?.displayName?.charAt(0) || 'P'}
                                </div>
                                <div className="truncate">
                                   <p className="font-extrabold text-slate-900 text-xs truncate leading-tight">{patient?.displayName || "Active Patient"}</p>
                                   <p className="text-[8px] font-black text-slate-400 leading-none mt-1 uppercase">ID: {id?.slice(0, 8).toUpperCase()}</p>
                                </div>
                             </div>
                             <span className="bg-accent-maroon text-white text-[8px] font-black px-2 py-0.5 rounded uppercase font-sans shrink-0">CRITICAL</span>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-[10px] bg-white/40 p-3 rounded-xl border border-red-100/20">
                             <div>
                                <span className="text-slate-400 uppercase font-bold text-[8px] block leading-none mb-1">Heart Rate</span>
                                <span className="font-extrabold text-red-600 text-xs italic">{(vitals?.heartRate !== undefined && vitals?.heartRate !== null) ? vitals.heartRate : (escalationVitals?.bpm !== undefined && escalationVitals?.bpm !== null ? escalationVitals.bpm : '0')} BPM</span>
                             </div>
                             <div>
                                <span className="text-slate-400 uppercase font-bold text-[8px] block leading-none mb-1">Blood Oxygen</span>
                                <span className="font-extrabold text-red-600 text-xs italic">{(vitals?.o2 !== undefined && vitals?.o2 !== null) ? vitals.o2 : (escalationVitals?.spo2 !== undefined && escalationVitals?.spo2 !== null ? escalationVitals.spo2 : '0')}%</span>
                             </div>
                          </div>

                          <button 
                            onClick={() => navigate(`/doctor/patient/${id}`)}
                            className="w-full py-2.5 bg-[#800020] hover:bg-accent-maroon text-white rounded-xl text-[9px] font-extrabold uppercase tracking-widest text-center transition-all flex items-center justify-center gap-1 shadow-md shadow-accent-maroon/20"
                          >
                             View Report <ArrowRight className="w-3 h-3" />
                          </button>
                       </div>
                    );
                 }
                 return null;
              })()}

              {/* OTHER MONITORED NODES SECTION */}
              <div className="space-y-4">
                 <h4 className="text-[9px] font-black text-slate-300 uppercase tracking-widest leading-none">Other Monitored Patients</h4>
                 <div className="space-y-3">
                    {patients.length > 0 ? (
                      patients
                        .filter(p => p.id !== id)
                        .filter(p => !searchQuery || p.displayName?.toLowerCase().includes(searchQuery.toLowerCase()))
                        .map((otherP) => {
                          const otherMetrics = vitalsMap[otherP.id];
                          const otherIsEmergency = otherMetrics?.isEmergency || otherMetrics?.status === 'Critical' || otherMetrics?.heartRate > 120;
                          return (
                            <div 
                              key={otherP.id}
                              onClick={() => navigate(`/doctor/patient/${otherP.id}`)}
                              className="flex items-center justify-between p-3.5 bg-slate-50 hover:bg-slate-100/60 rounded-2xl border border-transparent hover:border-slate-100 transition-all cursor-pointer group"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                 <div className="w-9 h-9 bg-slate-900 rounded-xl flex items-center justify-center text-white shrink-0 font-extrabold text-sm overflow-hidden shadow-sm">
                                    {otherP.photoURL ? <img src={otherP.photoURL} alt="" className="w-full h-full object-cover" /> : otherP.displayName?.charAt(0) || 'P'}
                                 </div>
                                 <div className="truncate">
                                    <p className="font-extrabold text-slate-900 text-xs truncate group-hover:text-accent-maroon transition-colors">{otherP.displayName || "Patient Node"}</p>
                                    <p className="text-[8px] font-bold text-slate-400 mt-0.5 uppercase tracking-tight">Age {otherP.age || '--'} • {otherP.gender || '--'}</p>
                                 </div>
                              </div>
                              <div className="text-right shrink-0">
                                 <p className="text-[9px] font-black text-slate-900 italic">{otherMetrics?.heartRate || 75} BPM</p>
                                 <span className={`inline-block w-1.5 h-1.5 rounded-full mt-1 ${otherIsEmergency ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`} />
                              </div>
                            </div>
                          );
                      })
                    ) : (
                       <div className="py-10 text-center">
                          <Activity className="w-6 h-6 text-slate-200 mx-auto mb-2 animate-pulse" />
                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-relaxed">No secondary accounts synced</p>
                       </div>
                    )}
                 </div>
              </div>
           </div>
        </aside>

        {/* PANEL 2: PATIENT REPORT (RIGHT DETAIL MODULE) */}
        <main className="flex-1 flex flex-col bg-slate-50 min-h-screen lg:h-full lg:overflow-hidden">
           
           {/* HEADER UNIT */}
           <header className="h-20 bg-white border-b border-slate-200 px-6 sm:px-10 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-4">
                 <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 text-slate-400 hover:text-accent-maroon transition-all">
                    <Menu className="w-6 h-6" />
                 </button>
                 <button 
                   onClick={() => navigate('/doctor/dashboard')}
                   className="hidden sm:block p-2.5 bg-slate-50 text-slate-400 hover:text-slate-900 rounded-xl transition-all"
                   title="Return to Clinical Index"
                 >
                    <ArrowLeft className="w-4 h-4" />
                 </button>
                 <div>
                    <h2 className="text-md lg:text-lg font-black text-slate-900 tracking-tight italic">Patient Report</h2>
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mt-1">Institutional Diagnostics Ledger</p>
                 </div>
              </div>
              <div className="flex items-center gap-4 text-right">
                 <button
                   onClick={handleDownloadSnapshot}
                   className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-black text-[9px] uppercase tracking-widest rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
                   title="Download current patient vitals as PDF report"
                 >
                    <FileDown className="w-3.5 h-3.5 animate-bounce" />
                    <span>DOWNLOAD VITALS PDF</span>
                 </button>
                 <div className="hidden md:block font-mono text-[9px] font-black uppercase text-slate-400 tracking-wider">
                    Admitted Date: {patientProfile?.admittedDate || 'May 20, 2026'}
                 </div>
              </div>
           </header>

           {/* CHRONIC INCIDENT NOTIFICATION HEADER BAR */}
           {alertSeverity.level >= 3 && !isAcknowledged && (
             <div className="bg-accent-maroon text-white px-6 py-4 flex items-center justify-between shrink-0 shadow-lg border-b border-red-800 animate-pulse z-10 font-sans">
               <div className="flex items-center gap-3">
                 <AlertCircle className="w-5 h-5 text-white shrink-0 animate-bounce" />
                 <div>
                   <p className="text-[10px] font-black uppercase tracking-widest leading-none mb-1">CRITICAL TRAUMA SIREN (LEVEL {alertSeverity.level})</p>
                   <p className="text-xs font-bold text-red-50">{alertSeverity.label} - Medical responders dispatch locked</p>
                 </div>
               </div>
               <button 
                 onClick={() => setMuteAudio(!muteAudio)}
                 className="px-4 py-2 bg-white/20 hover:bg-white/30 text-white font-black text-[9px] uppercase tracking-widest rounded-xl transition-all"
               >
                 {muteAudio ? "Unmute Sound" : "Mute Sound"}
               </button>
             </div>
           )}

           {/* SCROLLABLE DETAILED DATA PANELS */}
           <div className="flex-1 overflow-y-auto p-6 sm:p-10 space-y-8 no-scrollbar scroll-smooth">
              
              {/* COMPONENT 1: METADATA LEDGER */}
              <div className="bg-white rounded-[24px] border border-slate-100 shadow-premium p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                 <div className="flex items-center gap-5 min-w-0 w-full">
                    <div className="w-16 h-16 bg-slate-950 rounded-[20px] flex items-center justify-center text-white shrink-0 font-black text-xl overflow-hidden shadow-md">
                       {patient?.photoURL ? <img src={patient.photoURL} alt="" className="w-full h-full object-cover" /> : patient?.displayName?.charAt(0) || 'P'}
                    </div>
                    <div className="truncate">
                       <div className="flex items-center gap-3 flex-wrap">
                          <h1 className="text-xl font-black text-slate-900 tracking-tighter italic leading-none">{patient?.displayName || "Patient Node"}</h1>
                          <span className={`px-2.5 py-1 text-[8px] font-black uppercase tracking-widest rounded-md ${
                             alertSeverity.level >= 3 ? 'bg-red-500 text-white animate-pulse font-bold' :
                             alertSeverity.level === 2 ? 'bg-amber-500 text-white font-bold' : 'bg-green-500 text-white font-bold'
                          }`}>
                             {alertSeverity.level >= 3 ? 'CRITICAL' : alertSeverity.level === 2 ? 'WARNING' : 'OPTIMAL'}
                          </span>
                       </div>
                       <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-2 leading-none">
                          ID: {id?.substring(0, 10).toUpperCase() || "PT-4587"} • Gender: {patientProfile?.gender || patient?.gender || 'Unknown'} • Age: {patientProfile?.age || patient?.age || '--'}
                       </p>
                    </div>
                 </div>

                 {/* Phone & Blood indicators inside details card */}
                 <div className="flex gap-4 shrink-0 w-full md:w-auto border-t border-slate-55 pt-4 md:pt-0 md:border-0 justify-around">
                    <div className="text-center md:text-right">
                       <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block leading-none mb-1">Blood Group</span>
                       <span className="text-xs font-black text-slate-800 italic">{patientProfile?.bloodGroup || '--'}</span>
                    </div>
                    <div className="text-center md:text-right">
                       <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block leading-none mb-1">Direct Phone</span>
                       <span className="text-xs font-black text-slate-800 italic">{patientProfile?.phoneNumber || '--'}</span>
                    </div>
                 </div>
              </div>

              {/* COMPONENT 2: LEAD II WAVEFORM CHART */}
              <div className="bg-white rounded-[24px] border border-slate-100 shadow-premium p-6 md:p-8 space-y-4">
                 <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                       <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest leading-none">Live ECG Waveform</h3>
                       <p className="text-lg font-black text-slate-900 italic tracking-tight mt-1.5">Direct Telemetry Lead II</p>
                    </div>
                    <div className="flex items-center gap-2 self-start sm:self-auto">
                       <select className="bg-slate-50 border border-slate-100 text-[10px] font-black uppercase tracking-wider rounded-xl p-2 text-slate-600 focus:outline-none focus:ring-1 focus:ring-accent-maroon/10">
                          <option>Lead II (Standard)</option>
                          <option>Lead I</option>
                          <option>Lead III</option>
                       </select>
                       <select className="bg-slate-50 border border-slate-100 text-[10px] font-black uppercase tracking-wider rounded-xl p-2 text-slate-600 focus:outline-none focus:ring-1 focus:ring-accent-maroon/10">
                          <option>Sweep: 25 mm/s</option>
                          <option>Sweep: 50 mm/s</option>
                       </select>
                    </div>
                 </div>

                 {/* ECG grid line */}
                 <div className="h-[360px] rounded-2xl md:rounded-3xl border border-slate-100 flex items-center justify-center relative overflow-hidden bg-white shadow-inner">
                    <div className="hidden" />
                    <ECGGraph bpm={vitals?.heartRate || escalationVitals?.bpm || 72} liveEcg={vitals?.ecg} spo2={vitals?.o2 || escalationVitals?.spo2} />
                 </div>
              </div>

              {/* COMPONENT 3: CLINICAL TABLE & AI REASONER SPLIT */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 md:gap-8">
                 
                 {/* Vital Readings table lists */}
                 <div className="bg-white rounded-[32px] border border-slate-100 shadow-premium p-6 md:p-8 space-y-6 flex flex-col justify-between">
                    <div>
                       <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest leading-none mb-6">Vital Readings</h3>
                       <div className="divide-y divide-slate-150">
                          <VitalTableRow 
                            label="Heart Rate" 
                            value={`${vitals?.heartRate || escalationVitals?.bpm || 72} BPM`} 
                            status={(vitals?.heartRate || escalationVitals?.bpm) > 140 ? 'CRITICAL' : (vitals?.heartRate || escalationVitals?.bpm) > 100 ? 'WARNING' : 'OPTIMAL'}
                          />
                          <VitalTableRow 
                            label="SpO2 (Vitals Oxygen)" 
                            value={`${vitals?.o2 || escalationVitals?.spo2 || 98}%`} 
                            status={(vitals?.o2 || escalationVitals?.spo2) < 90 ? 'CRITICAL' : 'OPTIMAL'}
                          />
                          <VitalTableRow 
                            label="Blood Pressure" 
                            value={(() => {
                               const curHr = vitals?.heartRate || escalationVitals?.bpm || 72;
                               if (curHr > 140) return "170/100 mmHg";
                               if (curHr > 100) return "135/90 mmHg";
                               return "120/80 mmHg";
                            })()} 
                            status={(vitals?.heartRate || escalationVitals?.bpm) > 140 ? 'CRITICAL' : 'OPTIMAL'}
                          />
                          <VitalTableRow 
                            label="Respiratory Rate" 
                            value={(() => {
                               const curHr = vitals?.heartRate || escalationVitals?.bpm || 72;
                               return curHr > 100 ? "24 /min" : "18 /min";
                            })()} 
                            status="OPTIMAL"
                          />
                          <VitalTableRow 
                            label="Body Temperature" 
                            value={`${(() => {
                               const celsius = vitals?.temp || escalationVitals?.temperature || 36.5;
                               const fahrenheit = (celsius * 9/5) + 32;
                               return `${fahrenheit.toFixed(1)} °F (${celsius.toFixed(1)} °C)`;
                            })()}`} 
                            status={(vitals?.temp || escalationVitals?.temperature) > 38.5 ? 'WARNING' : 'OPTIMAL'}
                          />
                       </div>
                    </div>
                 </div>

                 {/* AI diagnostics panel */}
                 <div className="bg-white rounded-[32px] border border-slate-100 shadow-premium p-6 md:p-8 space-y-6 flex flex-col justify-between">
                    <div>
                       <div className="flex items-center justify-between gap-4 mb-4">
                          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest leading-none flex items-center gap-2">
                             <Sparkles className="w-4 h-4 text-accent-maroon shrink-0 animate-pulse text-red-500" />
                             AI Analysis Report
                          </h3>
                          <span className={`px-2.5 py-1 text-[8px] font-black tracking-widest uppercase rounded-lg ${
                             clinicalReport.riskLevel === 'OPTIMAL' ? 'bg-green-100/90 text-green-700 font-bold' :
                             clinicalReport.riskLevel === 'WARNING' ? 'bg-amber-100/90 text-amber-700 font-bold' : 'bg-red-100/90 text-red-700 font-bold'
                          }`}>{clinicalReport.riskLevel}</span>
                       </div>
                       <div className="h-px bg-slate-100 w-full mb-6" />

                       <div className="space-y-4 font-sans text-xs">
                          <div>
                             <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 leading-none">ECG Condition</p>
                             <p className="text-xs font-extrabold text-slate-900 leading-none">{clinicalReport.ecgCondition}</p>
                          </div>
                          <div>
                             <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 leading-none">Overall Risk Classification</p>
                             <p className={`text-xs font-black leading-none ${
                               clinicalReport.riskLevel === 'OPTIMAL' ? 'text-green-600' :
                               clinicalReport.riskLevel === 'WARNING' ? 'text-amber-600' : 'text-accent-maroon font-bold'
                             }`}>{clinicalReport.riskLevel}</p>
                          </div>
                          <div>
                             <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 leading-none">Identified Anomaly</p>
                             <p className="text-xs font-extrabold text-slate-900 leading-none">{clinicalReport.possibleIssue}</p>
                          </div>
                          <div className="pt-2">
                             <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 leading-none">Clinical Guidelines & Treatment Recommendations</p>
                             <p className="text-[10px] font-semibold text-slate-500 bg-slate-50 border border-slate-100/50 p-4 rounded-xl leading-relaxed">{clinicalReport.recommendation}</p>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>

              {/* ACTION BUTTON WRAPPER AT VERY BOTTOM */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 pt-4 border-t border-slate-100">
                 <button 
                   onClick={handleLocalFalseAlarm}
                   className="w-full flex items-center justify-center gap-3 p-5 bg-amber-50 border border-amber-200 text-amber-700 hover:bg-amber-100/80 active:scale-95 transition-all rounded-2xl font-black text-[10px] uppercase tracking-widest cursor-pointer shadow-sm"
                 >
                    <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 font-bold" />
                    False Alert: Reset telemetry to optimal
                 </button>
                 <button 
                   onClick={handleLocalTriggerEmergency}
                   className="w-full flex items-center justify-center gap-3 p-5 bg-accent-maroon text-white hover:bg-accent-maroon/90 active:scale-95 transition-all rounded-2xl font-black text-[10px] uppercase tracking-widest cursor-pointer shadow-xl shadow-accent-maroon/20"
                 >
                    <ShieldAlert className="w-5 h-5 text-white shrink-0 animate-bounce" />
                    Emergency Alert: Dispatch Responders
                 </button>
                 <button 
                   onClick={handleLocalCallAmbulance}
                   disabled={isAmbulanceCalling}
                   className={`w-full flex items-center justify-center gap-3 p-5 rounded-2xl font-black text-[10px] uppercase tracking-widest cursor-pointer transition-all ${
                     isAmbulanceCalling 
                       ? 'bg-slate-100 text-slate-400 border border-slate-200' 
                       : 'bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 shadow-xl shadow-emerald-500/10'
                   }`}
                 >
                    <Phone className="w-5 h-5 text-white shrink-0 animate-pulse" />
                    {isAmbulanceCalling ? 'Calling Ambulance...' : 'Call Ambulance (9573732216)'}
                 </button>
              </div>
           </div>
        </main>
      </div>

    {/* EMERGENCY POPUP INTERACTIVE OVERLAY */}
    <AnimatePresence>
      {isLocalEmergencyPopupVisible && (
         <motion.div 
           initial={{ opacity: 0 }}
           animate={{ opacity: 1 }}
           exit={{ opacity: 0 }}
           className="fixed inset-0 bg-slate-900/85 backdrop-blur-md z-[9999] flex items-center justify-center p-4 overflow-y-auto font-sans"
         >
           <motion.div 
             initial={{ scale: 0.9, y: 20 }}
             animate={{ scale: 1, y: 0 }}
             exit={{ scale: 0.9, y: 20 }}
             className="w-full max-w-4xl bg-white rounded-[32px] md:rounded-[48px] overflow-hidden shadow-2xl relative border-2 border-accent-maroon/20 my-8 shadow-accent-maroon/10"
           >
              {/* CLOSE WINDOW ACTION */}
              <button 
                onClick={handleLocalFalseAlarm}
                className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all cursor-pointer z-10 border-0"
                title="Mark as False Alarm"
              >
                <X className="w-5 h-5 border border-white rounded-full p-0.5" />
              </button>

              {/* MODAL HERO HEAD */}
              <div className="bg-accent-maroon text-white p-8 md:p-12 flex items-center gap-6">
                <div className="p-4 bg-white/15 rounded-3xl shrink-0 animate-bounce">
                   <AlertCircle className="w-10 h-10 text-white" />
                </div>
                <div>
                   <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/70">HEARTSYNC CLINICAL CRISIS CORE</span>
                   <h2 className="text-2xl md:text-3xl font-black italic tracking-tight leading-none mt-1">FULL MEDICAL EMERGENCY ACTIVE</h2>
                </div>
              </div>

              {/* MODAL CORRESPONDENCE PANEL */}
              <div className="p-6 md:p-12 space-y-8 text-slate-800">
                {/* MESSAGE STATUS HEADER */}
                <div className="bg-red-50 border border-red-100 rounded-2xl p-6 flex gap-4 items-start">
                   <span className="text-2xl">🚨</span>
                   <div>
                     <p className="text-red-900 text-sm font-black uppercase tracking-wide">Physiological Alarm Triaged</p>
                     <p className="text-slate-600 text-xs font-semibold leading-relaxed mt-1">
                        Heart Rate, Oxygen Saturation, and Body Temperature thresholds are breached. Emergency dispatch sequences are engaged and automated alert messages have been broadcast to the verified Family and Friends nodes.
                     </p>
                   </div>
                </div>

                {/* VITALS COMPARATIVE INDEX */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                   {/* BPM CARD */}
                   <div className="p-6 rounded-[24px] border bg-red-50 border-red-200 text-red-805 flex flex-col justify-between">
                      <div>
                         <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Heart Rate</p>
                         <p className="text-3xl font-black italic tracking-tighter mt-2">{vitals?.heartRate || escalationVitals?.bpm || 35} <span className="text-xs font-bold uppercase text-slate-400">BPM</span></p>
                      </div>
                      <span className="text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded bg-red-650 text-white self-start mt-4 animate-pulse">
                         CRITICAL
                      </span>
                   </div>

                   {/* SPO2 CARD */}
                   <div className="p-6 rounded-[24px] border bg-red-50 border-red-205 text-red-805 flex flex-col justify-between">
                      <div>
                         <p className="text-[9px] font-black uppercase tracking-widest text-slate-500 font-bold">Oxygen (SpO2)</p>
                         <p className="text-3xl font-black italic tracking-tighter mt-2">{vitals?.o2 || escalationVitals?.spo2 || 72} <span className="text-xs font-bold uppercase text-slate-400">%</span></p>
                      </div>
                      <span className="text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded bg-red-650 text-white self-start mt-4 animate-pulse">
                         CRITICAL
                      </span>
                   </div>

                   {/* TEMP CARD */}
                   <div className="p-6 rounded-[24px] border bg-red-50 border-red-205 text-red-805 flex flex-col justify-between">
                      <div>
                         <p className="text-[9px] font-black uppercase tracking-widest text-slate-500 font-bold">Body Temp</p>
                         <p className="text-3xl font-black italic tracking-tighter mt-2">{vitals?.temp || escalationVitals?.temperature || 40} <span className="text-xs font-bold uppercase text-slate-400">°C</span></p>
                      </div>
                      <span className="text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded bg-red-650 text-white self-start mt-4 animate-pulse">
                         CRITICAL
                      </span>
                   </div>

                   {/* WHATSAPP LEDGER CARD */}
                   <div className="p-6 rounded-[24px] border bg-emerald-50 border-emerald-150 text-emerald-950 flex flex-col justify-between">
                      <div>
                         <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 font-semibold font-mono">WhatsApp Gateway</p>
                         <p className="text-xs font-black italic mt-2.5">
                           {whatsAppStatus === 'sending' ? 'Dispatching...' :
                            whatsAppStatus === 'sent' ? 'Broadcast Succeeded' :
                            whatsAppStatus === 'error' ? 'Delivery Error (Retry)' : 'Broadcasting Alerts'}
                         </p>
                         <p className="text-[8px] font-extrabold text-slate-400 uppercase mt-1">To: Family/Friends (7569824148)</p>
                      </div>
                      <span className={`text-[8px] font-black tracking-wider px-2.5 py-1 rounded self-start mt-4 ${
                        whatsAppStatus === 'sent' ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'
                      }`}>
                         {whatsAppStatus === 'sending' ? 'PENDING' :
                          whatsAppStatus === 'sent' ? 'SENT' : 'IDLE'}
                      </span>
                   </div>
                </div>

                {/* DETAILS GRID */}
                <div className="flex bg-slate-50 p-4 border border-slate-100 rounded-2xl justify-between flex-wrap text-[10px] font-mono text-slate-500 font-bold uppercase leading-none">
                   <span>Recipient: Family & Friends (7569824148)</span>
                   <span>Patient Node: {patient?.displayName || "John Doe"}</span>
                   <span>Clinical ID: {id?.substring(0, 10).toUpperCase()}</span>
                </div>

                {/* MODAL BASE CONTROLS */}
                <div className="flex flex-col sm:flex-row gap-4 items-center justify-between border-t border-slate-100 pt-8 mt-4 font-sans">
                   <button 
                     onClick={handleLocalFalseAlarm}
                     className="w-full sm:w-auto border-2 border-dashed border-slate-200 text-slate-500 hover:border-slate-300 hover:text-slate-600 rounded-2xl px-8 py-4 font-black uppercase tracking-widest text-[10px] transition-all cursor-pointer"
                   >
                      FALSE ALARM
                   </button>

                   <div className="flex items-center gap-4 w-full sm:w-auto">
                      <button 
                        onClick={handleLocalViewReport}
                        className="flex-1 sm:flex-none bg-slate-100 hover:bg-slate-200 text-slate-700 font-black rounded-2xl px-8 py-4 uppercase tracking-widest text-[10px] transition-all cursor-pointer"
                      >
                         VIEW REPORT
                      </button>
                      <button 
                        onClick={handleLocalCallAmbulance}
                        disabled={isAmbulanceCalling}
                        className="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl px-8 py-4 font-black uppercase tracking-widest text-[10px] flex items-center gap-2 shadow-lg shadow-emerald-500/20 hover:scale-[1.02] active:scale-95 transition-transform cursor-pointer"
                      >
                         {isAmbulanceCalling ? 'DIALING OUT...' : 'CALL AMBULANCE'}
                      </button>
                   </div>
                </div>
              </div>
           </motion.div>
         </motion.div>
      )}
    </AnimatePresence>
    </div>
  );
};

const VitalTableRow = ({ label, value, status }: { label: string; value: string; status: 'CRITICAL' | 'WARNING' | 'OPTIMAL' }) => (
  <div className="flex items-center justify-between py-4 font-sans">
     <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{label}</span>
     <div className="flex items-center gap-3">
        <span className="text-xs font-black text-slate-800 italic">{value}</span>
        <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded leading-none ${
           status === 'CRITICAL' ? 'bg-red-50 text-red-600 border border-red-100 font-bold animate-pulse' :
           status === 'WARNING' ? 'bg-amber-50 text-amber-600 border border-amber-100' : 'bg-green-50 text-green-600'
        }`}>{status}</span>
     </div>
  </div>
);

export default DoctorPatientDetails;

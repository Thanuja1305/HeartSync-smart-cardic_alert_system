import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  Activity, 
  History, 
  MapPin, 
  Settings, 
  LogOut, 
  User, 
  Menu, 
  X, 
  ShieldCheck, 
  ShieldAlert,
  Bell,
  Thermometer,
  Droplets,
  HeartPulse,
  AlertCircle,
  TrendingUp,
  Clock,
  Camera,
  ChevronRight,
  Globe,
  Upload,
  Sparkles,
  Volume2,
  VolumeX
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { db, handleFirestoreError, OperationType, rtdb } from '../lib/firebase';
import { doc, onSnapshot, setDoc, collection, query, orderBy, limit, addDoc } from 'firebase/firestore';
import { ref, onValue, set } from 'firebase/database';
import VitalsCard from '../components/patient/VitalsCard';
import ECGGraph from '../components/patient/ECGGraph';
import AIChatWidget from '../components/patient/AIChatWidget';
import LiveLocation from './LiveLocation';
import PatientProfile from './PatientProfile';
import { usePatientVitals } from '../hooks/usePatientVitals';
import { startIoTSimulation } from '../services/iotService';

type DashboardTab = 'monitoring' | 'history' | 'location' | 'settings';

const PatientDashboard = () => {
  const { user, profile, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<DashboardTab>('monitoring');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [vitals, setVitals] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [patientData, setPatientData] = useState<any>(null);
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);
  const [showEmergencyPopup, setShowEmergencyPopup] = useState(false);
  const [activeLogs, setActiveLogs] = useState<string[]>([]);
  const [latency, setLatency] = useState(25);
  const [isSimulating, setIsSimulating] = useState(true);
  const [showPatientEmergencyModal, setShowPatientEmergencyModal] = useState(false);
  const [emergencyLocationCoords, setEmergencyLocationCoords] = useState<{ latitude: number; longitude: number } | null>(null);
  const [isAlertingDoctors, setIsAlertingDoctors] = useState(false);

  const [heartRateThreshold, setHeartRateThreshold] = useState<number>(() => {
    const saved = localStorage.getItem('heart_rate_threshold');
    return saved ? Number(saved) : 120;
  });
  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(false);

  const lastAlertTimeRef = useRef<number>(0);
  const wasAboveThresholdRef = useRef<boolean>(false);
  const lastSyncTimeRef = useRef<number>(0);
  const lastSyncValuesRef = useRef<{ bpm: number; spo2: number; isEmergency: boolean } | null>(null);

  // Sync state changes back to localStorage
  useEffect(() => {
    localStorage.setItem('heart_rate_threshold', String(heartRateThreshold));
  }, [heartRateThreshold]);

  // Check notification status on mount
  useEffect(() => {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        setNotificationsEnabled(true);
      }
    }
  }, []);

  // System notification watch
  useEffect(() => {
    if (!vitals?.heartRate || !notificationsEnabled) return;

    const bpm = vitals.heartRate;
    const limitVal = heartRateThreshold;
    const isAbove = bpm > limitVal;

    if (isAbove) {
      const now = Date.now();
      const shouldNotify = !wasAboveThresholdRef.current || (now - lastAlertTimeRef.current > 30000);

      if (shouldNotify) {
        lastAlertTimeRef.current = now;
        wasAboveThresholdRef.current = true;

        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification("🚨 Clinical Alert: Heart Rate Limit Exceeded", {
            body: `Telemetry reports anomalous heart rate of ${bpm} BPM, exceeding safety limit of ${limitVal} BPM!`,
            icon: "/favicon.ico",
            tag: "hr-breach"
          });
        }
      }
    } else {
      wasAboveThresholdRef.current = false;
    }
  }, [vitals?.heartRate, heartRateThreshold, notificationsEnabled]);

  // Manually connect this specific patient profile to always receive live sensor stream
  const userId = "m1uph2bX7SVd9Wbyge1AMqAmq093";
  const { vitals: realVitals, loading: vitalsLoading, error: vitalsError } = usePatientVitals(userId);

  // Background hardware simulator connection
  useEffect(() => {
    if (!isSimulating || !userId) return;

    console.log("STARTING HARDWARE SIMULATOR STREAM FOR:", userId);
    const stopSimulation = startIoTSimulation(userId);

    return () => {
      console.log("STOPPING HARDWARE SIMULATOR STREAM FOR:", userId);
      stopSimulation();
    };
  }, [isSimulating, userId]);

  const getStatusString = (level: number): 'optimal' | 'warning' | 'critical' => {
    if (level === 2) return 'warning';
    if (level === 3) return 'critical';
    return 'optimal';
  };

  // Pulse Connection Latency Simulator
  useEffect(() => {
    const interval = setInterval(() => {
      setLatency(15 + Math.floor(Math.random() * 15));
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  const handleTriggerGlobalEmergency = () => {
    setIsAlertingDoctors(true);
    
    // Obtain live geolocation or default to synced RTDB device coordinate
    const handleAlertCreation = (lat: number, lng: number) => {
      setEmergencyLocationCoords({ latitude: lat, longitude: lng });
      setShowPatientEmergencyModal(true);

      // 1. Sync to Firestore liveHealthMetrics for this patient ID
      setDoc(doc(db, 'liveHealthMetrics', userId), {
        heartRate: vitals?.heartRate || 142,
        o2: vitals?.o2 || 88,
        temp: vitals?.temp || 38.6,
        isEmergency: true,
        status: 'critical',
        alertLevel: 3,
        alertReason: 'Patient manually triggered Global Emergency Trigger!',
        current_condition: 'CRITICAL RESPONDERS ASSIGNED',
        humidity: vitals?.humidity || 55,
        ecg: vitals?.ecg || 512
      }, { merge: true }).catch(err => console.error("Firestore liveHealthMetrics error:", err));

      // 2. Alert Connected Doctors via public emergencyAlerts collection in Firestore
      setDoc(doc(db, 'emergencyAlerts', userId), {
        patientId: userId,
        emergency: true,
        severity: "CRITICAL",
        detectedAt: Date.now(),
        status: "PENDING_DOCTOR_VERIFICATION",
        patientName: patientData?.fullName || patientData?.displayName || "Rahul Sharma",
        vitalsAtTrigger: {
          heartRate: vitals?.heartRate || 142,
          spo2: vitals?.o2 || 88,
          temp: vitals?.temp || 38.6
        },
        location: {
          latitude: lat,
          longitude: lng
        },
        verifiedBy: null,
        verifiedAt: null
      }, { merge: true }).catch(err => console.error("Firestore emergencyAlerts error:", err));

      // 3. Update Realtime Database node alert level to trigger Sirens instantly on doctor screen
      const liveRef = ref(rtdb, `/users/${userId}/liveReading`);
      set(liveRef, {
        BPM: vitals?.heartRate || 142,
        SpO2: vitals?.o2 || 88,
        Temp: vitals?.temp || 38.6,
        alertLevel: 3,
        alertReason: 'Patient manually triggered Global Emergency Trigger!',
        current_condition: 'CRITICAL RESPONDERS ASSIGNED',
        humidity: vitals?.humidity || 55,
        ecg: vitals?.ecg || 512
      }).catch(err => console.error("RTDB live reading error:", err));

      setIsAlertingDoctors(false);
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          handleAlertCreation(pos.coords.latitude, pos.coords.longitude);
        },
        (err) => {
          console.warn("GPS Permission blocked/errored inside secure iframe, falling back to synced medical station telemetry.", err);
          handleAlertCreation(40.7128, -74.0060);
        },
        { timeout: 7000, enableHighAccuracy: true }
      );
    } else {
      handleAlertCreation(40.7128, -74.0060);
    }
  };

  const handleResetGlobalEmergency = () => {
    setShowPatientEmergencyModal(false);
    // Restore state variables to optimal nominal ranges
    setDoc(doc(db, 'liveHealthMetrics', userId), {
      heartRate: 72,
      o2: 98,
      temp: 36.5,
      isEmergency: false,
      status: 'optimal',
      alertLevel: 1,
      alertReason: '',
      current_condition: 'MONITORING',
      humidity: 55,
      ecg: 512
    }, { merge: true }).catch(err => console.error("Firestore nominal restore error:", err));

    // Clear public emergencyAlerts document
    setDoc(doc(db, 'emergencyAlerts', userId), {
      patientId: userId,
      emergency: false,
      status: "RESOLVED_BY_PATIENT",
      resolvedAt: Date.now()
    }, { merge: true }).catch(err => console.error("Firestore alert resolution error:", err));

    // Reset RTDB live readings node
    const liveRef = ref(rtdb, `/users/${userId}/liveReading`);
    set(liveRef, {
      BPM: 72,
      SpO2: 98,
      Temp: 36.5,
      alertLevel: 1,
      alertReason: '',
      current_condition: 'MONITORING',
      humidity: 55,
      ecg: 512
    }).catch(err => console.error("RTDB nominal restore error:", err));
  };

  // Standard high-pitch clinical double-beep sequence for ICU emergencies
  const playClinicalBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      const triggerBeep = (freq: number, duration: number, delayMs: number) => {
        setTimeout(() => {
          const osc = audioCtx.createOscillator();
          const gainNode = audioCtx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
          gainNode.gain.setValueAtTime(0.06, audioCtx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
          osc.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          osc.start();
          osc.stop(audioCtx.currentTime + duration);
        }, delayMs);
      };

      triggerBeep(987.77, 0.15, 0);       // Pulse 1
      triggerBeep(987.77, 0.15, 180);     // Pulse 2
    } catch {
      // Fail silently if browser blocks automated play
    }
  };

  // Beeps periodically when alertLevel is 3 (Critical) and audio is not muted
  useEffect(() => {
    if (vitals?.status === 'critical' && isSoundEnabled) {
      const interval = setInterval(playClinicalBeep, 2000);
      playClinicalBeep();
      return () => clearInterval(interval);
    }
  }, [vitals?.status, isSoundEnabled]);

  // Handle emergency modal logic automatically on status change
  useEffect(() => {
    if (vitals?.status === 'critical') {
      setShowEmergencyPopup(true);
    }
  }, [vitals?.status]);

  // Feed Real-time logs list on incoming Firebase changes
  useEffect(() => {
    if (!vitals) return;
    const timeStr = new Date().toLocaleTimeString();
    const isCrisis = vitals.status === 'critical';
    const isWarn = vitals.status === 'warning';
    
    let message = `SENSORS NOMINAL: BPM ${vitals.heartRate} | SpO2 ${vitals.o2}% | Temp ${vitals.temp.toFixed(1)}°C | Humid ${vitals.humidity}%`;
    if (isCrisis) {
      message = `🚨 CRITICAL LIMIT BREACHED: BPM [${vitals.heartRate}] SpO2 [${vitals.o2}%] - ALARM TRIGGERED`;
    } else if (isWarn) {
      message = `⚠️ WARNING READOUT: Borderline vitals detected - BPM ${vitals.heartRate} | Temp ${vitals.temp.toFixed(1)}°C`;
    }

    setActiveLogs(prev => [`[${timeStr}] ${message}`, ...prev.slice(0, 14)]);
  }, [vitals?.heartRate, vitals?.o2, vitals?.temp, vitals?.humidity]);

  // Sync Patient profile & historical logs
  useEffect(() => {
    if (!userId) return;

    // 1. Listen to Firestore Patient Profile
    const unsubPatient = onSnapshot(doc(db, 'patients', userId), (snap) => {
      if (snap.exists()) {
        setPatientData((prev: any) => ({
          ...prev,
          ...snap.data()
        }));
      }
    });

    // 2. Listen to RTDB Patient Profile (Manual Integration)
    const patientRef = ref(rtdb, `/users/${userId}`);
    const unsubPatientRTDB = onValue(patientRef, (snapshot) => {
      const data = snapshot.val();
      console.log("PATIENT PROFILE DATA RECEIVED FROM RTDB:", data);
      if (snapshot.exists() && data) {
        setPatientData((prev: any) => ({
          ...prev,
          fullName: data.name || data.fullName || (prev ? prev.fullName : ''),
          age: data.age !== undefined ? String(data.age) : (prev ? prev.age : ''),
          gender: data.gender || (prev ? prev.gender : ''),
          bloodGroup: data.bloodGroup || (prev ? prev.bloodGroup : ''),
          condition: data.condition || (prev ? prev.condition : ''),
          email: data.email || (prev ? prev.email : '')
        }));
      }
    }, (err) => {
      console.error("Firebase permission/read error caught in RTDB patient profile:", err);
    });

    const q = query(
      collection(db, 'patientHistory', userId, 'logs'),
      orderBy('timestamp', 'desc'),
      limit(20)
    );
    const unsubHistory = onSnapshot(q, (snap) => {
      setHistory(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubPatient();
      unsubPatientRTDB();
      unsubHistory();
    };
  }, [userId]);

  // Synchronize browser tab title for SEO and standard compliant SPA
  useEffect(() => {
    document.title = "ICU Live | Patient Dashboard | HeartSync";
  }, []);

  // Synchronize RTDB vitals into local vitals state and propagate to Firestore liveHealthMetrics
  useEffect(() => {
    if (!userId || !realVitals) return;

    const formattedVitals = {
      heartRate: realVitals.bpm,
      o2: realVitals.spo2,
      temp: realVitals.temperature,
      isEmergency: realVitals.alertLevel === 3,
      status: realVitals.alertLevel === 3 ? 'critical' : realVitals.alertLevel === 2 ? 'warning' : 'optimal',
      alertLevel: realVitals.alertLevel,
      alertReason: realVitals.alertReason,
      current_condition: realVitals.current_condition,
      humidity: realVitals.humidity,
      ecg: realVitals.ecg
    };

    setVitals((prev: any) => {
      if (prev &&
          prev.heartRate === formattedVitals.heartRate &&
          prev.o2 === formattedVitals.o2 &&
          prev.temp === formattedVitals.temp &&
          prev.isEmergency === formattedVitals.isEmergency &&
          prev.status === formattedVitals.status &&
          prev.alertLevel === formattedVitals.alertLevel &&
          prev.alertReason === formattedVitals.alertReason &&
          prev.current_condition === formattedVitals.current_condition &&
          prev.humidity === formattedVitals.humidity) {
        return prev;
      }
      return formattedVitals;
    });

    // Sync to Firestore selectively:
    // Sync immediately if:
    // 1. It's an emergency status update, OR
    // 2. Emergency status changed compared to last sync, OR
    // 3. Significant numeric changes detected (BPM fluctuates, SpO2 fluctuates), OR
    // 4. More than 4.5 seconds have elapsed since the last sync.
    const now = Date.now();
    const isEmergencyValue = realVitals.alertLevel === 3;
    const timeSinceLastSync = now - lastSyncTimeRef.current;
    
    let shouldSync = false;
    if (!lastSyncValuesRef.current) {
      // First sync
      shouldSync = true;
    } else {
      const last = lastSyncValuesRef.current;
      const bpmDelta = Math.abs(realVitals.bpm - last.bpm);
      const spo2Delta = Math.abs(realVitals.spo2 - last.spo2);
      const emergencyChanged = isEmergencyValue !== last.isEmergency;

      if (isEmergencyValue || emergencyChanged) {
        shouldSync = true; // Always sync emergencies immediately to update doctor console instantly
      } else if (bpmDelta > 5 || spo2Delta > 2) {
        shouldSync = true; // Sync significant updates
      } else if (timeSinceLastSync > 4500) {
        shouldSync = true; // Routine heartbeat status updates
      }
    }

    if (shouldSync) {
      lastSyncTimeRef.current = now;
      lastSyncValuesRef.current = {
        bpm: realVitals.bpm,
        spo2: realVitals.spo2,
        isEmergency: isEmergencyValue
      };

      setDoc(doc(db, 'liveHealthMetrics', userId), {
        heartRate: realVitals.bpm,
        o2: realVitals.spo2,
        temp: realVitals.temperature,
        humidity: realVitals.humidity !== undefined ? realVitals.humidity : 55,
        ecg: realVitals.ecg !== undefined ? realVitals.ecg : 512,
        status: realVitals.alertLevel === 3 ? 'Critical' : realVitals.alertLevel === 2 ? 'Warning' : 'Optimal',
        timestamp: new Date().toISOString(),
        isEmergency: isEmergencyValue
      }, { merge: true })
        .catch((err) => console.error("Failed to sync RTDB to Firestore:", err));
    }
  }, [userId, realVitals]);

  const navItems = [
    { id: 'monitoring', label: 'Live Monitoring', icon: Activity },
    { id: 'history', label: 'History Logs', icon: History },
    { id: 'location', label: 'Emergency Location', icon: MapPin },
    { id: 'settings', label: 'System Settings', icon: Settings },
  ];

  return (
    <div className={`flex min-h-screen lg:h-screen lg:overflow-hidden font-sans text-slate-800 transition-all duration-700 bg-[#F8FAFC] ${
      vitals?.status === 'critical' 
        ? 'ring-[10px] ring-red-500/20 ring-inset animate-pulse' 
        : ''
    }`}>
      <title>ICU Live | Patient Dashboard</title>

      {/* MOBILE OVERLAY */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[80] lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* SIDEBAR NAVIGATION */}
      <aside className={`fixed lg:relative w-full sm:w-80 h-full bg-white text-slate-700 border-r border-slate-100 z-[90] flex flex-col transition-transform duration-500 lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 md:p-8 pb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="p-2.5 bg-accent-maroon rounded-2xl shadow-lg shadow-accent-maroon/20">
                <Heart className="w-5 h-5 text-white fill-white" />
             </div>
             <div>
                <h1 className="text-xl font-bold text-slate-900 tracking-tight">HeartSync</h1>
                <p className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest leading-none">Patient Hub</p>
             </div>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 text-slate-400 hover:text-slate-900 transition-all">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* PROFILE INTEGRITY BANNER - Styled for ICU theme */}
        <div className="px-6 mb-6">
          <div className="p-5 bg-slate-50 rounded-[24px] border border-slate-100 relative overflow-hidden shadow-sm">
             <div className="absolute top-0 right-0 p-3 flex gap-1 items-center">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                <span className="text-[8px] font-mono text-emerald-600 tracking-widest">ON</span>
             </div>
             <p className="text-[9px] font-mono font-black text-accent-maroon uppercase tracking-widest leading-none mb-1">UNIT LINK</p>
             <h4 className="text-xs font-black text-slate-700 truncate">HS-ICU-EMR NODE</h4>
             <p className="text-[9px] font-mono text-slate-400 mt-2">SYS SECURE // LATENCY: {latency}ms</p>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-2 overflow-y-auto no-scrollbar">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id as DashboardTab);
                setIsSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all ${
                activeTab === item.id 
                ? 'bg-slate-900 text-white shadow-premium translate-x-1' 
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <item.icon className="w-5 h-5 transition-transform" />
              <span className="text-xs font-bold uppercase tracking-wider">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* BOTTOM REAL SIGN-OUT FOOTER */}
        <div className="p-4 border-t border-slate-100 bg-white">
          <button 
            onClick={() => {
              logout();
            }}
            className="w-full flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl font-bold text-xs font-mono tracking-widest uppercase bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100 transition-all active:scale-95"
          >
            <LogOut className="w-4 h-4 text-slate-500" />
            <span>SIGN OUT</span>
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 flex flex-col min-w-0 min-h-screen lg:h-full lg:overflow-hidden bg-[#F8FAFC]">
        <header className="h-20 md:h-24 bg-white/70 backdrop-blur-md border-b border-slate-100 px-4 sm:px-6 md:px-12 flex items-center justify-between shrink-0 relative z-20">
          <div className="flex items-center gap-3 md:gap-4">
             <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 text-slate-400 hover:text-slate-900 transition-all">
                <Menu className="w-6 h-6" />
             </button>
             <div>
                <h2 className="text-lg md:text-2xl font-black text-slate-800 tracking-tight italic">
                  {navItems.find(t => t.id === activeTab)?.label}
                </h2>
                <p className="hidden xs:block text-[9px] md:text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest leading-none mt-0.5">
                  CLINICAL SUITE // SYS_ACTIVE_OK
                </p>
             </div>
          </div>
          
          <div className="flex items-center gap-4 md:gap-6">
             <div className="hidden sm:flex flex-col items-end">
                <span className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest">UNIT FEED ACCURACY</span>
                <div className="flex items-center gap-2 mt-0.5">
                   <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                   <span className="text-xs font-mono font-black text-slate-600">1:1 CRYPTO-SECURE ({latency}ms)</span>
                </div>
             </div>
             
             {/* Global Emergency Manual Trigger Panic Control */}
             <button 
               onClick={handleTriggerGlobalEmergency}
               disabled={isAlertingDoctors}
               className="flex items-center gap-2 px-4 py-2.5 bg-accent-maroon hover:bg-accent-maroon/90 text-white rounded-xl shadow-lg shadow-accent-maroon/20 hover:scale-[1.02] active:scale-95 transition-all cursor-pointer font-sans text-[11px] font-black tracking-widest uppercase"
               title="Broadcast simultaneous urgent distress alerts to all connected doctors"
             >
                <ShieldAlert className="w-4 h-4 text-white shrink-0 animate-bounce" />
                <span>GLOBAL EMERGENCY</span>
             </button>

             {/* Dynamic Beeper Controller */}
             <button 
               onClick={() => setIsSoundEnabled(!isSoundEnabled)}
               className={`p-2.5 rounded-xl border transition-all ${
                 isSoundEnabled 
                   ? 'bg-accent-maroon/10 border-accent-maroon/20 text-accent-maroon hover:bg-accent-maroon/20' 
                   : 'bg-slate-150 border-slate-200 text-slate-500 hover:bg-slate-200'
               }`}
               title={isSoundEnabled ? "Mute ICU Audio Warnings" : "Enable ICU Audio Warnings"}
             >
                {isSoundEnabled ? <Volume2 className="w-4 h-4 animate-bounce" /> : <VolumeX className="w-4 h-4" />}
             </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-12 space-y-6 md:space-y-12 no-scrollbar">
           <AnimatePresence mode="wait">
               {activeTab === 'monitoring' && (
                 vitalsLoading ? (
                   <motion.div 
                     initial={{ opacity: 0 }}
                     animate={{ opacity: 1 }}
                     className="flex flex-col items-center justify-center py-20 text-center space-y-4"
                   >
                     <div className="p-4 bg-accent-maroon/10 rounded-full animate-bounce">
                       <HeartPulse className="w-10 h-10 text-accent-maroon animate-pulse" />
                     </div>
                     <div>
                       <h3 className="text-lg font-black text-slate-800 tracking-tight italic">Establishing Telemetry Link</h3>
                       <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Acquiring 1:1 RTDB Live Feed...</p>
                     </div>
                   </motion.div>
                 ) : vitalsError ? (
                   <motion.div 
                     initial={{ opacity: 0 }}
                     animate={{ opacity: 1 }}
                     className="flex flex-col items-center justify-center py-20 text-center space-y-4"
                   >
                     <div className="p-4 bg-red-100 rounded-full">
                       <AlertCircle className="w-10 h-10 text-red-500 animate-pulse" />
                     </div>
                     <div>
                       <h3 className="text-[14px] font-black text-slate-800 uppercase tracking-widest leading-none">Telemetry Offline</h3>
                       <p className="text-xs text-red-400 font-bold max-w-sm mt-1">{vitalsError.message || "Failed to initialize satellite connection."}</p>
                     </div>
                   </motion.div>
                 ) : (
                   <motion.div 
                     key="monitoring"
                     initial={{ opacity: 0, y: 20 }}
                     animate={{ opacity: 1, y: 0 }}
                     exit={{ opacity: 0, y: -20 }}
                     className="space-y-8 md:space-y-12"
                   >
                      {/* QUICK VITALS */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 md:gap-6">
                         <VitalsCard 
                         label="Heart Rate" 
                         value={vitals?.heartRate !== undefined && vitals?.heartRate !== null ? vitals.heartRate : '--'} 
                         unit="BPM" 
                         status={vitals ? getStatusString(vitals.alertLevel) : 'optimal'} 
                         icon={HeartPulse} 
                         trend={vitals?.heartRate > 90 ? 'up' : vitals?.heartRate < 55 ? 'down' : 'stable'}
                         customStatusLabel={vitals?.alertLevel === 3 ? 'CRITICAL LIMIT' : vitals?.alertLevel === 2 ? 'ELEVATED' : 'STABLE'}
                       />
                       <VitalsCard 
                         label="Blood Oxygen" 
                         value={vitals?.o2 !== undefined && vitals?.o2 !== null ? vitals.o2 : '--'} 
                         unit="%" 
                         status={vitals ? getStatusString(vitals.alertLevel) : 'optimal'} 
                         icon={Activity} 
                         trend={vitals?.o2 < 93 ? 'down' : 'stable'}
                         customStatusLabel={vitals?.o2 > 0 && vitals?.o2 < 90 ? 'HEAVY HYPOXIA' : vitals?.o2 < 95 ? 'MARGINAL' : 'OPTIMAL'}
                       />
                       <VitalsCard 
                         label="Core Temperature" 
                         value={vitals?.temp !== undefined && vitals?.temp !== null ? vitals.temp.toFixed(1) : '--'} 
                         unit="°C" 
                         status={vitals ? getStatusString(vitals.alertLevel) : 'optimal'} 
                         icon={Thermometer} 
                         trend={vitals?.temp > 37.5 ? 'up' : 'stable'}
                         customStatusLabel={vitals?.temp > 38 ? 'HYPERTHERMIA' : 'NOMINAL'}
                       />
                       <VitalsCard 
                         label="Room Humidity" 
                         value={vitals?.humidity !== undefined && vitals?.humidity !== null ? vitals.humidity : '--'} 
                         unit="%" 
                         status="optimal" 
                         icon={Droplets} 
                         trend="stable"
                         customStatusLabel="ENVIRONMENT LEVEL"
                       />
                       <VitalsCard 
                         label="Attending Status" 
                         value={vitals?.current_condition || 'MONITORING'} 
                         unit="" 
                         status={vitals ? getStatusString(vitals.alertLevel) : 'optimal'} 
                         icon={ShieldCheck} 
                         customStatusLabel={vitals?.status === 'critical' ? 'PANIC RED ALERT' : 'SECURE CONNECTED'}
                       />
                    </div>

                    {/* ECG LIVE VIEW */}
                    <div className="grid grid-cols-1 2xl:grid-cols-3 gap-6 md:gap-10">
                       <div className="2xl:col-span-2">
                         <div className="bg-white rounded-[24px] md:rounded-[40px] border border-slate-100 shadow-premium p-5 md:p-10 h-full relative overflow-hidden">
                            <div className="flex items-center justify-between mb-8">
                               <div>
                                  <h3 className="text-lg md:text-xl font-bold text-slate-900 tracking-tight">Live ECG Waveform</h3>
                                  <p className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest mt-1">DIRECT RTDB LINK: HS-001 {isSimulating && <span className="text-emerald-500 font-bold ml-1 animate-pulse">[SIMULATING]</span>}</p>
                               </div>
                               <div className="px-3 py-1 bg-slate-950 text-white rounded-full text-[9px] font-mono tracking-wider uppercase flex items-center gap-2 shadow-sm font-semibold">
                                  <span className="relative flex h-1.5 w-1.5">
                                     <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                     <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-red-500"></span>
                                  </span>
                                  <span>LIVE</span>
                               </div>
                            </div>
                            <div className="h-[340px] border border-slate-100 rounded-2xl overflow-hidden bg-white shadow-inner">
                               <ECGGraph bpm={vitals?.heartRate || 72} liveEcg={vitals?.ecg} spo2={vitals?.o2 || vitals?.spo2} />
                            </div>
                            </div>
                         </div>

                       {/* AI RECOMMENDATION BOX */}
                       <div className="2xl:col-span-1 flex flex-col">
                          <div className="flex-1 bg-slate-950 border border-slate-800 rounded-[24px] md:rounded-[40px] p-6 flex flex-col justify-between shadow-premium min-h-[250px]">
                            <div className="mb-4">
                              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                                <div className="flex items-center gap-2">
                                  <div className="w-1.5 h-1.5 bg-accent-maroon rounded-full animate-ping" />
                                  <h4 className="text-xs font-mono font-bold text-accent-maroon tracking-wider">TELEMETRY STREAM</h4>
                                </div>
                                <span className="text-[8px] font-mono text-slate-400 font-bold">SYS_VER::4.0.2</span>
                              </div>
                              <div className="font-mono text-[10px] space-y-1.5 max-h-40 overflow-y-auto no-scrollbar text-emerald-400">
                                {activeLogs.map((log, index) => (
                                  <div key={index} className="truncate select-text">
                                    <span className="text-slate-600 mr-1">&gt;</span>
                                    <span>{log}</span>
                                  </div>
                                ))}
                                {activeLogs.length === 0 && (
                                  <div className="text-slate-600 italic">Waiting for telemetry frames...</div>
                                )}
                              </div>
                            </div>
                            
                            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between text-[9px] font-mono text-slate-400">
                              <span className="flex items-center gap-1">
                                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                                RTDB ACTIVE
                              </span>
                              <span>PKT_LOSS: 0.00%</span>
                            </div>
                             </div>
                          </div>
                       </div>

                    {/* AI ADVISORY & RESPONSE GUIDELINES */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                      <div className="md:col-span-2 bg-white border border-slate-100 rounded-[32px] p-6 shadow-premium relative overflow-hidden group">
                         <div className="absolute top-0 right-0 p-6 font-mono">
                            <Sparkles className="w-8 h-8 text-accent-maroon/10 group-hover:text-accent-maroon/25 transition-all duration-700" />
                          </div>
                         <div className="relative z-10 flex flex-col h-full">
                            <div className="p-3 bg-red-50 border border-red-100 rounded-xl w-fit mb-4">
                               <Activity className="w-5 h-5 text-accent-maroon" />
                            </div>
                            <h3 className="text-lg font-bold text-slate-800 tracking-tight mb-2">Automated ICU Guard Advisements</h3>
                            <p className="text-slate-500 text-xs leading-relaxed font-mono">
                               {vitals?.heartRate > 130 
                                 ? "🚨 CRITICAL HEART RATE BREACH: Attending physician should immediately review cardiac sinus tachycardia. Have the patient lie down, avoid exertion, and prepare emergency oxygen line." 
                                 : vitals?.o2 > 0 && vitals?.o2 < 90 
                                 ? "🚨 POTENTIAL HYPOXIA CRITICALITY: Oxygen levels are below clinical margin. Ensure the pulse oximeter sensor is secure on the fingertip and start respiratory assistance protocol."
                                 : "Vitals are synchronized perfectly with Cloud Realtime Database nodes. Electro-cardiology baseline normal. No manual interventions advised under protocol HS-001."}
                            </p>
                         </div>
                      </div>

                      <div className="md:col-span-1 bg-white border border-slate-100 rounded-[32px] p-6 shadow-premium flex flex-col justify-between">
                        <div>
                          <h4 className="text-xs font-mono font-bold text-accent-maroon tracking-wider mb-2 uppercase">SATELLITE CONTROLS</h4>
                          <p className="text-[10px] text-slate-400 font-mono mb-4">Toggle hardware simulation to push live ESP32/Arduino data directly to Firebase or silence sound signals.</p>
                        </div>
                        <div className="space-y-2 mt-auto">
                          <button 
                            onClick={() => setIsSimulating(!isSimulating)}
                            className={`w-full py-2.5 rounded-xl font-bold font-mono text-[9px] tracking-widest uppercase transition-all border ${
                              isSimulating 
                                ? 'bg-emerald-600 border-emerald-650 hover:bg-emerald-700 text-white shadow-md shadow-emerald-500/15'
                                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            {isSimulating ? "🛑 STOP SIMULATION" : "📡 START SIMULATION"}
                          </button>
                          <button 
                            onClick={() => {
                              setShowEmergencyPopup(false);
                              setIsSoundEnabled(false);
                            }}
                            className="w-full py-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white rounded-xl font-bold font-mono text-[9px] tracking-widest uppercase transition-all"
                          >
                            Silence Alerts & Beepers
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* EMERGENCY WARNING MODAL OVERLAY */}
                    <AnimatePresence>
                      {showEmergencyPopup && vitals?.status === 'critical' && (
                        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
                          <motion.div 
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1, y: [0, -6, 0] }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            transition={{ duration: 0.35 }}
                            className="bg-white border-2 border-red-500 max-w-lg w-full rounded-[40px] shadow-[0_0_80px_rgba(239,68,68,0.25)] p-8 md:p-10 relative overflow-hidden"
                          >
                            <div className="absolute top-0 right-0 p-8">
                              <AlertCircle className="w-16 h-16 text-red-500/5 animate-pulse" />
                            </div>
                            
                            <div className="flex items-center gap-3.5 mb-6 text-red-650">
                              <div className="p-3 bg-red-50 border border-red-100 rounded-2xl animate-[ping_1.5s_infinite]">
                                <AlertCircle className="w-8 h-8 text-red-500" />
                              </div>
                              <div>
                                <h2 className="text-xl font-bold italic tracking-tight text-slate-900">CRITICAL WARNING STATUS</h2>
                                <p className="text-[8px] font-mono text-red-500 uppercase tracking-widest leading-none mt-0.5 font-bold">ICU Hub Alarm System</p>
                              </div>
                            </div>

                            <p className="text-slate-600 font-mono text-xs leading-relaxed mb-6">
                              Severe physiological drift detected on user hardware logs. Automated clinic protocols have initiated telemetry dispatching. Attending units are notified.
                            </p>

                            <div className="bg-red-50/50 border border-red-100 rounded-2xl p-4 space-y-2 mb-8 font-mono font-black">
                              <div className="flex justify-between items-center text-xs">
                                <span className="text-slate-500">Current Heart Rate:</span>
                                <span className="font-extrabold text-red-600 font-semibold">{vitals?.heartRate} BPM (Normal: 45 - 130)</span>
                              </div>
                              <div className="flex justify-between items-center text-xs">
                                <span className="text-slate-500">Oxygen Saturation:</span>
                                <span className="font-extrabold text-red-600 font-semibold">{vitals?.o2}% (Normal: &gt; 90%)</span>
                              </div>
                            </div>

                            <div className="flex flex-col sm:flex-row gap-3">
                              <button 
                                onClick={() => setShowEmergencyPopup(false)}
                                className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-black font-mono text-[10px] tracking-widest uppercase transition-all shadow-md shadow-red-500/10"
                              >
                                Silence Screen Alert
                              </button>
                              <button 
                                onClick={() => alert("SOS DISPATCH SEQUENCE ACTIVATED. Rescue services and attending medical personnel have been updated via encrypted telemetry.")}
                                className="flex-1 py-3 bg-slate-950 hover:bg-slate-800 border border-slate-200 text-white rounded-xl font-black font-mono text-[10px] tracking-widest uppercase transition-all"
                              >
                                Verify Attending SOS
                              </button>
                            </div>
                          </motion.div>
                        </div>
                      )}
                    </AnimatePresence>

                    <div className="hidden" />
                  </motion.div>
               ))}
              {activeTab === 'history' && (
                <motion.div 
                  key="history"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                   <div className="bg-white rounded-[32px] md:rounded-[40px] border border-slate-100 shadow-premium overflow-hidden">
                      <div className="p-6 md:p-10 border-b border-slate-50 flex flex-col sm:flex-row justify-between items-center gap-6">
                         <div className="text-center sm:text-left">
                            <h3 className="text-lg md:text-xl font-black text-slate-900 tracking-tight italic">Telemetry Audit Logs</h3>
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Updates every 60 seconds</p>
                         </div>
                         <div className="flex gap-3 md:gap-4 w-full sm:w-auto">
                            <button className="flex-1 sm:flex-none px-4 md:px-6 py-2.5 md:py-3 bg-slate-50 text-slate-400 rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 transition-all">Filter</button>
                            <button className="flex-1 sm:flex-none px-4 md:px-6 py-2.5 md:py-3 bg-slate-900 text-white rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest shadow-lg shadow-slate-900/10">Export PDF</button>
                         </div>
                      </div>
                      <div className="overflow-x-auto no-scrollbar">
                         <table className="w-full text-left border-collapse min-w-[600px]">
                            <thead>
                               <tr className="bg-slate-50/50">
                                  <th className="px-6 md:px-10 py-4 md:py-5 text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">Timestamp</th>
                                  <th className="px-6 md:px-10 py-4 md:py-5 text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">BPM</th>
                                  <th className="px-6 md:px-10 py-4 md:py-5 text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">SpO2</th>
                                  <th className="px-6 md:px-10 py-4 md:py-5 text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Temp</th>
                                  <th className="px-6 md:px-10 py-4 md:py-5 text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Status</th>
                               </tr>
                            </thead>
                            <tbody>
                               {history.map((log) => (
                                 <tr key={log.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/30 transition-all">
                                    <td className="px-6 md:px-10 py-5 md:py-6">
                                       <div className="flex items-center gap-3">
                                          <div className="p-2 bg-slate-100 rounded-lg shrink-0">
                                             <Clock className="w-3.5 h-3.5 text-slate-400" />
                                          </div>
                                          <div>
                                             <p className="text-sm font-black text-slate-900 tracking-tight">{new Date(log.timestamp).toLocaleTimeString()}</p>
                                             <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">{new Date(log.timestamp).toLocaleDateString()}</p>
                                          </div>
                                       </div>
                                    </td>
                                    <td className="px-6 md:px-10 py-5 md:py-6 text-center font-black text-slate-900 italic">{log.heartRate}</td>
                                    <td className="px-6 md:px-10 py-5 md:py-6 text-center font-black text-slate-900 italic">{log.o2}%</td>
                                    <td className="px-6 md:px-10 py-5 md:py-6 text-center font-black text-slate-900 italic">{log.temp.toFixed(1)}°</td>
                                    <td className="px-6 md:px-10 py-5 md:py-6 text-right">
                                       <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${
                                         log.heartRate > 100 ? 'bg-red-50 text-accent-maroon' : 'bg-green-50 text-green-600'
                                       }`}>
                                          {log.status || 'Optimal'}
                                       </span>
                                    </td>
                                 </tr>
                               ))}
                               {history.length === 0 && (
                                 <tr>
                                    <td colSpan={5} className="px-6 md:px-10 py-20 text-center">
                                       <Activity className="w-10 h-10 text-slate-200 mx-auto mb-4 animate-pulse" />
                                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Synchronizing History with EMR Nodes...</p>
                                    </td>
                                 </tr>
                               )}
                            </tbody>
                         </table>
                      </div>
                   </div>
                </motion.div>
              )}

              {activeTab === 'location' && (
                <motion.div 
                  key="location"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-[500px] md:h-full rounded-[32px] md:rounded-[40px] overflow-hidden border border-slate-100 shadow-premium"
                >
                  <LiveLocation />
                </motion.div>
              )}

              {activeTab === 'settings' && (
                <motion.div 
                  key="settings"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8"
                >
                   <div className="bg-white rounded-[32px] md:rounded-[40px] p-6 md:p-10 border border-slate-100 shadow-premium space-y-8 md:space-y-10">
                      <div>
                         <h3 className="text-lg md:text-xl font-black text-slate-900 tracking-tight italic mb-1">General Preferences</h3>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Interface and interaction</p>
                      </div>
                      <div className="space-y-6">
                         <ToggleItem label="Biometric Sync" sub="Real-time data propagation" active />
                         <ToggleItem label="Emergency Sound Alert" sub="Critical event notification" active />
                         
                         {/* Local Notifications Toggle */}
                         <div className="flex items-center justify-between group pt-2 border-t border-slate-50">
                            <div>
                               <p className="text-sm font-black text-slate-900 tracking-tight">Local Notifications</p>
                               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight italic">Push alerts on threshold breaches</p>
                            </div>
                            <button 
                               onClick={async () => {
                                 if ('Notification' in window) {
                                   if (Notification.permission !== 'granted') {
                                     const res = await Notification.requestPermission();
                                     setNotificationsEnabled(res === 'granted');
                                   } else {
                                     setNotificationsEnabled(!notificationsEnabled);
                                   }
                                 } else {
                                   alert('Local Notifications are not supported by your current browser.');
                                 }
                               }}
                               className={`w-12 h-6 rounded-full p-1 transition-all duration-300 flex items-center ${notificationsEnabled ? 'bg-accent-maroon justify-end' : 'bg-slate-200 justify-start'}`}
                            >
                               <motion.div layout className="w-4 h-4 bg-white rounded-full shadow-md" />
                            </button>
                         </div>

                         {/* Heart Rate threshold setting */}
                         <div className="space-y-2 pt-4 border-t border-slate-50">
                            <div className="flex justify-between items-center">
                               <p className="text-sm font-black text-slate-900 tracking-tight">HR Threshold Limit</p>
                               <span className="text-xs font-mono font-black text-accent-maroon bg-accent-maroon/5 px-2 py-0.5 rounded-md">{heartRateThreshold} BPM</span>
                            </div>
                            <input 
                               type="range" 
                               min="80" 
                               max="160" 
                               value={heartRateThreshold} 
                               onChange={(e) => setHeartRateThreshold(Number(e.target.value))}
                               className="w-full accent-accent-maroon cursor-pointer"
                            />
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.05em] leading-relaxed italic">
                               Triggers immediate biometic warnings when raw readout exceeds safety value.
                            </p>
                         </div>
                      </div>
                   </div>

                   <div className="bg-white rounded-[32px] md:rounded-[40px] p-6 md:p-10 border border-slate-100 shadow-premium space-y-8 md:space-y-10">
                      <div>
                         <h3 className="text-lg md:text-xl font-black text-slate-900 tracking-tight italic mb-1">Privacy Protocol</h3>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Data sharing and isolation</p>
                      </div>
                      <div className="space-y-6">
                         <ToggleItem label="Share Live GPS" sub="Visible to emergency responders" active />
                         <ToggleItem label="Anonymous Training" sub="AI neural model improvement" />
                         <ToggleItem label="Cloud Persistence" sub="Store historical telemetry" active />
                      </div>
                   </div>
                </motion.div>
              )}
           </AnimatePresence>
        </div>
      </main>

      {/* FLOATING AI ASSISTANT */}
      <AIChatWidget userId={userId} />

      {/* MANUAL GLOBAL EMERGENCY STATUS & LOCATION TRACKER MODAL */}
      <AnimatePresence>
        {showPatientEmergencyModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/85 backdrop-blur-md z-[9999] flex items-center justify-center p-4 font-sans"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="w-full max-w-xl bg-white rounded-[32px] overflow-hidden shadow-2xl relative border-2 border-accent-maroon/20 p-6 md:p-10 space-y-6 md:space-y-8"
            >
              {/* HEADER WARNING SECTION */}
              <div className="flex items-center gap-4 border-b border-slate-100 pb-5">
                <div className="p-3 bg-red-100 rounded-2xl shrink-0 animate-pulse">
                  <ShieldAlert className="w-8 h-8 text-accent-maroon animate-bounce" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-red-500">HEARTSYNC PANIC RESPONDER ACTIVE</span>
                  <h3 className="text-xl md:text-2xl font-black italic tracking-tight text-slate-900 leading-none mt-1">EMERGENCY BROADCAST LIVE</h3>
                </div>
              </div>

              {/* MESSAGE CONTENT */}
              <div className="space-y-4">
                <p className="text-slate-600 text-sm leading-relaxed">
                  Your manual distress signal was transmitted simultaneously in real-time. Connected cardiologists, ER surgeons, and ambulance routing centers have been notified of your immediate physiological urgency.
                </p>

                {/* CURRENT TRACKED GPS COORDINATES CONTAINER */}
                <div className="bg-red-50/50 border border-red-100/60 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center gap-2 text-red-700">
                    <MapPin className="w-5 h-5 animate-pulse shrink-0" />
                    <span className="text-[11px] font-black uppercase tracking-wider">YOUR LAST KNOWN GPS POSITION</span>
                  </div>
                  
                  {emergencyLocationCoords ? (
                    <div className="grid grid-cols-2 gap-4 font-mono text-xs">
                      <div className="bg-white p-3 rounded-xl border border-red-100/30">
                        <span className="text-slate-400 font-bold uppercase text-[9px] block mb-1">LATITUDE</span>
                        <span className="font-extrabold text-slate-800 italic">{emergencyLocationCoords.latitude.toFixed(6)}° N</span>
                      </div>
                      <div className="bg-white p-3 rounded-xl border border-red-100/30">
                        <span className="text-slate-400 font-bold uppercase text-[9px] block mb-1">LONGITUDE</span>
                        <span className="font-extrabold text-slate-800 italic">{emergencyLocationCoords.longitude.toFixed(6)}° W</span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-slate-400 text-xs italic">Acquiring high-precision coordinates...</p>
                  )}

                  <div className="text-[9px] font-mono text-slate-400 flex items-center justify-between">
                    <span>ACCURACY: ± 3 METERS</span>
                    <span>BEARING: NOMINAL TRACK</span>
                  </div>
                </div>
              </div>

              {/* ACTION DIALOG BUTTONS */}
              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-150">
                <button 
                  onClick={handleResetGlobalEmergency}
                  className="w-full py-4 border-2 border-dashed border-slate-200 text-slate-500 hover:border-slate-600 rounded-xl font-black uppercase tracking-widest text-xs transition-all cursor-pointer text-center"
                >
                  STAND DOWN (FALSE ALERT)
                </button>
                <div className="w-full py-4 bg-accent-maroon text-white rounded-xl font-black uppercase tracking-widest text-xs text-center shadow-lg shadow-accent-maroon/20 animate-pulse">
                  LINE CONNECTED // RESPONDERS LIVE
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};

const MetricSmall = ({ label, value }: { label: string; value: string }) => (
  <div className="text-center">
     <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1">{label}</p>
     <p className="text-lg font-black text-slate-900 italic tracking-tighter">{value}</p>
  </div>
);

const ToggleItem = ({ label, sub, active }: { label: string; sub: string; active?: boolean }) => (
  <div className="flex items-center justify-between group">
     <div>
        <p className="text-sm font-black text-slate-900 tracking-tight">{label}</p>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight italic">{sub}</p>
     </div>
     <button className={`w-12 h-6 rounded-full p-1 transition-all duration-300 flex items-center ${active ? 'bg-accent-maroon justify-end' : 'bg-slate-200 justify-start'}`}>
        <motion.div layout className="w-4 h-4 bg-white rounded-full shadow-md" />
     </button>
  </div>
);

export default PatientDashboard;

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Stethoscope, 
  Users, 
  Activity, 
  Bell, 
  MapPin, 
  Search, 
  Filter, 
  ArrowRight, 
  HeartPulse, 
  AlertCircle,
  Clock,
  Shield,
  ShieldCheck,
  LogOut,
  ChevronRight,
  TrendingUp,
  Menu,
  X,
  Volume2,
  VolumeX,
  FileDown
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { collection, query, where, onSnapshot, limit, orderBy } from 'firebase/firestore';
import { db, rtdb } from '../lib/firebase';
import { ref, onValue, set } from 'firebase/database';
import DoctorSidebar from '../components/DoctorSidebar';
import ECGGraph from '../components/patient/ECGGraph';
import { useRef } from 'react';
import { generateVitalsPDF } from '../utils/pdfGenerator';

const DoctorDashboard = () => {
  const { profile, logout, user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [patients, setPatients] = useState<any[]>([]);
  const [filter, setFilter] = useState<'all' | 'critical' | 'stable'>('all');
  const [vitalsMap, setVitalsMap] = useState<Record<string, any>>({});
  const [alerts, setAlerts] = useState<any[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const [rtdbUsers, setRtdbUsers] = useState<Record<string, any>>({});
  const [isAlertMuted, setIsAlertMuted] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const soundIntervalRef = useRef<any>(null);

  // Pop-up lifecycle state machine state variables
  const [activeNodeData, setActiveNodeData] = useState<any>(null);
  const [dismissedAlertInstances, setDismissedAlertInstances] = useState<string[]>([]);
  const [envelopeStartTime, setEnvelopeStartTime] = useState<number>(0);

  useEffect(() => {
    if (profile?.role !== 'doctor') {
      navigate('/');
      return;
    }

    const qPatients = query(
      collection(db, 'users'),
      where('role', '==', 'patient'),
      where('status', '==', 'approved'),
      limit(20)
    );

    const unsubPatients = onSnapshot(qPatients, (snap) => {
      setPatients(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });

    const qAlerts = query(
      collection(db, 'emergencyAlerts'),
      orderBy('detectedAt', 'desc'),
      limit(5)
    );

    const unsubAlerts = onSnapshot(qAlerts, (snap) => {
      setAlerts(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Real-time listener for all patient biometrics from Firestore as backup
    const unsubVitals = onSnapshot(collection(db, 'liveHealthMetrics'), (snap) => {
      const metrics: Record<string, any> = {};
      snap.forEach(docSnap => {
        metrics[docSnap.id] = docSnap.data();
      });
      setVitalsMap(prev => ({ ...prev, ...metrics }));
    });

    // Real-time listener for all patient telemetry from RTDB (Main source of truth for alerts)
    const usersRef = ref(rtdb, '/users');
    const unsubUsersRTDB = onValue(usersRef, (snapshot) => {
      const data = snapshot.val();
      if (snapshot.exists() && data) {
        setRtdbUsers(data);
        const rtdbVitals: Record<string, any> = {};
        Object.keys(data).forEach(userId => {
          const userNode = data[userId];
          const live = userNode.liveReading || userNode.livereading;
          if (live) {
            const rawHr = live.BPM !== undefined ? Number(live.BPM) : (live.bpm !== undefined ? Number(live.bpm) : (live.heartRate !== undefined ? Number(live.heartRate) : (live.HeartRate !== undefined ? Number(live.HeartRate) : 72)));
            const rawO2 = live.SpO2 !== undefined ? Number(String(live.SpO2).replace('%', '')) : (live.spo2 !== undefined ? Number(live.spo2) : (live.SPO2 !== undefined ? Number(live.SPO2) : (live.o2 !== undefined ? Number(live.o2) : 98)));
            const rawTemp = live.Temp !== undefined ? Number(String(live.Temp).replace(/[CF\s]/gi, '')) : (live.temperature !== undefined ? Number(live.temperature) : (live.temp !== undefined ? Number(live.temp) : (live.Temperature !== undefined ? Number(live.Temperature) : 36.5)));
            const rawHum = live.Humidity !== undefined ? Number(String(live.Humidity).replace('%', '')) : (live.humidity !== undefined ? Number(live.humidity) : 55);
            
            const hrValue = Math.round(rawHr);
            const o2Value = Math.round(rawO2);
            const tempValue = Number(rawTemp.toFixed(1));
            const humValue = Math.round(rawHum);

            let ecgValue: number | number[] | string = 512;
            const rawEcg = live.ECG !== undefined ? live.ECG : (live.ecg !== undefined ? live.ecg : undefined);
            if (rawEcg !== undefined) {
              if (Array.isArray(rawEcg)) {
                ecgValue = rawEcg.map(Number).filter(v => !isNaN(v));
              } else if (typeof rawEcg === 'string') {
                ecgValue = rawEcg;
              } else {
                ecgValue = isNaN(Number(rawEcg)) ? 512 : Number(rawEcg);
              }
            }

            rtdbVitals[userId] = {
              heartRate: hrValue,
              bpm: hrValue,
              o2: o2Value,
              temp: tempValue,
              humidity: humValue,
              ecg: ecgValue,
              isEmergency: live.isEmergency === true || live.alertLevel === 3 || live.alertLevel === 4 || hrValue > 140 || hrValue < 40 || o2Value < 90,
              status: (live.alertLevel === 3 || live.alertLevel === 4 || hrValue > 140 || o2Value < 90) ? 'critical' : live.alertLevel === 2 ? 'warning' : 'optimal'
            };
          }
        });
        
        setVitalsMap(prev => {
          let hasChange = false;
          const updated = { ...prev };
          Object.keys(rtdbVitals).forEach(uid => {
            const incoming = rtdbVitals[uid];
            const existing = prev[uid];
            if (!existing) {
              hasChange = true;
              updated[uid] = incoming;
            } else {
              const isDifferent = 
                existing.heartRate !== incoming.heartRate ||
                existing.bpm !== incoming.bpm ||
                existing.o2 !== incoming.o2 ||
                existing.temp !== incoming.temp ||
                existing.humidity !== incoming.humidity ||
                existing.isEmergency !== incoming.isEmergency ||
                existing.status !== incoming.status;
              
              if (isDifferent) {
                hasChange = true;
                updated[uid] = incoming;
              }
            }
          });
          return hasChange ? updated : prev;
        });
      }
    });

    // Real-Time Data Sync: Listen to live parameters under patients/active_node
    const activeNodeRef = ref(rtdb, 'patients/active_node');
    const unsubActiveNode = onValue(activeNodeRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        setActiveNodeData(val);
      } else {
        setActiveNodeData(null);
      }
    });

    return () => {
      unsubPatients();
      unsubAlerts();
      unsubVitals();
      unsubUsersRTDB();
      unsubActiveNode();
    };
  }, [profile, navigate]);

  // Find the active critical patient dynamically
  let criticalPatientId = "";
  let criticalPatientData = null;
  let criticalVitals: any = null;

  Object.keys(vitalsMap).forEach(uid => {
    const v = vitalsMap[uid];
    const pt = patients.find(p => p.id === uid) || 
               (rtdbUsers[uid] ? { 
                 id: uid, 
                 displayName: rtdbUsers[uid].fullName || rtdbUsers[uid].displayName || rtdbUsers[uid].name || `Patient ${uid.substring(0, 5).toUpperCase()}`, 
                 ...rtdbUsers[uid] 
               } : {
                 id: uid,
                 displayName: `Patient ${uid.substring(0, 5).toUpperCase()}`
               });
    
    if (pt && v) {
      const isHrCritical = v.heartRate > 140 || v.heartRate < 40;
      const isO2Critical = v.o2 < 90;
      const isTempCritical = v.temp > 38.5 || v.temp < 35.0;
      
      if (isHrCritical || isO2Critical || isTempCritical || v.isEmergency || v.alertLevel === 3 || v.alertLevel === 4) {
        criticalPatientId = uid;
        criticalPatientData = pt;
        criticalVitals = {
          heartRate: v.heartRate || 0,
          o2: v.o2 || 0,
          temp: v.temp || 0,
          humidity: v.humidity || 55,
          ecg: v.ecg || 512,
          isHrCritical,
          isO2Critical,
          isTempCritical
        };
      }
    }
  });

  const isAnyCritical = !!criticalPatientId;

  // Active Critical Emergency Envelope Start Time Tracker
  useEffect(() => {
    if (criticalPatientId) {
      setEnvelopeStartTime(prev => prev === 0 ? Date.now() : prev);
    } else {
      setEnvelopeStartTime(0);
    }
  }, [criticalPatientId]);

  // Current Alert Instance Unique Session Identifier (Section 1)
  const currentAlertInstanceId = activeNodeData?.currentAlertInstanceId || 
                                activeNodeData?.alertId || 
                                (envelopeStartTime ? `${criticalPatientId}_${envelopeStartTime}` : "");

  // The Core Suppression Logic Gate (Section 2)
  const isDismissed = dismissedAlertInstances.includes(currentAlertInstanceId);
  const isModalVisible = isAnyCritical && !!currentAlertInstanceId && !isDismissed;

  // --- Section 3: POPUP ACTION TRANSACTION HANDLERS ---
  
  const handleCloseModalCrossClick = () => {
    stopAmbulanceSiren();
    if (currentAlertInstanceId) {
      setDismissedAlertInstances(prev => {
        if (!prev.includes(currentAlertInstanceId)) {
          return [...prev, currentAlertInstanceId];
        }
        return prev;
      });
    }
  };

  const handleMuteSirenAudio = () => {
    setIsAlertMuted(prev => !prev);
  };

  const handleRejectFalseAlert = async () => {
    if (!criticalPatientId) return;
    stopAmbulanceSiren();
    try {
      // 1. Drop active patient's liveReading back to normal levels
      const liveRef = ref(rtdb, `/users/${criticalPatientId}/liveReading`);
      await set(liveRef, {
        heartRate: 72,
        bpm: 72,
        spo2: 98,
        temperature: 36.5,
        humidity: 55,
        ecg: 512,
        isEmergency: false,
        alertLevel: 1
      });

      // 2. Clear patients/active_node to resolve across clients
      const activeNodeRef = ref(rtdb, 'patients/active_node');
      await set(activeNodeRef, null);

      // 3. Clear alert_state in patient scope
      const alertStateRef = ref(rtdb, `/patients/${criticalPatientId}/alert_state`);
      await set(alertStateRef, {
        level: 1,
        status: 'Stable',
        timestamp: Date.now(),
        is_acknowledged: true
      });
    } catch (e) {
      console.error("Failed to reject false alert:", e);
    }
  };

  const handleAcceptEmergency = async () => {
    if (!criticalPatientId) return;
    stopAmbulanceSiren();
    try {
      // 1. Sets a database variable `isAcknowledged: true` under the active session node
      const activeNodeRef = ref(rtdb, 'patients/active_node');
      await set(activeNodeRef, {
        patientId: criticalPatientId,
        isAcknowledged: true,
        acknowledgedAt: Date.now(),
        currentAlertInstanceId
      });

      // Also set patient's alert_state acknowledgement
      const alertStateRef = ref(rtdb, `/patients/${criticalPatientId}/alert_state`);
      await set(alertStateRef, {
        level: 4,
        status: 'Incident Acknowledged',
        timestamp: Date.now(),
        is_acknowledged: true
      });

      // 2. Safely close this popup by dismissing it
      if (currentAlertInstanceId) {
        setDismissedAlertInstances(prev => {
          if (!prev.includes(currentAlertInstanceId)) {
            return [...prev, currentAlertInstanceId];
          }
          return prev;
        });
      }
    } catch (e) {
      console.error("Failed to acknowledge emergency:", e);
    }

    // 3. Navigate/focus onto details
    navigate(`/doctor/patient/${criticalPatientId}`);
  };

  const handleDownloadSnapshot = () => {
    if (!criticalPatientId) return;
    const patientDataInfo = {
      name: criticalPatientData?.displayName || criticalPatientData?.fullName || `Patient ${criticalPatientId.substring(0, 5).toUpperCase()}`,
      age: String(criticalPatientData?.age || '54'),
      gender: criticalPatientData?.gender || 'Male',
      bloodGroup: criticalPatientData?.bloodGroup || 'O+',
      phoneNumber: criticalPatientData?.phoneNumber || '+91 95737 32216',
      condition: criticalPatientData?.condition || "Post-Myocardial Infarction Telemetry"
    };

    const snapshotVitals = {
      heartRate: criticalVitals?.heartRate || 135,
      o2: criticalVitals?.o2 || 88,
      temp: criticalVitals?.temp || 38.6,
      humidity: criticalVitals?.humidity || 52,
      status: 'CRITICAL',
      ecgCondition: 'Tachyarrhythmia segment with ST deviation',
      anomalyDetected: 'Elevation of ST wave & depressed SpO PERVASION indicate acute myocardium constraints.',
      recommendations: '1. Establish direct intravenous clinical lines immediately.\n2. Administer oxygen ventilation support to restore SpO2 to >95%.\n3. Prepare defibrillating telemetry systems and continuous monitoring.\n4. Call emergency dispatch / ICU backup.'
    };

    generateVitalsPDF(patientDataInfo, snapshotVitals);
  };

  const startAmbulanceSiren = () => {
    if (isAlertMuted) {
      stopAmbulanceSiren();
      return;
    }
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      
      if (soundIntervalRef.current) {
        clearInterval(soundIntervalRef.current);
      }

      let waveState = false;
      soundIntervalRef.current = setInterval(() => {
        if (!ctx || ctx.state === 'suspended') return;
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();

        // Dual-frequency sweep simulating continuous ambulance siren
        osc.type = 'sawtooth';
        const targetFreq = waveState ? 960 : 640;
        osc.frequency.setValueAtTime(targetFreq, ctx.currentTime);
        
        gainNode.gain.setValueAtTime(0, ctx.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.05);
        gainNode.gain.linearRampToValueAtTime(0.06, ctx.currentTime + 0.4);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.48);

        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
        waveState = !waveState;
      }, 500);
    } catch (e) {
      console.warn("Audio context playback error caught gracefully:", e);
    }
  };

  const stopAmbulanceSiren = () => {
    if (soundIntervalRef.current) {
      clearInterval(soundIntervalRef.current);
      soundIntervalRef.current = null;
    }
  };

  useEffect(() => {
    if (isModalVisible && !isAlertMuted) {
      startAmbulanceSiren();
    } else {
      stopAmbulanceSiren();
    }
    return () => {
      stopAmbulanceSiren();
    };
  }, [isModalVisible, isAlertMuted]);

  return (
    <div className="min-h-screen bg-slate-50 flex overflow-hidden">
      <title>Clinical Portal | HeartSync Doctor</title>
      
      {/* MOBILE OVERLAY */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[80] lg:hidden"
          />
        )}
      </AnimatePresence>

      <DoctorSidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />

      {/* MAIN CONTENT */}
      <main className="flex-1 flex flex-col min-w-0 min-h-screen lg:h-screen lg:overflow-hidden">
        <header className="h-20 md:h-24 bg-white border-b border-slate-200 px-4 sm:px-6 md:px-12 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3 md:gap-4">
             <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 text-slate-400 hover:text-accent-maroon transition-all">
                <Menu className="w-6 h-6" />
             </button>
             <div className="hidden lg:block">
               <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight italic">Clinical Registry</h2>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">Real-time Telemetry Processing</p>
             </div>
             <div className="lg:hidden">
               <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight italic">Registry</h2>
             </div>
          </div>
          <div className="flex items-center gap-3 md:gap-4">
            <button className="relative p-2.5 bg-slate-50 text-slate-400 rounded-xl hover:text-accent-maroon hover:bg-accent-maroon/5 transition-all">
                <Bell className="w-5 h-5" />
                <div className="absolute top-2 right-2 w-2 h-2 bg-accent-maroon rounded-full border-2 border-white" />
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-12 no-scrollbar">
           <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
              
              {/* LEFT & CENTER: Patient Monitoring */}
              <div className="lg:col-span-2 space-y-6 md:space-y-10">
                 {/* Live Status Overview */}
                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
                    <StatCard label="Live Monitored" value={patients.length} sub="Approved Nodes" trend="+12%" icon={Activity} />
                    <StatCard label="Critical Triggers" value={alerts.filter(a => a.severity === 'CRITICAL').length} sub="Immediate Action" trend="High" icon={AlertCircle} color="maroon" />
                 </div>

                 {/* Monitoring Grid */}
                 <div className="bg-white rounded-[24px] md:rounded-[48px] border border-slate-100 shadow-premium p-5 md:p-10">
                    <div className="flex flex-col gap-4 md:flex-row justify-between items-center mb-6 md:mb-10">
                       <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tighter italic text-center md:text-left">Active Telemetry Feed</h3>
                       <div className="flex bg-slate-50 p-1 rounded-xl md:rounded-2xl border border-slate-100 w-full md:w-auto overflow-x-auto no-scrollbar">
                          <FilterButton active={filter === 'all'} onClick={() => setFilter('all')}>All Nodes</FilterButton>
                          <FilterButton active={filter === 'critical'} onClick={() => setFilter('critical')}>Critical</FilterButton>
                       </div>
                    </div>

                    <div className="space-y-3 md:space-y-4">
                       {patients.length > 0 ? patients.filter((p) => {
                         if (filter === 'critical') return vitalsMap[p.id]?.isEmergency === true;
                         return true;
                       }).map((patient) => {
                         const v = vitalsMap[patient.id];
                         const isEmergency = v?.isEmergency;
                         return (
                         <div 
                           key={patient.id}
                           onClick={() => navigate(`/doctor/patient/${patient.id}`)}
                           className="group flex items-center justify-between p-4 md:p-6 bg-slate-50/50 hover:bg-white rounded-2xl md:rounded-3xl border border-transparent hover:border-slate-100 hover:shadow-xl transition-all cursor-pointer"
                         >
                            <div className="flex items-center gap-4 md:gap-5 min-w-0">
                               <div className="w-12 h-12 md:w-14 md:h-14 bg-slate-900 rounded-xl md:rounded-2xl flex items-center justify-center text-white text-lg md:text-xl font-black overflow-hidden shadow-lg shrink-0">
                                  {patient.photoURL ? <img src={patient.photoURL} alt="" className="w-full h-full object-cover" /> : patient.displayName?.charAt(0) || 'P'}
                               </div>
                               <div className="truncate">
                                  <p className="font-black text-slate-900 tracking-tight italic truncate">{patient.displayName || 'Unnamed Patient'}</p>
                                  <div className="flex items-center gap-2">
                                     <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${v ? (isEmergency ? 'bg-red-500 animate-pulse' : 'bg-green-500') : 'bg-slate-300'}`} />
                                     <span className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">
                                       {v ? (isEmergency ? 'Signal: Critical Trigger' : 'Signal: Stable') : 'Signal: Offline'}
                                     </span>
                                  </div>
                               </div>
                            </div>
                            
                            <div className="hidden sm:flex gap-6 md:gap-10 shrink-0">
                               <div>
                                  <p className="text-[8px] md:text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Pulse Rate</p>
                                  <p className={`text-base md:text-lg font-black tracking-tighter ${isEmergency ? 'text-red-500 font-bold' : 'text-slate-900'}`}>
                                    {v?.heartRate || '--'} <span className="text-[10px] font-bold text-slate-400">BPM</span>
                                  </p>
                               </div>
                               <div>
                                  <p className="text-[8px] md:text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Oxygen</p>
                                  <p className={`text-base md:text-lg font-black tracking-tighter ${v?.o2 < 95 ? 'text-amber-500 font-bold' : 'text-slate-900'}`}>
                                    {v?.o2 || '--'} <span className="text-[10px] font-bold text-slate-400">%</span>
                                  </p>
                               </div>
                            </div>

                            <button className="p-2.5 md:p-3 bg-white text-slate-400 rounded-xl border border-slate-100 group-hover:bg-accent-maroon group-hover:text-white group-hover:border-accent-maroon transition-all shrink-0">
                               <ChevronRight className="w-4 h-4 md:w-5 md:h-5" />
                            </button>
                         </div>
                       );
                      }) : (
                         <div className="py-12 text-center">
                            <Clock className="w-10 h-10 text-slate-200 mx-auto mb-4" />
                            <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Awaiting cloud synchronization...</p>
                         </div>
                       )}
                    </div>
                 </div>
              </div>

              {/* RIGHT: Alerts & Logs */}
              <div className="space-y-6 md:space-y-10">
                 <div className="bg-white rounded-[24px] md:rounded-[40px] border border-slate-100 shadow-premium p-5 md:p-8 overflow-hidden h-full">
                    <div className="flex items-center justify-between mb-8">
                       <h3 className="text-xl font-black text-slate-900 tracking-tighter italic">Emergency Logs</h3>
                       <span className="px-3 py-1 bg-accent-maroon text-white text-[9px] font-black uppercase tracking-widest rounded-lg">Live</span>
                    </div>

                    <div className="space-y-6">
                       {alerts.length > 0 ? alerts.map((alert) => (
                         <div 
                           key={alert.id} 
                           onClick={() => navigate(`/doctor/patient/${alert.patientId}`)}
                           className="relative pl-6 border-l-2 border-slate-100 pb-2 cursor-pointer hover:bg-slate-50 transition-colors"
                         >
                            <div className={`absolute -left-[5px] top-0 w-2 h-2 rounded-full ${
                              alert.severity === 'CRITICAL' ? 'bg-accent-maroon' : 'bg-amber-500'
                            }`} />
                            <div className="mb-2">
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                  {alert.detectedAt ? new Date(alert.detectedAt).toLocaleTimeString() : 'Just now'}
                               </p>
                               <h4 className="font-bold text-slate-900 truncate">{alert.patientName || 'Active Node'}</h4>
                            </div>
                            <div className={`p-4 rounded-2xl flex items-center justify-between gap-2 ${
                              alert.severity === 'CRITICAL' ? 'bg-accent-maroon/5 border border-accent-maroon/10' : 'bg-amber-50 border border-amber-100'
                            }`}>
                               <div className="min-w-0">
                                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Status</p>
                                  <p className={`text-lg md:text-xl font-black truncate ${alert.severity === 'CRITICAL' ? 'text-accent-maroon' : 'text-amber-600'}`}>{alert.severity}</p>
                               </div>
                               <button className="px-3 py-1.5 bg-white rounded-lg text-[9px] font-black uppercase tracking-widest text-slate-600 shadow-sm shrink-0">Review</button>
                            </div>
                         </div>
                       )) : (
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center py-10">No recent incidents</p>
                       )}
                    </div>
                    
                    <button 
                      onClick={() => navigate('/doctor/alerts')}
                      className="w-full mt-8 py-4 border-2 border-dashed border-slate-100 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:border-accent-maroon/30 hover:text-accent-maroon transition-all"
                    >
                       View Complete Audit Log
                    </button>
                 </div>
              </div>

           </div>
        </div>
      </main>

      {/* FULL MEDICAL EMERGENCY POPUP OVERLAY */}
      <AnimatePresence>
        {isModalVisible && (
           <motion.div 
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             exit={{ opacity: 0 }}
             className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[9999] flex items-center justify-center p-4 overflow-y-auto"
           >
             <motion.div 
               initial={{ scale: 0.9, y: 20 }}
               animate={{ scale: 1, y: 0 }}
               exit={{ scale: 0.9, y: 20 }}
               className="w-full max-w-4xl bg-white rounded-[32px] md:rounded-[48px] overflow-hidden shadow-2xl relative border-2 border-accent-maroon/20 my-8 shadow-accent-maroon/10 animate-pulse-border"
             >
               {/* WRONG SYMBOL / CLOSE ICON */}
               <button 
                 onClick={handleCloseModalCrossClick}
                 className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all cursor-pointer z-10"
                 title="Clinical Diagnostics (Page 3)"
               >
                 <X className="w-5 h-5 border border-white rounded-full p-0.5" />
               </button>

               {/* HEADER CARD */}
               <div className="bg-accent-maroon text-white p-8 md:p-12 flex items-center gap-6">
                 <div className="p-4 bg-white/15 rounded-3xl shrink-0 animate-bounce">
                    <AlertCircle className="w-10 h-10 text-white" />
                 </div>
                 <div>
                    <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/70">HEARTSYNC MEDICAL ALERT</span>
                    <h2 className="text-2xl md:text-3xl font-black italic tracking-tight leading-none mt-1">FULL MEDICAL EMERGENCY</h2>
                 </div>
               </div>

               {/* CONTENT CARD */}
               <div className="p-6 md:p-12 space-y-8">
                 {/* DYNAMIC ALERT BRIEF */}
                 <div className="bg-red-50/50 border border-red-100 rounded-2xl p-6 flex gap-4 items-start">
                    <span className="text-xl">⚠️</span>
                    <p className="text-slate-700 text-sm font-bold leading-relaxed">
                      {criticalVitals?.isHrCritical && criticalVitals?.isO2Critical && criticalVitals?.isTempCritical ? (
                        "Heart Rate, SpO2, and Temperature are ALL in critical ranges. Immediate life-saving intervention required."
                      ) : (
                        `Warning: ${[
                          criticalVitals?.isHrCritical ? 'Heart Rate' : '',
                          criticalVitals?.isO2Critical ? 'Blood Oxygen' : '',
                          criticalVitals?.isTempCritical ? 'Temperature' : ''
                        ].filter(Boolean).join(', ')} is in critical range. Immediate medical assistance is on the way.`
                      )}
                    </p>
                 </div>

                 {/* PARAMETER CARDS DETAILED GRID */}
                 <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                    {/* HEART RATE */}
                    <div className={`p-6 rounded-[24px] border ${criticalVitals?.isHrCritical ? 'bg-red-50/60 border-red-200 text-red-700' : 'bg-slate-50 border-slate-100 text-slate-700'} flex flex-col justify-between`}>
                       <div>
                          <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Heart Rate</p>
                          <p className="text-3xl font-black italic tracking-tighter mt-2">{criticalVitals?.heartRate || 0} <span className="text-xs font-bold uppercase text-slate-400">BPM</span></p>
                       </div>
                       <span className={`text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md self-start mt-4 ${criticalVitals?.isHrCritical ? 'bg-red-500/10 text-red-600' : 'bg-slate-200/50 text-slate-500'}`}>
                          {criticalVitals?.isHrCritical ? 'CRITICAL' : 'OPTIMAL'}
                       </span>
                    </div>

                    {/* BLOOD OXYGEN */}
                    <div className={`p-6 rounded-[24px] border ${criticalVitals?.isO2Critical ? 'bg-red-50/60 border-red-200 text-red-700' : 'bg-slate-50 border-slate-100 text-slate-700'} flex flex-col justify-between`}>
                       <div>
                          <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Blood Oxygen</p>
                          <p className="text-3xl font-black italic tracking-tighter mt-2">{criticalVitals?.o2 || 0} <span className="text-xs font-bold uppercase text-slate-400">%</span></p>
                       </div>
                       <span className={`text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md self-start mt-4 ${criticalVitals?.isO2Critical ? 'bg-red-500/10 text-red-600' : 'bg-slate-200/50 text-slate-500'}`}>
                          {criticalVitals?.isO2Critical ? 'CRITICAL' : 'OPTIMAL'}
                       </span>
                    </div>

                    {/* TEMPERATURE */}
                    <div className={`p-6 rounded-[24px] border ${criticalVitals?.isTempCritical ? 'bg-red-50/60 border-red-200 text-red-700' : 'bg-slate-50 border-slate-100 text-slate-700'} flex flex-col justify-between`}>
                       <div>
                          <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Temperature</p>
                          <p className="text-3xl font-black italic tracking-tighter mt-2">{criticalVitals?.temp || 0} <span className="text-xs font-bold uppercase text-slate-400">°C</span></p>
                       </div>
                       <span className={`text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md self-start mt-4 ${criticalVitals?.isTempCritical ? 'bg-red-500/10 text-red-600' : 'bg-slate-200/50 text-slate-500'}`}>
                          {criticalVitals?.isTempCritical ? 'CRITICAL' : 'OPTIMAL'}
                       </span>
                    </div>

                    {/* HUMIDITY */}
                    <div className="p-6 rounded-[24px] border bg-slate-50 border-slate-100 text-slate-700 flex flex-col justify-between">
                       <div>
                          <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Ambient Humidity</p>
                          <p className="text-3xl font-black italic tracking-tighter mt-2">{criticalVitals?.humidity || 55} <span className="text-xs font-bold uppercase text-slate-400">%</span></p>
                       </div>
                       <span className="text-[8px] font-black uppercase tracking-widest px-2.5 py-1 bg-slate-200/50 text-slate-500 rounded-md self-start mt-4">
                          MONITORED
                       </span>
                    </div>
                 </div>

                 {/* REAL-TIME TELEMETRY WAVEFORM (ECG LEAD II) */}
                 <div className="border border-red-100 bg-red-50/20 rounded-[24px] p-6">
                    <p className="text-[10px] font-black uppercase tracking-widest text-red-500 mb-3 flex items-center gap-1.5 font-sans">
                       <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                       REAL-TIME TELEMETRY WAVEFORM (ECG LEAD II)
                    </p>
                    <div className="h-[280px] rounded-[16px] overflow-hidden flex items-center justify-center relative bg-white border border-slate-100 shadow-inner">
                       <ECGGraph bpm={criticalVitals?.heartRate} liveEcg={criticalVitals?.ecg} spo2={criticalVitals?.o2} />
                    </div>
                 </div>

                 {/* METRICS METADATA FOOTER */}
                 <div className="flex bg-slate-100/50 p-4 border border-slate-200/40 rounded-xl justify-between flex-wrap text-[10px] font-mono text-slate-500 antialiased font-semibold">
                    <span>PATIENT: {criticalPatientData?.displayName || "ACTIVE NODE"}</span>
                    <span>ID: {criticalPatientId?.slice(0, 8).toUpperCase() || "HS-001"}</span>
                    <span>TIME: {new Date().toLocaleTimeString()}</span>
                  </div>

                 {/* ACTION ROW BAR */}
                 <div className="flex flex-col sm:flex-row gap-4 items-center justify-between border-t border-slate-100 pt-8 mt-4 font-sans">
                    <button 
                      onClick={handleMuteSirenAudio}
                      className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black uppercase tracking-wider text-[10px] border transition-all cursor-pointer ${
                        isAlertMuted 
                          ? 'bg-amber-50 border-amber-200 text-amber-700' 
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-600'
                      }`}
                    >
                      {isAlertMuted ? (
                        <>
                          <VolumeX className="w-4 h-4 text-amber-600 font-bold" />
                          UNMUTE AMBULANCE VOICE
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-4 h-4 text-slate-500 animate-pulse font-bold" />
                          MUTE SIREN AUDIO
                        </>
                      )}
                    </button>

                    <div className="flex items-center gap-4 w-full sm:w-auto">
                       <button 
                         onClick={handleDownloadSnapshot}
                         className="flex-1 sm:flex-none border-2 border-slate-200 hover:border-slate-300 bg-slate-50 text-slate-700 rounded-2xl px-6 py-4 font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm hover:scale-[1.01] active:scale-95"
                       >
                          <FileDown className="w-4 h-4 text-slate-500 animate-bounce" />
                          <span>DOWNLOAD PDF REPORT</span>
                       </button>
                       <button 
                         onClick={handleRejectFalseAlert}
                         className="flex-1 sm:flex-none border-2 border-dashed border-slate-200 text-slate-500 hover:border-slate-300 hover:text-slate-600 rounded-2xl px-6 py-4 font-black uppercase tracking-widest text-[10px] transition-all cursor-pointer"
                       >
                          REJECT FALSE ALERT
                       </button>
                       <button 
                         onClick={handleAcceptEmergency}
                         className="flex-1 sm:flex-none bg-accent-maroon hover:bg-accent-maroon/90 text-white rounded-2xl px-8 py-4 font-black uppercase tracking-widest text-[10px] flex items-center gap-2 shadow-lg shadow-accent-maroon/20 hover:scale-[1.02] active:scale-95 transition-transform cursor-pointer"
                       >
                          ACCEPT EMERGENCY
                       </button>
                    </div>
                 </div>
               </div>
             </motion.div>
           </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const StatCard = ({ label, value, sub, trend, icon: Icon, color }: { label: string; value: string | number; sub: string; trend: string; icon: any; color?: 'maroon' }) => (
  <div className="bg-white p-6 md:p-8 rounded-[24px] md:rounded-[40px] border border-slate-100 shadow-premium flex items-center gap-4 md:gap-6">
    <div className={`w-12 h-10 md:w-16 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center shrink-0 ${
      color === 'maroon' ? 'bg-accent-maroon text-white shadow-lg shadow-accent-maroon/20' : 'bg-slate-50 text-slate-400'
    }`}>
      <Icon className="w-5 h-5 md:w-7 md:h-7" />
    </div>
    <div className="flex-1 min-w-0">
      <div className="flex items-center justify-between mb-1">
         <p className="text-[8px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
         <span className={`text-[8px] md:text-[9px] font-black uppercase ${color === 'maroon' ? 'text-medical-red' : 'text-green-500'}`}>{trend}</span>
      </div>
      <p className="text-2xl md:text-4xl font-black text-slate-900 tracking-tighter mb-1 truncate">{value}</p>
      <p className="text-[8px] md:text-[10px] font-bold text-slate-400 uppercase tracking-tight truncate">{sub}</p>
    </div>
  </div>
);

const FilterButton = ({ children, active, onClick }: { children: React.ReactNode; active: boolean; onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`px-4 sm:px-6 py-2 md:py-2.5 rounded-lg md:rounded-xl font-bold text-[10px] sm:text-xs transition-all whitespace-nowrap ${
      active ? 'bg-white text-slate-900 shadow-sm border border-slate-100' : 'text-slate-400 hover:text-slate-600'
    }`}
  >
    {children}
  </button>
);

export default DoctorDashboard;

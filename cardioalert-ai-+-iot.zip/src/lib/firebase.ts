import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { initializeFirestore, doc, getDocFromServer, persistentLocalCache, persistentMultipleTabManager, terminate } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getDatabase } from "firebase/database";
import firebaseConfig from '../../firebase-applet-config.json';

// Configuration from environment variables with fallback to firebase-applet-config.json
const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || firebaseConfig.apiKey,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || firebaseConfig.authDomain,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || firebaseConfig.projectId,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || firebaseConfig.storageBucket,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || firebaseConfig.messagingSenderId,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || firebaseConfig.appId,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || firebaseConfig.measurementId,
  databaseURL: "https://heartsync-3b608-default-rtdb.asia-southeast1.firebasedatabase.app"
};

// Singleton app initialization
const app = !getApps().length ? initializeApp(config) : getApp();

export const auth = getAuth(app);
export const rtdb = getDatabase(app, "https://heartsync-3b608-default-rtdb.asia-southeast1.firebasedatabase.app");

// Use initializeFirestore to enable forceLongPolling and persistent local cache
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  })
}, firebaseConfig.firestoreDatabaseId);

export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// --- Firestore Connection Validation ---
async function testConnection() {
  try {
    // CRITICAL: Call getDocFromServer to verify backend connectivity as per instructions
    await getDocFromServer(doc(db, 'system', 'connection_test'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Clinical Database Initialization: The client is currently reporting an offline status. This is normal during initial container boot or network transition.");
    } else {
      console.debug("Firestore connection test completed (may have 404ed but server reached).");
    }
  }
}
// Run validation on module load
testConnection();

// --- Firestore Error Handling ---
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  // Enhanced circularity detection and cleanup
  const seen = new WeakSet();
  const circularReplacer = (key: string, value: any) => {
    if (typeof value === "object" && value !== null) {
      if (seen.has(value)) return "[Circular]";
      seen.add(value);
      
      // Specifically filter out common circular or massive properties in Firebase/DOM objects
      if (key === 'src' || key === 'parent' || key === 'root') return "[Ref]";
      if (value instanceof HTMLElement || value instanceof Window || value instanceof Document) {
        return "[DOM Node]";
      }
    }
    return value;
  };

  const safeStringify = (obj: any): string => {
    try {
      return JSON.stringify(obj, circularReplacer);
    } catch (e) {
      return `[Serialization Error: ${e instanceof Error ? e.message : String(e)}]`;
    }
  };

  let errorMessage = 'Unknown error';
  if (error instanceof Error) {
    errorMessage = error.message;
  } else if (typeof error === 'string') {
    errorMessage = error;
  } else {
    errorMessage = safeStringify(error);
  }

  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }

  // Clear seen set for second pass
  seen.delete(errInfo); 
  // Note: seen is block-scoped so we don't strictly need to clear it, 
  // but for clarity in safeLog we'll just redefine it inside the helper actually.

  const serializedErrorInfo = safeStringify(errInfo);
  
  const isOfflineError = errorMessage.toLowerCase().includes('offline') || 
                        errorMessage.toLowerCase().includes('client is offline') || 
                        errorMessage.toLowerCase().includes('unreachable') || 
                        errorMessage.toLowerCase().includes('network');

  if (isOfflineError) {
    console.warn('Firestore Clinical Offline Event (Handled Gracefully):', serializedErrorInfo);
    return;
  }

  console.error('Firestore Clinical Error Log: ', serializedErrorInfo);
  
  // Always throw the serialized error info to satisfy the requirement
  // for a JSON string error message that conforms to FirestoreErrorInfo
  throw new Error(serializedErrorInfo);
}

export function parseFirestoreError(error: any): string {
  const message = error.message || String(error);
  try {
    const parsed = JSON.parse(message) as FirestoreErrorInfo;
    if (parsed.error.includes('the client is offline')) {
      return "System is offline. Changes will sync when connection is restored.";
    }
    if (parsed.error.includes('insufficient permissions')) {
      return "Access denied: Missing permissions.";
    }
    return parsed.error;
  } catch {
    return message;
  }
}
// --------------------------------

export default app;

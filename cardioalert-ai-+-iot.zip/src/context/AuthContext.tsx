import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User, signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile, signInWithPopup, GoogleAuthProvider, sendPasswordResetEmail } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { CheckCircle2, AlertCircle } from 'lucide-react';

interface ToastType {
  message: string;
  type: 'success' | 'error';
}

interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  role: 'patient' | 'doctor' | 'admin' | null;
  status: 'pending' | 'approved' | 'rejected';
  onboarded: boolean;
  onboardingCompleted?: boolean;
  createdAt?: any;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isOnline: boolean;
  toast: ToastType | null;
  showToast: (message: string, type: 'success' | 'error') => void;
  updateProfileData: (data: Partial<UserProfile>) => Promise<void>;
  login: (email: string, password: string) => Promise<User | null>;
  loginWithGoogle: () => Promise<User | null>;
  resetPassword: (email: string) => Promise<void>;
  signup: (email: string, password: string, fullName: string) => Promise<User | null>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({ 
  user: null, 
  profile: null,
  loading: true, 
  isOnline: true,
  toast: null, 
  showToast: () => {},
  updateProfileData: async () => {},
  login: async () => null,
  loginWithGoogle: async () => null,
  resetPassword: async () => {},
  signup: async () => null,
  logout: async () => {}
});

export const useAuth = () => useContext(AuthContext);

// Safe stringify helper for serializing profile metadata to LocalStorage
const safeStringify = (obj: any): string => {
  const seen = new WeakSet();
  return JSON.stringify(obj, (key, value) => {
    if (typeof value === "object" && value !== null) {
      if (seen.has(value)) {
        return "[Circular]";
      }
      seen.add(value);
      
      // Filter out DOM elements or other non-serializables that might cause issues
      if (value instanceof HTMLElement || value instanceof Window || value instanceof Document) {
        return "[DOM Element]";
      }
    }
    return value;
  });
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [profile, setProfile] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('last_known_profile');
    try {
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(!localStorage.getItem('last_known_profile'));
  const [toast, setToast] = useState<ToastType | null>(null);

  const showToast = React.useCallback((message: string, type: 'success' | 'error') => {
    setToast({ message, type });
  }, []);

  // Manage toast auto-dismiss timer separately to prevent overlapping timeouts
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => {
      setToast(null);
    }, 3000);
    return () => clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showToast("Realtime Sync Connected", "success");
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast("Offline Mode Active", "error");
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [showToast]);

  const logout = React.useCallback(async () => {
    try {
      localStorage.removeItem('last_known_profile');
      setProfile(null);
    } catch (error) {
      console.error("Error during logout cleanup:", error);
    }
    await auth.signOut();
  }, []);

  const login = React.useCallback(async (email: string, password: string) => {
    try {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      showToast("Node Link Established", "success");
      return cred.user;
    } catch (error: any) {
      console.error("Login Error:", error);
      let message = "Node authentication failed. Please verify credentials.";
      if (error.code === 'auth/invalid-credential' || error.code === 'auth/wrong-password' || error.code === 'auth/user-not-found') {
        message = "Invalid node credentials. Access denied.";
      } else if (error.code === 'auth/too-many-requests') {
        message = "Too many failed attempts. Identity locked for security.";
      }
      throw new Error(message);
    }
  }, [showToast]);

  const loginWithGoogle = React.useCallback(async () => {
    try {
      const provider = new GoogleAuthProvider();
      const cred = await signInWithPopup(auth, provider);
      showToast("Google Identity Synchronized", "success");
      return cred.user;
    } catch (error: any) {
      console.error("Google Auth Error:", error);
      // Show more descriptive error for debugging
      let msg = "Identity sync failed.";
      if (error.code === 'auth/popup-closed-by-user') {
        msg = "Authentication window closed.";
      } else if (error.code === 'auth/operation-not-allowed') {
        msg = "Google auth not enabled in console.";
      } else if (error.code) {
        msg = `Sync failed: ${error.code}`;
      }
      showToast(msg, "error");
      return null;
    }
  }, [showToast]);

  const resetPassword = React.useCallback(async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
      showToast("Identity recovery link sent to email.", "success");
    } catch (error: any) {
      console.error("Reset Error:", error);
      let msg = "Could not send recovery link.";
      if (error.code === 'auth/user-not-found') {
        msg = "E-health node not found.";
      } else if (error.code === 'auth/invalid-email') {
        msg = "Invalid e-health address.";
      }
      showToast(msg, "error");
      throw new Error(msg);
    }
  }, [showToast]);

  const signup = React.useCallback(async (email: string, password: string, fullName: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(userCredential.user, { displayName: fullName });
      
      // Initialize profile document
      const profileRef = doc(db, 'users', userCredential.user.uid);
      const newProfile: UserProfile = {
        uid: userCredential.user.uid,
        email: email,
        displayName: fullName,
        role: null,
        status: 'approved',
        onboarded: false,
        onboardingCompleted: false,
        createdAt: serverTimestamp()
      };
      await setDoc(profileRef, newProfile);
      
      showToast("Neural Profile Registered", "success");
      return userCredential.user;
    } catch (error: any) {
      console.error("Signup Error:", error);
      let message = "Registry synchronization failed. Please try again.";
      if (error.code === 'auth/email-already-in-use') {
        message = "This e-health node is already registered. Please sign in.";
      } else if (error.code === 'auth/weak-password') {
        message = "Neural passkey is too weak. Enhance complexity.";
      } else if (error.code === 'auth/invalid-email') {
        message = "Invalid e-health address format.";
      }
      throw new Error(message);
    }
  }, [showToast]);

  const updateProfileData = React.useCallback(async (data: Partial<UserProfile>) => {
    if (!auth.currentUser) return;
    
    // Optimistic update
    setProfile(prev => {
      const next = prev ? { ...prev, ...data } : null;
      if (next) {
        try {
          localStorage.setItem('last_known_profile', safeStringify(next));
        } catch (e) {
          console.error("Persistence failed:", e);
        }
      }
      return next;
    });
    
    try {
      const profileRef = doc(db, 'users', auth.currentUser.uid);
      await setDoc(profileRef, {
        ...data,
        updatedAt: serverTimestamp(),
      }, { merge: true });
    } catch (error) {
      console.error("Error updating profile data:", error);
      showToast("Sync Delayed: Offline update queued", "error");
      throw error;
    }
  }, [showToast]);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;
    let loadingTimer: NodeJS.Timeout | null = null;
    let isMounted = true;

    const unsubscribeAuth = onAuthStateChanged(auth, async (authUser) => {
      if (!isMounted) return;
      setUser(authUser);
      
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (loadingTimer) {
        clearTimeout(loadingTimer);
        loadingTimer = null;
      }

      if (authUser) {
        // Fast-path: If we already have a cached profile matching this user, do not show the spinner
        const cached = localStorage.getItem('last_known_profile');
        let hasMatch = false;
        if (cached) {
          try {
            const parsed = JSON.parse(cached);
            if (parsed && parsed.uid === authUser.uid) {
              hasMatch = true;
            }
          } catch (e) {}
        }

        if (!hasMatch) {
          setLoading(true);
        }

        // Set up safety timeout fallback so initialization never freezes the UI
        loadingTimer = setTimeout(() => {
          if (isMounted) {
            setLoading(false);
          }
          console.warn("Medical session initialization fallback triggered.");
        }, 5000);

        const profileRef = doc(db, 'users', authUser.uid);

        unsubscribeProfile = onSnapshot(profileRef, 
          (snap) => {
            if (!isMounted) return;
            if (snap.exists()) {
              const data = snap.data() as UserProfile;
              setProfile(data);
              try {
                localStorage.setItem('last_known_profile', safeStringify(data));
              } catch (e) {
                console.error("Realtime persistence failed:", e);
              }
            } else {
              // Asynchronously verify/initialize document if online so we don't block the UI thread
              if (navigator.onLine) {
                console.log("Initializing missing user profile document asynchronously...");
                const newProfile: UserProfile = {
                  uid: authUser.uid,
                  email: authUser.email,
                  displayName: authUser.displayName || 'Medical Node',
                  role: null,
                  status: 'approved',
                  onboarded: false,
                  onboardingCompleted: false,
                  createdAt: serverTimestamp()
                };
                setDoc(profileRef, newProfile).catch((err) => {
                  console.error("Async profile write failed:", err);
                });
              }
            }
            if (loadingTimer) {
              clearTimeout(loadingTimer);
              loadingTimer = null;
            }
            setLoading(false);
          },
          (err: any) => {
            console.error("Profile snapshot error:", err);
            if (!isMounted) return;
            if (loadingTimer) {
              clearTimeout(loadingTimer);
              loadingTimer = null;
            }
            setLoading(false);
          }
        );
      } else {
        setProfile(null);
        localStorage.removeItem('last_known_profile');
        setLoading(false);
      }
    });

    return () => {
      isMounted = false;
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
      if (loadingTimer) clearTimeout(loadingTimer);
    };
  }, []);

  const value = React.useMemo(() => ({ 
    user, 
    profile, 
    loading, 
    isOnline,
    toast, 
    showToast, 
    updateProfileData,
    login,
    loginWithGoogle,
    resetPassword,
    signup,
    logout 
  }), [
    user, 
    profile, 
    loading, 
    isOnline, 
    toast, 
    showToast, 
    updateProfileData, 
    login, 
    loginWithGoogle, 
    resetPassword, 
    signup, 
    logout
  ]);

  return (
    <AuthContext.Provider value={value}>
      {children}
      {toast && (
        <div className="fixed bottom-10 right-10 z-[100] animate-in fade-in slide-in-from-bottom-5">
          <div className={`p-4 rounded-2xl bg-white border shadow-2xl flex items-center gap-3 min-w-[300px] ${
            toast.type === 'success' ? 'border-accent-maroon/20 text-accent-maroon' : 'border-red-200 text-red-600'
          }`}>
            {toast.type === 'success' ? (
              <div className="p-1 bg-accent-maroon/10 rounded-full">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            ) : (
              <div className="p-1 bg-red-100 rounded-full">
                <AlertCircle className="w-4 h-4" />
              </div>
            )}
            <p className="font-bold">{toast.message}</p>
          </div>
        </div>
      )}
    </AuthContext.Provider>
  );
};

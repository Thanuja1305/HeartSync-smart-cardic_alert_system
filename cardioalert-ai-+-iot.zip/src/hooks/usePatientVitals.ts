import { useState, useEffect } from 'react';
import { ref, onValue } from 'firebase/database';
import { rtdb } from '../lib/firebase';

export interface VitalsData {
  heartRate: number;
  bpm: number;
  spo2: number;
  temperature: number;
  humidity?: number;
  ecg?: number | number[] | string;
  current_condition?: string;
  alertLevel?: number; // 1 = optimal, 2 = warning, 3 = critical
  alertReason?: string;
}

export function usePatientVitals(userId?: string) {
  const [vitals, setVitals] = useState<VitalsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    console.log("LISTENER INITIALIZED: Realtime stream setup for patient:", userId);
    
    // Maintain references to both potential nodes so we can merge updates continuously
    const liveReadingRef = ref(rtdb, `/users/${userId}/liveReading`);
    const livereadingRef = ref(rtdb, `/users/${userId}/livereading`);

    let latestLiveReading: any = null;
    let latestLivereading: any = null;

    const processVitalsData = (data: any) => {
      // Support all lower, upper, and clinical variants from direct hardware outputs
      const rawHr = data.BPM !== undefined ? Number(data.BPM) : (data.bpm !== undefined ? Number(data.bpm) : (data.heartRate !== undefined ? Number(data.heartRate) : (data.HeartRate !== undefined ? Number(data.HeartRate) : 0)));
      const rawO2 = data.SpO2 !== undefined ? Number(String(data.SpO2).replace('%', '')) : (data.spo2 !== undefined ? Number(data.spo2) : (data.SPO2 !== undefined ? Number(data.SPO2) : (data.o2 !== undefined ? Number(data.o2) : 0)));
      const rawTemp = data.Temp !== undefined ? Number(String(data.Temp).replace(/[CF\s]/gi, '')) : (data.temperature !== undefined ? Number(data.temperature) : (data.temp !== undefined ? Number(data.temp) : (data.Temperature !== undefined ? Number(data.Temperature) : 0)));
      const rawHum = data.Humidity !== undefined ? Number(String(data.Humidity).replace('%', '')) : (data.humidity !== undefined ? Number(data.humidity) : 0);
      
      // Force whole numbers for clean clinical display as requested
      const hrValue = Math.round(rawHr);
      const o2Value = Math.round(rawO2);
      const tempValue = Number(rawTemp.toFixed(1)); // 1 decimal place is clinically standard for temperature (e.g. 36.5 °C)
      const humValue = Math.round(rawHum);
      
      // ECG can be a single number (sample point), an array of number samples, or a clinical string description (e.g. "Normal_Sinus", "Flatline", "Arrhythmia")
      let ecgValue: number | number[] | string = 0;
      const rawEcg = data.ECG !== undefined ? data.ECG : (data.ecg !== undefined ? data.ecg : undefined);
      if (rawEcg !== undefined) {
        if (Array.isArray(rawEcg)) {
          ecgValue = rawEcg.map(Number).filter(v => !isNaN(v));
        } else if (typeof rawEcg === 'string') {
          ecgValue = rawEcg;
        } else {
          ecgValue = isNaN(Number(rawEcg)) ? 0 : Number(rawEcg);
        }
      }

      // Automatic ICU Condition Detection Logic
      let status: 'Normal' | 'Warning' | 'Critical' = 'Normal';
      let alertLevel = 1;

      if (o2Value > 0 && (o2Value < 90 || hrValue > 130 || hrValue < 45)) {
        status = 'Critical';
        alertLevel = 3;
      } else if (tempValue > 38 || (o2Value > 0 && o2Value < 95)) {
        status = 'Warning';
        alertLevel = 2;
      }

      setVitals({
        heartRate: hrValue,
        bpm: hrValue,
        spo2: o2Value,
        temperature: tempValue,
        humidity: humValue,
        ecg: ecgValue,
        current_condition: data.status || status,
        alertLevel: alertLevel,
        alertReason: data.alertReason || (status === 'Critical' ? 'Critical Vitals' : status === 'Warning' ? 'Abnormal Vitals' : 'Optimal')
      });
      setLoading(false);
    };

    const useOfflineDefaults = () => {
      setVitals({
        heartRate: 0,
        bpm: 0,
        spo2: 0,
        temperature: 0,
        humidity: 0,
        ecg: 0,
        current_condition: 'OFFLINE',
        alertLevel: 1,
        alertReason: 'Sensor Off'
      });
      setLoading(false);
    };

    const handleUpdate = () => {
      // Prioritize whichever node has actual physiological reading activity (non-zero heart-rate or oxygen)
      const data1Active = latestLiveReading && (Number(latestLiveReading.bpm || latestLiveReading.heartRate || 0) > 0);
      const data2Active = latestLivereading && (Number(latestLivereading.bpm || latestLivereading.heartRate || 0) > 0);

      if (data1Active) {
        processVitalsData(latestLiveReading);
      } else if (data2Active) {
        processVitalsData(latestLivereading);
      } else {
        // Drop back to whichever exist, prioritizing liveReading
        const fallbackData = latestLiveReading || latestLivereading;
        if (fallbackData) {
          processVitalsData(fallbackData);
        } else {
          useOfflineDefaults();
        }
      }
    };

    const unsubLiveReading = onValue(
      liveReadingRef,
      (snapshot) => {
        latestLiveReading = snapshot.val();
        handleUpdate();
      },
      (err) => {
        console.error("Firebase liveReading stream error:", err);
        setError(err);
        setLoading(false);
      }
    );

    const unsubLivereading = onValue(
      livereadingRef,
      (snapshot) => {
        latestLivereading = snapshot.val();
        handleUpdate();
      },
      (err) => {
        console.error("Firebase livereading stream error:", err);
        setError(err);
        setLoading(false);
      }
    );

    return () => {
      console.log("UNSUBSCRIBE: Tearing down both RTDB listeners for", userId);
      unsubLiveReading();
      unsubLivereading();
    };
  }, [userId]);

  return { vitals, loading, error };
}

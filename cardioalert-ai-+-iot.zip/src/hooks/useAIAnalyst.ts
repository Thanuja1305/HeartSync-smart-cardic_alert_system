import { useEffect, useRef } from 'react';
import { db } from '../lib/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

export const useAIAnalyst = (userId: string | undefined, metrics: any) => {
  const lastAnalysisTime = useRef<number>(0);
  const isAnalyzing = useRef<boolean>(false);

  const bpm = metrics?.bpm || metrics?.heartRate || 0;
  const spo2 = metrics?.spo2 || 0;
  const temp = metrics?.temperature || metrics?.temp || 0;
  const motion = metrics?.motion || metrics?.motionStatus || "Unknown";

  useEffect(() => {
    if (!userId || !bpm) return;

    const now = Date.now();
    // Analyze every 1 minute (60,000 ms)
    if (now - lastAnalysisTime.current < 60000 || isAnalyzing.current) return;

    const runAnalysis = async () => {
      isAnalyzing.current = true;
      try {
        console.info("🧠 AI Analyst: Starting periodic health review...");
        
        const response = await fetch('/api/gemini/analyze', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ 
            metrics: {
              bpm,
              spo2,
              temperature: temp,
              motion
            }
          })
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch AI analysis: ${response.statusText}`);
        }

        const analysisResult = await response.json();
        
        await setDoc(doc(db, 'aiAnalysis', userId), {
          ...analysisResult,
          updatedAt: serverTimestamp(),
          vitalsAtTime: {
            bpm,
            spo2,
            temp
          }
        }, { merge: true });

        // If emergency, ensure emergencyAlert is updated
        if (analysisResult.status === 'EMERGENCY') {
          await setDoc(doc(db, 'emergencyAlerts', userId), {
            aiSummary: analysisResult.reasoning,
            status: 'ACTIVE',
            severity: 'CRITICAL',
            updatedAt: serverTimestamp()
          }, { merge: true });
        }

        lastAnalysisTime.current = Date.now();
        console.info("✅ AI Analyst: Periodic review completed and synced.");
      } catch (error) {
        console.error("❌ AI Analyst Error:", error);
      } finally {
        isAnalyzing.current = false;
      }
    };

    runAnalysis();
  }, [userId, bpm, spo2, temp, motion]);
};

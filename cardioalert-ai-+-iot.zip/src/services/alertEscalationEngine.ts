/**
 * HEART SYNC - REAL-TIME ALERT & ESCALATION ENGINE SERVICE
 * 
 * This service implements the state-driven, deterministic triage logic,
 * Firebase data structures, and transactional override and dispatch controls
 * for the HeartSync Doctor's Dashboard.
 */

import { rtdb, db } from '../lib/firebase';
import { ref, set, update, push, serverTimestamp as rtdbTimestamp } from 'firebase/database';
import { collection, addDoc, serverTimestamp as firestoreTimestamp } from 'firebase/firestore';

// --- Section 1: FIREBASE ALERTS DATA STRUCTURE & REAL-TIME PATHS SPECIFICATION ---
/**
 * Real-time database path design:
 * 
 * 1. LIVE VITALS PATH:
 *    Ref: `/patients/${patientId}/vitals`
 *    Payload:
 *    {
 *       "bpm": 145,                // Live heart rate
 *       "spo2": 88,                // Blood oxygen level (%)
 *       "temperature": 39.2,       // Body temperature (°C)
 *       "ecgStatus": "Irregular",  // ECG pattern state ("Normal" | "Irregular" | "Flatline")
 *       "timestamp": 1716584219000 // Epoch milliseconds
 *    }
 * 
 * 2. ALERT STATE PATH:
 *    Ref: `/patients/${patientId}/alert_state`
 *    Payload:
 *    {
 *       "level": 4,                    // Escalation Level: 1 = Normal, 2 = Warning, 3 = Critical, 4 = Emergency
 *       "status": "Cardiac Incident",  // Dynamic clinical state string 
 *       "timestamp": 1716584219000,    // Time of last evaluation
 *       "is_acknowledged": false       // Dispatch/resolution acknowledgement status
 *    }
 * 
 * 3. HISTORICAL STREAM PATH:
 *    Ref: `/alerts_log/${alertId}`
 *    Payload:
 *    {
 *       "alertId": "-Nxs...",
 *       "patientId": "PT-4587",
 *       "patientName": "Rahul Sharma",
 *       "level": 4,
 *       "status": "Cardiac Incident",
 *       "message": "Heart Attack Risk: BPM > 140 + ECG === Irregular + SpO2 < 90%",
 *       "vitalsAtTrigger": {
 *          "bpm": 145,
 *          "spo2": 88,
 *          "temperature": 37.0,
 *          "ecgStatus": "Irregular"
 *       },
 *       "detectedAt": 1716584219000,
 *       "resolved": false
 *    }
 */

export interface VitalsPayload {
  bpm: number;
  spo2: number;
  temperature: number;
  ecgStatus: 'Normal' | 'Irregular' | 'Flatline' | string;
}

export interface AlertStatePayload {
  level: 1 | 2 | 3 | 4;
  status: string;
  timestamp: number;
  is_acknowledged: boolean;
  label?: string;
  dispatchAvailable?: boolean;
}

export interface AlertSeverityResult {
  level: 1 | 2 | 3 | 4;
  status: string;
  triggerPopup: boolean;
  playAudio: boolean;
  continuousSiren?: boolean;
  dispatchAvailable?: boolean;
  label: string;
}

// --- Section 2: MULTI-PARAMETER TRIAGE LOGIC ENGINE ---

/**
 * Deterministically triages live clinical parameters against precise physical limits.
 * 
 * Clinical Level Framework:
 * - LEVEL 1 (Normal): All parameters stable.
 * - LEVEL 2 (Warning): Only one parameter outside thresholds (e.g., Temp > 38.5 or BPM 101-120). No full screen alarm.
 * - LEVEL 3 (Critical): Multiple parameters out of bounds (e.g., SpO2 < 90% AND BPM > 140%). Trigger screen overlay and beep.
 * - LEVEL 4 (Emergency): Distinct life-threatening disease signatures:
 *   * Cardiac Arrest: ECG === "Flatline" + BPM < 30 + SpO2 < 80%
 *   * Heart Attack Risk: BPM > 140 + ECG === "Irregular" + SpO2 < 90%
 *   * Sepsis Risk: Temp > 39°C + BPM > 130 + SpO2 < 90%
 *   Trigger dynamic continuous siren, flashing overlay, and lock-state dispatch availability.
 * 
 * @param vitals Heart rate, oxygen, temperature measurements
 * @returns Evaluated target clinical alert state metadata
 */
export function evaluateAlertSeverity(
  vitals: VitalsPayload
): AlertSeverityResult {
  const { bpm, spo2, temperature, ecgStatus } = vitals;

  // --- Check Level 4 Signature 1: Cardiac Arrest ---
  if (ecgStatus === 'Flatline' && bpm < 30 && spo2 < 80) {
    return {
      level: 4,
      status: 'Cardiac Arrest',
      triggerPopup: true,
      playAudio: true,
      continuousSiren: true,
      dispatchAvailable: true,
      label: 'Cardiac Arrest Signature Detected'
    };
  }

  // --- Check Level 4 Signature 2: Heart Attack Risk ---
  if (bpm > 140 && ecgStatus === 'Irregular' && spo2 < 90) {
    return {
      level: 4,
      status: 'Heart Attack Risk',
      triggerPopup: true,
      playAudio: true,
      continuousSiren: true,
      dispatchAvailable: true,
      label: 'Unstable Heart Rhythm - Coronary Risk'
    };
  }

  // --- Check Level 4 Signature 3: Sepsis Risk ---
  if (temperature > 39.0 && bpm > 130 && spo2 < 90) {
    return {
      level: 4,
      status: 'Sepsis Risk',
      triggerPopup: true,
      playAudio: true,
      continuousSiren: true,
      dispatchAvailable: true,
      label: 'Hyperthermic Septic Shock Risk'
    };
  }

  // --- Check Level 3: Multiple Parameters Out of Bounds ---
  // E.g., Low SpO2 (<90%) AND High BPM (>140%)
  if (spo2 < 90 && bpm > 140) {
    return {
      level: 3,
      status: 'Unstable Heart Rhythm',
      triggerPopup: true,
      playAudio: true,
      continuousSiren: false,
      dispatchAvailable: false,
      label: 'Critical SpO2 & Heart Rate Compromise'
    };
  }

  // --- Check Level 2: Single Parameter Out of Bounds ---
  const isTempOut = temperature > 38.5;
  const isBpmOut = bpm > 100 && bpm <= 120; // or any metric exceeding standard bounds
  const isSpo2Out = spo2 < 94 && spo2 >= 90;

  if (isTempOut || isBpmOut || isSpo2Out || ecgStatus === 'Irregular') {
    let warnDetails = 'Elevated parameters detected';
    if (isTempOut) warnDetails = 'Isolated Hyperthermia Warning';
    else if (isBpmOut) warnDetails = 'Isolated Tachycardia Warning';
    else if (isSpo2Out) warnDetails = 'Mild Desaturation Warning';
    else if (ecgStatus === 'Irregular') warnDetails = 'Inconsistent Wave Outline';

    return {
      level: 2,
      status: 'Warning',
      triggerPopup: false,
      playAudio: false,
      label: warnDetails
    };
  }

  // --- Level 1: Normal / Baseline Rest State ---
  return {
    level: 1,
    status: 'Stable',
    triggerPopup: false,
    playAudio: false,
    label: 'Optimal State'
  };
}

// --- Section 4: ALERT RESOLUTION & OVERRIDE HANDLERS (Transactional database operations) ---

/**
 * Triggers external emergency notifications and ambulance dispatches
 * through Webhooks or WhatsApp pathways (n8n node orchestration).
 */
export async function triggerExternalWebhooks(patientId: string, alertDetails: any) {
  console.log(`[EXTERNAL DISPATCH DISPATCHED] Sending emergency request to n8n dispatch gateway for Patient ${patientId}`, alertDetails);
  
  // Real secure production request placeholder mimicking REST trigger payload for hospital dispatches
  try {
    const webhookUrl = "https://n8n.workflow.example.com/webhook/dispatch-ambulance";
    // For local evaluation, we perform a fetch only when explicitly available via variable
    if (import.meta.env.VITE_N8_DISPATCH_WEBHOOK) {
      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId,
          timestamp: Date.now(),
          escalation: alertDetails,
          requestedBy: "HeartSync State Escaler"
        })
      });
    }
  } catch (err) {
    console.error("External webhook background route failed to reply:", err);
  }
}

/**
 * Marks an emergency alert as a false alarm, resets the state to baseline level 1,
 * and appends an entry to the system audit trails.
 */
export async function handleMarkAsFalseAlert(
  patientId: string, 
  patientName: string = "Active Node"
) {
  const timestamp = Date.now();
  console.log(`[OVERRIDE TRIGGERED] Initializing False Alert recovery context for patient ${patientId}`);

  // 1. Transactionally update patient alert_state on RTDB to Normal
  const alertStateRef = ref(rtdb, `/patients/${patientId}/alert_state`);
  await set(alertStateRef, {
    level: 1,
    status: 'Stable (Override)',
    timestamp: timestamp,
    is_acknowledged: true,
    label: 'Marked as False Alarm'
  });

  // 2. Clear any active flags on patients' live readings
  const liveReadingRef = ref(rtdb, `/users/${patientId}/liveReading`);
  await update(liveReadingRef, {
    alertLevel: 1,
    alertReason: 'Physician Manual Reset',
    current_condition: 'STABLE (RESET)'
  });

  // 3. Write event node to active alerts-log to track history
  const logRef = ref(rtdb, `/alerts_log`);
  const newLogItem = push(logRef);
  await set(newLogItem, {
    alertId: newLogItem.key,
    patientId: patientId,
    patientName: patientName,
    level: 1,
    status: 'OVERRIDE_RESOLVED',
    message: 'Physician manually reviewed telemetry and declared false trigger.',
    detectedAt: timestamp,
    resolved: true
  });

  // 4. Log to Firestore audit log for compliance trail
  await addDoc(collection(db, 'auditLogs'), {
    action: 'FALSE_ALERT_OVERRIDE',
    patientId: patientId,
    verifiedBy: 'Physician Terminal',
    vitalsStatusAtOverride: 'Reset to Normal',
    timestamp: new Date().toISOString()
  });

  return { success: true, timestamp };
}

/**
 * Confirms an active emergency state, flags acknowledgement triggers,
 * and initiates immediate webhook orchestration for ambulance dispatching.
 */
export async function handleTriggerEmergencyAlert(
  patientId: string, 
  patientName: string = "Active Node",
  vitals?: VitalsPayload
) {
  const timestamp = Date.now();
  console.log(`[EMERGENCY LOCK] Confirmed critical trauma. Initiating ambulance dispatch sequence for ${patientId}`);

  // 1. Transactionally set the verified emergency active level on RTDB
  const alertStateRef = ref(rtdb, `/patients/${patientId}/alert_state`);
  await update(alertStateRef, {
    is_acknowledged: true,
    level: 4,
    status: 'EMERGENCY_DISPATCH_LOCKED'
  });

  // 2. Lock the live readings state to Emergency trigger
  const liveReadingRef = ref(rtdb, `/users/${patientId}/liveReading`);
  await update(liveReadingRef, {
    alertLevel: 4,
    alertReason: 'Clinician Emergency Triggered',
    current_condition: 'DISPATCH_IN_PROGRESS'
  });

  // 3. Deploy external webhook n8n integration dispatch
  const escalationDetails = {
    severity: 'CRITICAL_DISPATCH',
    clinicalSignatures: vitals || { bpm: 145, spo2: 88, temperature: 37.0, ecgStatus: 'Irregular' },
    dispatchedAt: timestamp
  };
  await triggerExternalWebhooks(patientId, escalationDetails);

  // 4. Add ambulance dispatch profile to Firestore for route processing
  const dispatchRef = collection(db, 'ambulanceDispatch');
  await addDoc(dispatchRef, {
    patientId: patientId,
    patientName: patientName,
    alertId: `ALERT-${Date.now()}`,
    ambulanceAssigned: true,
    ambulanceId: 'Unit-Omega-7',
    eta: '5-8 Mins (Express Dispatch)',
    status: 'REQUESTED',
    hospitalAssigned: 'HeartSync Apex Hospital',
    dispatchedAt: timestamp
  });

  // 5. Append compliance trail item to logs
  const logRef = ref(rtdb, `/alerts_log`);
  const newLogItem = push(logRef);
  await set(newLogItem, {
    alertId: newLogItem.key,
    patientId: patientId,
    patientName: patientName,
    level: 4,
    status: 'EMERGENCY_DISPATCHED',
    message: 'Physician-initiated ambulance and emergency crew dispatch locked.',
    detectedAt: timestamp,
    resolved: false
  });

  return { success: true, timestamp };
}

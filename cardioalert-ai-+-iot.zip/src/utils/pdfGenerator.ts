import { jsPDF } from 'jspdf';

interface VitalsSnapshot {
  heartRate: number;
  o2: number;
  temp: number;
  humidity?: number;
  status: string;
  ecgCondition?: string;
  anomalyDetected?: string;
  recommendations?: string;
}

interface PatientDemo {
  name: string;
  age: string;
  gender: string;
  bloodGroup: string;
  phoneNumber?: string;
  condition?: string;
}

export function generateVitalsPDF(patient: PatientDemo, vitals: VitalsSnapshot) {
  // Initialize standard A4 PDF document
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const primaryColor = [128, 0, 32]; // HeartSync Crimson Maroon
  const secondaryColor = [30, 41, 59]; // Slate Gray
  const criticalColor = [220, 38, 38]; // Red Alert
  const optimalColor = [16, 185, 129]; // Green Nominal

  // Add sleek branding top border
  doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.rect(0, 0, 210, 15, 'F');

  // Title Text inside Crimson Top Border
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('HEARTSYNC™ BIOTELEMETRY CLINICAL SYSTEMS // OFFLINE SNAPSHOT', 15, 10);

  // Subheader line below the header bar
  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(`CONFIDENTIAL CLINICAL DOCUMENT // PORT RECIPIENT MODE // TELEMETRY SYNC RECORD`, 15, 20);

  // Generate Current Timestamp
  const now = new Date();
  const timestampStr = now.toLocaleDateString() + ' ' + now.toLocaleTimeString();

  // Document Info
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(`TIMESTAMP: ${timestampStr}`, 145, 20);

  // Draw Patient Demographics Card Box
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(15, 25, 180, 40, 3, 3, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(15, 25, 180, 40, 3, 3, 'S');

  // Patient Card Content Header
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('PATIENT DEMOGRAPHIC GENERAL LEDGER', 20, 33);

  // Demographic content
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('Patient Name:', 20, 42);
  doc.setFont('helvetica', 'normal');
  doc.text(patient.name || 'Rahul Sharma', 50, 42);

  doc.setFont('helvetica', 'bold');
  doc.text('Age / Gender:', 20, 48);
  doc.setFont('helvetica', 'normal');
  doc.text(`${patient.age || '54'} yrs / ${patient.gender || 'Male'}`, 50, 48);

  doc.setFont('helvetica', 'bold');
  doc.text('Primary Diagnosis:', 20, 54);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(patient.condition || 'Post-Myocardial Infarction Telemetry', 50, 54);
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);

  // Secondary Demographics (O+, Phone)
  doc.setFont('helvetica', 'bold');
  doc.text('Blood Group:', 120, 42);
  doc.setFont('helvetica', 'normal');
  doc.text(patient.bloodGroup || 'O+', 150, 42);

  doc.setFont('helvetica', 'bold');
  doc.text('Contact Phone:', 120, 48);
  doc.setFont('helvetica', 'normal');
  doc.text(patient.phoneNumber || '+91 95737 32216', 150, 48);

  // Status Indicator Circle inside Patient Demographics Box
  const codeStatusVal = vitals.status.toUpperCase();
  const indicatorColor = codeStatusVal === 'CRITICAL' ? criticalColor : (codeStatusVal === 'WARNING' ? [245, 158, 11] : optimalColor);
  doc.setFillColor(indicatorColor[0], indicatorColor[1], indicatorColor[2]);
  doc.circle(130, 53, 1.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.text('Triage Level:', 135, 54);
  doc.setTextColor(indicatorColor[0], indicatorColor[1], indicatorColor[2]);
  doc.text(codeStatusVal, 158, 54);
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);


  // Draw Telemetry Vital Signs Grid Board
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(226, 232, 240);
  
  // Vertical Column boxes
  // Box 1: Heart Rate
  doc.roundedRect(15, 70, 42, 35, 2, 2, 'S');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text('HEART RATE', 20, 76);
  doc.setFontSize(22);
  doc.setTextColor(indicatorColor[0], indicatorColor[1], indicatorColor[2]);
  doc.setFont('helvetica', 'bold');
  doc.text(`${vitals.heartRate}`, 20, 88);
  doc.setFontSize(8);
  doc.text('BPM', 20, 95);

  // Box 2: Blood Oxygen SpO2
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.roundedRect(61, 70, 42, 35, 2, 2, 'S');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text('BLOOD OXYGEN', 66, 76);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  const isO2Crisis = vitals.o2 < 90;
  doc.setTextColor(isO2Crisis ? criticalColor[0] : optimalColor[0], isO2Crisis ? criticalColor[1] : optimalColor[1], isO2Crisis ? criticalColor[2] : optimalColor[2]);
  doc.text(`${vitals.o2}`, 66, 88);
  doc.setFontSize(8);
  doc.text('%', 66, 95);

  // Box 3: Temperature
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.roundedRect(107, 70, 42, 35, 2, 2, 'S');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text('BODY TEMP', 112, 76);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.text(`${vitals.temp.toFixed(1)}`, 112, 88);
  doc.setFontSize(8);
  doc.text('°C', 112, 95);

  // Box 4: Room Humidity / Environment
  doc.roundedRect(153, 70, 42, 35, 2, 2, 'S');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text('HUMIDITY', 158, 76);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.text(`${vitals.humidity || 58}`, 158, 88);
  doc.setFontSize(8);
  doc.text('%', 158, 95);


  // AI Diagnostics & Medical Annotation Section
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(15, 110, 180, 75, 3, 3, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(15, 110, 180, 75, 3, 3, 'S');

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('CLINICAL TELEMETRY ANNOTATION & AI REASONING', 20, 118);

  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('ECG Sinus Waveform Condition:', 20, 127);
  doc.setFont('helvetica', 'normal');
  doc.text(vitals.ecgCondition || 'Standard Rhythm - Trace Pattern II showing stable QRS segment', 80, 127);

  doc.setFont('helvetica', 'bold');
  doc.text('Identified Anomalies:', 20, 134);
  doc.setFont('helvetica', 'normal');
  doc.text(vitals.anomalyDetected || 'No sudden physiological drift detected in current sampling interval', 80, 134);

  doc.setFont('helvetica', 'bold');
  doc.text('Clinical Assessment Guidelines:', 20, 141);

  // Word wrap recommendation text nicely to avoid overflowing bounds
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  const instructionsText = vitals.recommendations || 
    '1. Maintain direct telemetry link on cardiac lead II.\n' +
    '2. Ensure ambient hospital ward temperature is constant.\n' +
    '3. Patient should stay calm, sit in an upright position (Fowler\'s posture), and limit exertion.\n' +
    '4. Prepare emergency code cart and check standard oxygenation reserves in the vicinity.\n' +
    '5. In case of telemetry signal disconnection, manually re-verify physiological pulses immediately.';

  const splitLines = doc.splitTextToSize(instructionsText, 170);
  doc.text(splitLines, 20, 147);


  // Signature and Verification Authority Footer
  // Draw sleek baseline horizontal rule
  doc.setDrawColor(226, 232, 240);
  doc.line(15, 195, 195, 195);

  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.setFont('helvetica', 'normal');
  doc.text('HEARTSYNC EMERGENCY CONSULTATION SERVICE // AUTOGENERATED SYSTEM DOCUMENT', 15, 201);
  
  // Verification field
  doc.setDrawColor(148, 163, 184);
  doc.line(135, 230, 195, 230);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.text('Attending Physician Signature', 135, 235);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text('Registration ID # HS-MD-9921', 135, 240);

  // Hospital logo annotation
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('HEARTSYNC SYSTEM INTEGRITY APPROVED', 15, 210);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text('Valid for clinical adjudication file transfers.', 15, 215);

  // Save the PDF locally
  const sanitizedName = (patient.name || 'patient').replace(/[^a-z0-9]/gi, '_').toLowerCase();
  doc.save(`heartsync_${sanitizedName}_vitals_record.pdf`);
}
